# Perfekey

מקלדת אנדרואיד בעברית ובאנגלית. הבנייה נעשית אוטומטית ב-GitHub Actions.

מילוני השכיחות (app/src/main/assets) מבוססים על FrequencyWords מאת Hermit Dave
(https://github.com/hermitdave/FrequencyWords), שנבנו מכתוביות של OpenSubtitles.
