package com.perfekey.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/** ניהול הכספת: הוספה, עריכה ומחיקה של פריטים פרטיים */
class VaultActivity : Activity() {

    private val authRequest = 21
    private lateinit var ui: UiKit
    private var items = mutableListOf<Vault.Item>()
    private var waitingForAuth = false

    override fun onCreate(savedInstanceState: Bundle?) {
        ui = UiKit(this)
        ui.applyTheme()
        super.onCreate(savedInstanceState)
        ui.styleWindow()
        // מונע צילומי מסך והצגה ברשימת האפליקציות האחרונות
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
    }

    override fun onResume() {
        super.onResume()
        if (Vault.isUnlocked()) {
            Vault.unlock()   // מאריך את הזמן כל עוד המסך פתוח
            items = Vault.load(this)
            render()
        } else if (!waitingForAuth) {
            waitingForAuth = true
            ui.page()   // מסך ריק עד שהאימות יסתיים
            startActivityForResult(Intent(this, VaultAuthActivity::class.java), authRequest)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == authRequest) {
            waitingForAuth = false
            if (resultCode != RESULT_OK) finish()
        }
    }

    override fun onStop() {
        super.onStop()
        if (!waitingForAuth && !isChangingConfigurations) Vault.lock()
    }

    private fun render() {
        val page = ui.page()
        val col = page.column
        ui.header(col, ui.t("הכספת", "Vault"),
            ui.t("מוצפן, נפתח רק בטביעת אצבע", "Encrypted, opens with your fingerprint only"), back = true)

        if (items.isEmpty()) {
            ui.emptyState(col, R.drawable.ic_lock, ui.t("הכספת ריקה", "Your vault is empty"),
                ui.t("שמור כאן מספר תעודת זהות, חשבון בנק, כתובת או כל דבר פרטי. במקלדת, לחיצה על פריט מקלידה אותו בלי להעתיק ללוח.",
                    "Keep your ID number, bank account, address or anything private here. In the keyboard, tapping an item types it without copying to the clipboard."))
        } else {
            ui.section(col, ui.t("${items.size} פריטים", "${items.size} items"))
            val card = ui.card(col)
            for (item in items) {
                ui.add(card, LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(ui.dp(16), ui.dp(13), ui.dp(12), ui.dp(13))
                    background = ui.ripple()
                    isClickable = true
                    setOnClickListener { edit(item) }
                    addView(ui.iconTile(R.drawable.ic_lock, ui.accent))
                    addView(ui.titleBlock(item.label, "•".repeat(item.value.length.coerceIn(6, 14))),
                        LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                    addView(android.widget.ImageView(this@VaultActivity).apply {
                        setImageResource(R.drawable.ic_edit)
                        setColorFilter(ui.textSub, android.graphics.PorterDuff.Mode.SRC_IN)
                    })
                })
            }
            col.addView(TextView(this).apply {
                text = ui.t("לחיצה על פריט לעריכה. אי אפשר לצלם את המסך הזה.", "Tap an item to edit. Screenshots are blocked on this screen.")
                textSize = 13f
                setTextColor(ui.textSub)
                setPadding(ui.dp(8), ui.dp(12), ui.dp(8), 0)
            })
        }
        ui.fab(page) { edit(null) }
    }

    private fun edit(item: Vault.Item?) {
        ui.formSheet(
            if (item == null) ui.t("פריט חדש", "New item") else ui.t("עריכת פריט", "Edit item"),
            listOf(
                UiKit.FieldSpec(ui.t("שם", "Name"), ui.t("למשל: תעודת זהות", "e.g. ID number"), item?.label ?: ""),
                UiKit.FieldSpec(ui.t("תוכן", "Content"), ui.t("מה שיוקלד בלחיצה", "What will be typed"), item?.value ?: "", multiline = true)
            ),
            secure = true,
            onDelete = item?.let { { items.remove(it); Vault.save(this, items); render() } }
        ) { values ->
            val label = values[0].trim()
            val value = values[1]
            if (label.isEmpty() || value.isEmpty()) return@formSheet false
            if (item == null) items += Vault.Item(System.currentTimeMillis(), label, value)
            else { item.label = label; item.value = value }
            Vault.save(this, items)
            render()
            true
        }
    }
}
