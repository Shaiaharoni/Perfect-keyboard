package com.perfekey.app

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Build
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

/** שפת הממשק (מסכי ההגדרות וההודעות): עברית או אנגלית */
object L {
    fun isEnglish(ctx: Context) =
        ctx.getSharedPreferences("settings", Context.MODE_PRIVATE).getString("uiLang", "he") == "en"

    fun t(ctx: Context, he: String, en: String) = if (isEnglish(ctx)) en else he
}

/**
 * ערכת העיצוב המשותפת לכל המסכים: צבעים, כרטיסים, שורות, מתגים, חלונות טופס ואישור.
 * כך כל המסכים נראים אחידים ומתאימים את עצמם למצב בהיר/כהה ולשפת הממשק.
 */
class UiKit(private val a: Activity) {

    val dark = (a.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    val english = L.isEnglish(a)
    val dir = if (english) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL

    val bg = if (dark) 0xFF121214.toInt() else 0xFFF2F3F6.toInt()
    val surface = if (dark) 0xFF1E1F23.toInt() else 0xFFFFFFFF.toInt()
    val field = if (dark) 0xFF2A2B30.toInt() else 0xFFEDEEF2.toInt()
    val textMain = if (dark) 0xFFF2F2F2.toInt() else 0xFF1A1A1A.toInt()
    val textSub = if (dark) 0xFF9A9CA3.toInt() else 0xFF6B6E76.toInt()
    val divider = if (dark) 0x22FFFFFF else 0x14000000
    val accent = Themes.accentOf(a)
    val green = 0xFF2F9E6E.toInt()
    val red = 0xFFE5484D.toInt()

    fun t(he: String, en: String) = if (english) en else he
    fun dp(v: Int): Int = (v * a.resources.displayMetrics.density).toInt()

    /** להפעיל לפני super.onCreate */
    fun applyTheme() {
        a.setTheme(if (dark) android.R.style.Theme_Material_NoActionBar else android.R.style.Theme_Material_Light_NoActionBar)
    }

    /** להפעיל אחרי super.onCreate */
    fun styleWindow() {
        a.window.statusBarColor = bg
        a.window.navigationBarColor = bg
        @Suppress("DEPRECATION")
        if (!dark) a.window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or (if (Build.VERSION.SDK_INT >= 26) View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR else 0)
    }

    fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        cornerRadius = dp(radiusDp).toFloat()
        setColor(color)
    }

    fun tint(color: Int, alpha: Int) = (color and 0x00FFFFFF) or (alpha shl 24)

    fun ripple(): RippleDrawable =
        RippleDrawable(ColorStateList.valueOf(if (dark) 0x22FFFFFF else 0x14000000), null, GradientDrawable().apply { setColor(Color.WHITE) })

    /** עמוד בסיסי: עמודה נגללת, ואופציונלית כפתור צף (+) */
    class Page(val root: FrameLayout, val column: LinearLayout)

    fun page(): Page {
        val column = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = dir
            setPadding(dp(16), dp(20), dp(16), dp(100))
        }
        val root = FrameLayout(a).apply { setBackgroundColor(bg) }
        root.addView(ScrollView(a).apply { addView(column) },
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        a.setContentView(root)
        return Page(root, column)
    }

    /** כותרת מסך: חץ חזרה (אופציונלי), כותרת ותת-כותרת */
    fun header(col: LinearLayout, title: String, subtitle: String?, back: Boolean) {
        val row = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(14))
        }
        if (back) {
            row.addView(ImageView(a).apply {
                // חזרה: במסך מימין לשמאל החץ מצביע ימינה
                setImageResource(if (english) R.drawable.ic_chevron_left else R.drawable.ic_chevron_right)
                setColorFilter(textMain, PorterDuff.Mode.SRC_IN)
                scaleType = ImageView.ScaleType.CENTER
                background = rounded(surface, 14)
                isClickable = true
                setOnClickListener { a.finish() }
            }, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginEnd = dp(12) })
        }
        val texts = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(TextView(a).apply {
            text = title
            textSize = 26f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(textMain)
        })
        if (subtitle != null) texts.addView(TextView(a).apply {
            text = subtitle
            textSize = 14f
            setTextColor(textSub)
            setPadding(0, dp(2), 0, 0)
        })
        row.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        col.addView(row)
    }

    fun section(col: LinearLayout, title: String) {
        col.addView(TextView(a).apply {
            text = title
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(accent)
            setPadding(dp(8), dp(22), dp(8), dp(8))
        })
    }

    fun card(col: LinearLayout): LinearLayout {
        val c = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(surface, 18)
            clipToOutline = true
        }
        col.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return c
    }

    /** מוסיף שורה לכרטיס, עם קו מפריד בין שורות */
    fun add(card: LinearLayout, v: View) {
        if (card.childCount > 0) card.addView(View(a).apply { setBackgroundColor(divider) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1).apply { setMargins(dp(16), 0, dp(16), 0) })
        card.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    fun titleBlock(title: String, subtitle: String?, color: Int = textMain, maxSubLines: Int = 2) = LinearLayout(a).apply {
        orientation = LinearLayout.VERTICAL
        addView(TextView(a).apply {
            text = title
            textSize = 16f
            setTextColor(color)
            maxLines = 2
        })
        if (subtitle != null) addView(TextView(a).apply {
            text = subtitle
            textSize = 13f
            setTextColor(textSub)
            maxLines = maxSubLines
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(0, dp(2), 0, 0)
        })
    }

    /** ריבוע מעוגל צבעוני עם אייקון */
    fun iconTile(icon: Int, color: Int, sizeDp: Int = 38) = ImageView(a).apply {
        setImageResource(icon)
        setColorFilter(color, PorterDuff.Mode.SRC_IN)
        scaleType = ImageView.ScaleType.CENTER
        background = rounded(tint(color, 0x22), 10)
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)).apply { marginEnd = dp(12) }
    }

    fun navRow(icon: Int?, title: String, subtitle: String?, danger: Boolean = false, onTap: () -> Unit) =
        LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(13), dp(12), dp(13))
            background = ripple()
            isClickable = true
            setOnClickListener { onTap() }
            if (icon != null) addView(iconTile(icon, if (danger) red else accent))
            addView(titleBlock(title, subtitle, if (danger) red else textMain),
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(ImageView(a).apply {
                setImageResource(if (english) R.drawable.ic_chevron_right else R.drawable.ic_chevron_left)
                setColorFilter(textSub, PorterDuff.Mode.SRC_IN)
            })
        }

    fun switchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit): Pair<LinearLayout, Switch> {
        val sw = Switch(a).apply {
            isChecked = checked
            thumbTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(Color.WHITE, if (dark) 0xFFB0B2B8.toInt() else Color.WHITE)
            )
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(accent, if (dark) 0xFF4A4B52.toInt() else 0xFFC9CCD3.toInt())
            )
            setOnCheckedChangeListener { _, c -> onChange(c) }
        }
        val row = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(13), dp(12), dp(13))
            background = ripple()
            isClickable = true
            setOnClickListener { sw.toggle() }
            addView(titleBlock(title, subtitle), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(sw)
        }
        return row to sw
    }

    fun <T> segmented(title: String, options: List<Pair<String, T>>, selected: T, onPick: (T) -> Unit): LinearLayout {
        val box = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(13), dp(16), dp(14))
            addView(titleBlock(title, null))
        }
        val group = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(3), dp(3), dp(3), dp(3))
            background = rounded(field, 12)
        }
        val views = mutableListOf<TextView>()
        fun paint(sel: T) {
            views.forEachIndexed { i, tv ->
                val on = options[i].second == sel
                tv.setTextColor(if (on) Color.WHITE else textMain)
                tv.background = if (on) rounded(accent, 10) else null
            }
        }
        options.forEach { (label, value) ->
            val tv = TextView(a).apply {
                text = label
                gravity = Gravity.CENTER
                textSize = 14f
                setPadding(0, dp(8), 0, dp(8))
                isClickable = true
                setOnClickListener {
                    paint(value)
                    onPick(value)
                }
            }
            views += tv
            group.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        paint(selected)
        box.addView(group, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(10) })
        return box
    }

    class Swatch<T>(val value: T, val label: String, val fill: Int, val fill2: Int? = null, val ring: Int? = null)

    /** בחירת צבע: עיגולים צבעוניים עם תווית, שורה נגללת */
    fun <T> swatches(title: String, items: List<Swatch<T>>, selected: T, onPick: (T) -> Unit): LinearLayout {
        val box = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(13), dp(16), dp(12))
            addView(titleBlock(title, null))
        }
        val row = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = dir }
        val rings = mutableListOf<View>()
        items.forEach { sw ->
            val cell = LinearLayout(a).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(6), dp(8), dp(6), 0)
                isClickable = true
            }
            val frame = FrameLayout(a)
            val ring = View(a).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.TRANSPARENT)
                    setStroke(dp(2), if (sw.value == selected) accent else Color.TRANSPARENT)
                }
                tag = sw.value
            }
            rings += ring
            frame.addView(ring, FrameLayout.LayoutParams(dp(46), dp(46)))
            frame.addView(View(a).apply {
                background = (if (sw.fill2 != null) GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(sw.fill, sw.fill2))
                else GradientDrawable()).apply {
                    shape = GradientDrawable.OVAL
                    if (sw.fill2 == null) setColor(sw.fill)
                    setStroke(dp(3), sw.ring ?: tint(textMain, 0x22))
                }
            }, FrameLayout.LayoutParams(dp(36), dp(36), Gravity.CENTER))
            cell.addView(frame, LinearLayout.LayoutParams(dp(46), dp(46)))
            cell.addView(TextView(a).apply {
                text = sw.label
                textSize = 12f
                setTextColor(textSub)
                gravity = Gravity.CENTER
                setPadding(0, dp(4), 0, 0)
            })
            cell.setOnClickListener {
                rings.forEach { r ->
                    (r.background as GradientDrawable).setStroke(dp(2), if (r.tag == sw.value) accent else Color.TRANSPARENT)
                }
                onPick(sw.value)
            }
            row.addView(cell)
        }
        box.addView(android.widget.HorizontalScrollView(a).apply {
            isHorizontalScrollBarEnabled = false
            layoutDirection = dir
            addView(row)
        })
        return box
    }

    /** מצב ריק: אייקון גדול בעיגול, כותרת והסבר */
    fun emptyState(col: LinearLayout, icon: Int, title: String, text: String) {
        col.addView(LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(48), dp(24), dp(24))
            addView(ImageView(a).apply {
                setImageResource(icon)
                setColorFilter(accent, PorterDuff.Mode.SRC_IN)
                scaleType = ImageView.ScaleType.FIT_CENTER
                setPadding(dp(22), dp(22), dp(22), dp(22))
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(tint(accent, 0x22)) }
            }, LinearLayout.LayoutParams(dp(96), dp(96)))
            addView(TextView(a).apply {
                this.text = title
                textSize = 18f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(textMain)
                gravity = Gravity.CENTER
                setPadding(0, dp(18), 0, dp(6))
            })
            addView(TextView(a).apply {
                this.text = text
                textSize = 14f
                setTextColor(textSub)
                gravity = Gravity.CENTER
            })
        })
    }

    /** כפתור צף עגול (+) בפינה התחתונה */
    fun fab(page: Page, onTap: () -> Unit) {
        page.root.addView(ImageView(a).apply {
            setImageResource(R.drawable.ic_plus)
            setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN)
            scaleType = ImageView.ScaleType.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(accent) }
            elevation = dp(8).toFloat()
            isClickable = true
            setOnClickListener { onTap() }
        }, FrameLayout.LayoutParams(dp(60), dp(60), Gravity.BOTTOM or (if (english) Gravity.RIGHT else Gravity.LEFT))
            .apply { setMargins(dp(22), dp(22), dp(22), dp(26)) })
    }

    // ---------- חלונות ----------

    class FieldSpec(val label: String, val hint: String, val initial: String, val multiline: Boolean = false, val password: Boolean = false)

    private fun sheet(): Pair<Dialog, LinearLayout> {
        val d = Dialog(a)
        val box = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = dir
            setPadding(dp(20), dp(12), dp(20), dp(20))
            background = GradientDrawable().apply {
                setColor(surface)
                cornerRadii = floatArrayOf(dp(24).toFloat(), dp(24).toFloat(), dp(24).toFloat(), dp(24).toFloat(), 0f, 0f, 0f, 0f)
            }
        }
        // פס אחיזה קטן למעלה
        box.addView(View(a).apply { background = rounded(textSub, 3) },
            LinearLayout.LayoutParams(dp(40), dp(5)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(14) })
        d.setContentView(box)
        d.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.BOTTOM)
            setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }
        return d to box
    }

    private fun button(label: String, filled: Boolean, color: Int, onTap: () -> Unit) = TextView(a).apply {
        text = label
        gravity = Gravity.CENTER
        textSize = 15f
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(if (filled) Color.WHITE else color)
        background = if (filled) rounded(color, 14) else rounded(tint(color, 0x18), 14)
        setPadding(dp(12), dp(13), dp(12), dp(13))
        isClickable = true
        setOnClickListener { onTap() }
    }

    /**
     * חלון טופס שעולה מלמטה: שדות עם תוויות, כפתור שמירה, ואופציונלית מחיקה.
     * secure = שדות פרטיים (המקלדת לא לומדת מהם ולא מציעה בהם מילים).
     */
    fun formSheet(
        title: String, fields: List<FieldSpec>, secure: Boolean,
        onDelete: (() -> Unit)?, saveLabel: String? = null, note: String? = null, errorText: String? = null,
        onSave: (List<String>) -> Boolean
    ) {
        val (d, box) = sheet()
        box.addView(TextView(a).apply {
            text = title
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(textMain)
            setPadding(0, 0, 0, dp(8))
        })
        val edits = fields.map { f ->
            box.addView(TextView(a).apply {
                text = f.label
                textSize = 13f
                setTextColor(textSub)
                setPadding(dp(4), dp(10), dp(4), dp(6))
            })
            EditText(a).apply {
                hint = f.hint
                setText(f.initial)
                setTextColor(textMain)
                setHintTextColor(textSub)
                textSize = 16f
                background = rounded(field, 14)
                setPadding(dp(14), dp(12), dp(14), dp(12))
                inputType = if (f.password) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                else InputType.TYPE_CLASS_TEXT or
                    (if (f.multiline) InputType.TYPE_TEXT_FLAG_MULTI_LINE else 0) or
                    (if (secure) InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS else 0)
                if (f.multiline) { minLines = 2; maxLines = 5; gravity = Gravity.TOP or Gravity.START }
                textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            }.also { box.addView(it, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)) }
        }
        if (note != null) box.addView(TextView(a).apply {
            text = note
            textSize = 13f
            setTextColor(textSub)
            setPadding(dp(4), dp(10), dp(4), 0)
        })
        val err = TextView(a).apply { textSize = 13f; setTextColor(red); setPadding(dp(4), dp(8), dp(4), 0); visibility = View.GONE }
        box.addView(err)
        val buttons = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(18), 0, 0) }
        if (onDelete != null) {
            buttons.addView(button(t("מחיקה", "Delete"), false, red) {
                d.dismiss()
                confirm(t("למחוק?", "Delete?"), t("מחק", "Delete")) { onDelete() }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(10) })
        }
        buttons.addView(button(saveLabel ?: t("שמירה", "Save"), true, accent) {
            val values = edits.map { it.text.toString() }
            if (onSave(values)) d.dismiss() else {
                err.text = errorText ?: t("צריך למלא את כל השדות", "Please fill in all fields")
                err.visibility = View.VISIBLE
            }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 2f))
        box.addView(buttons)
        d.show()
    }

    /** חלון אישור עם כפתור פעולה (אדום) וביטול */
    fun confirm(message: String, action: String, danger: Boolean = true, onConfirm: () -> Unit) {
        val (d, box) = sheet()
        box.addView(TextView(a).apply {
            text = message
            textSize = 17f
            setTextColor(textMain)
            setPadding(dp(4), 0, dp(4), dp(18))
        })
        val buttons = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.addView(button(t("ביטול", "Cancel"), false, textSub) { d.dismiss() },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(10) })
        buttons.addView(button(action, true, if (danger) red else accent) {
            d.dismiss()
            onConfirm()
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        box.addView(buttons)
        d.show()
    }
}
