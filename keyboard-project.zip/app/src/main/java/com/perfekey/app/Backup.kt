package com.perfekey.app

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * גיבוי ושחזור: הגדרות, קיצורים, מילים שנלמדו, סטטיסטיקה ולוח ההעתקות לקובץ אחד.
 * הכספת נכללת רק אם בוחרים סיסמה, ואז היא מוצפנת בסיסמה הזאת (AES-256).
 */
object Backup {

    private val FILES = listOf("settings", "shortcuts", "predictor", "stats", "clipboard")
    private const val ITERATIONS = 120_000

    class ParsedBackup(val json: JSONObject) {
        val hasVault get() = json.has("vault")
    }

    fun export(context: Context, vaultPassword: String?): String {
        val root = JSONObject()
            .put("app", "Perfekey")
            .put("version", 1)
            .put("created", System.currentTimeMillis())
        val prefs = JSONObject()
        for (name in FILES) prefs.put(name, prefsToJson(context.getSharedPreferences(name, Context.MODE_PRIVATE)))
        root.put("prefs", prefs)
        if (!vaultPassword.isNullOrEmpty()) {
            val items = JSONArray()
            Vault.load(context).forEach { items.put(JSONObject().put("label", it.label).put("value", it.value)) }
            root.put("vault", encrypt(items.toString(), vaultPassword))
        }
        return root.toString(2)
    }

    /** קורא קובץ גיבוי; זורק שגיאה אם זה לא קובץ של Perfekey */
    fun parse(text: String): ParsedBackup {
        val json = JSONObject(text)
        require(json.optString("app") == "Perfekey") { "not a Perfekey backup" }
        return ParsedBackup(json)
    }

    /**
     * משחזר מהגיבוי. אם יש בו כספת והסיסמה ריקה, הכספת לא משוחזרת.
     * מחזיר false אם הסיסמה לכספת שגויה (ואז שום דבר לא נכתב).
     */
    fun restore(context: Context, backup: ParsedBackup, vaultPassword: String?): Boolean {
        var vaultItems: List<Vault.Item>? = null
        if (backup.hasVault && !vaultPassword.isNullOrEmpty()) {
            val plain = try { decrypt(backup.json.getJSONObject("vault"), vaultPassword) } catch (_: Exception) { return false }
            val arr = JSONArray(plain)
            vaultItems = List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                Vault.Item(System.currentTimeMillis() + i, o.getString("label"), o.getString("value"))
            }
        }
        val prefs = backup.json.optJSONObject("prefs") ?: JSONObject()
        for (name in FILES) {
            val data = prefs.optJSONObject(name) ?: continue
            jsonToPrefs(data, context.getSharedPreferences(name, Context.MODE_PRIVATE))
        }
        vaultItems?.let { Vault.save(context, it) }
        return true
    }

    // ---------- SharedPreferences <-> JSON ----------

    private fun prefsToJson(sp: SharedPreferences): JSONObject {
        val o = JSONObject()
        for ((k, v) in sp.all) {
            val e = when (v) {
                is Boolean -> JSONObject().put("t", "b").put("v", v)
                is Int -> JSONObject().put("t", "i").put("v", v)
                is Long -> JSONObject().put("t", "l").put("v", v)
                is Float -> JSONObject().put("t", "f").put("v", v.toDouble())
                is String -> JSONObject().put("t", "s").put("v", v)
                is Set<*> -> JSONObject().put("t", "ss").put("v", JSONArray(v.map { it.toString() }))
                else -> null
            }
            if (e != null) o.put(k, e)
        }
        return o
    }

    private fun jsonToPrefs(o: JSONObject, sp: SharedPreferences) {
        val ed = sp.edit().clear()
        o.keys().forEach { k ->
            val e = o.getJSONObject(k)
            when (e.getString("t")) {
                "b" -> ed.putBoolean(k, e.getBoolean("v"))
                "i" -> ed.putInt(k, e.getInt("v"))
                "l" -> ed.putLong(k, e.getLong("v"))
                "f" -> ed.putFloat(k, e.getDouble("v").toFloat())
                "s" -> ed.putString(k, e.getString("v"))
                "ss" -> {
                    val arr = e.getJSONArray("v")
                    ed.putStringSet(k, (0 until arr.length()).map { arr.getString(it) }.toSet())
                }
            }
        }
        ed.commit()
    }

    // ---------- הצפנה בסיסמה ----------

    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)
    private fun unb64(s: String) = Base64.decode(s, Base64.NO_WRAP)

    private fun deriveKey(password: String, salt: ByteArray, kdf: String): SecretKeySpec {
        val spec = PBEKeySpec(password.toCharArray(), salt, ITERATIONS, 256)
        val bytes = SecretKeyFactory.getInstance(kdf).generateSecret(spec).encoded
        return SecretKeySpec(bytes, "AES")
    }

    private fun bestKdf(): String = try {
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256"); "PBKDF2WithHmacSHA256"
    } catch (_: Exception) {
        "PBKDF2WithHmacSHA1"
    }

    private fun encrypt(plain: String, password: String): JSONObject {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val kdf = bestKdf()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, deriveKey(password, salt, kdf))
        val ct = cipher.doFinal(plain.toByteArray(Charsets.UTF_8))
        return JSONObject().put("kdf", kdf).put("salt", b64(salt)).put("iv", b64(cipher.iv)).put("data", b64(ct))
    }

    private fun decrypt(o: JSONObject, password: String): String {
        val key = deriveKey(password, unb64(o.getString("salt")), o.optString("kdf", "PBKDF2WithHmacSHA256"))
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, unb64(o.getString("iv"))))
        return String(cipher.doFinal(unb64(o.getString("data"))), Charsets.UTF_8)
    }
}
