package com.perfekey.app

import android.content.Context

/** ערכות צבעים למקלדת וצבעי הדגשה */
object Themes {

    class Colors(
        val bg: Int, val key: Int, val special: Int, val num: Int, val pressed: Int, val text: Int,
        val dark: Boolean
    )

    /** (מזהה, שם בעברית, שם באנגלית) */
    val themes = listOf(
        Triple("auto", "לפי הטלפון", "System"),
        Triple("light", "בהיר", "Light"),
        Triple("dark", "כהה", "Dark"),
        Triple("black", "שחור", "Black"),
        Triple("midnight", "כחול לילה", "Midnight"),
        Triple("sand", "חול", "Sand")
    )

    private val palettes = mapOf(
        "light" to Colors(0xFFD6D9DE.toInt(), 0xFFEEEFF2.toInt(), 0xFFB9BDC5.toInt(), 0xFFCFD2D8.toInt(), 0xFFA3A8B1.toInt(), 0xFF1A1A1A.toInt(), false),
        "dark" to Colors(0xFF1B1B1F.toInt(), 0xFF424349.toInt(), 0xFF2E2F34.toInt(), 0xFF36373C.toInt(), 0xFF60616A.toInt(), 0xFFF2F2F2.toInt(), true),
        "black" to Colors(0xFF000000.toInt(), 0xFF1C1C1E.toInt(), 0xFF2C2C2E.toInt(), 0xFF141416.toInt(), 0xFF3A3A3C.toInt(), 0xFFF2F2F2.toInt(), true),
        "midnight" to Colors(0xFF0F1A2E.toInt(), 0xFF1E2D4A.toInt(), 0xFF152238.toInt(), 0xFF182640.toInt(), 0xFF2B3F63.toInt(), 0xFFEAF0FF.toInt(), true),
        "sand" to Colors(0xFFE8E0D2.toInt(), 0xFFF7F2E9.toInt(), 0xFFD3C8B4.toInt(), 0xFFDDD3C2.toInt(), 0xFFC2B59E.toInt(), 0xFF2B2418.toInt(), false)
    )

    /** (מזהה, צבע הדגשה, צבע מקש האנטר) */
    val accents = listOf(
        Triple("classic", 0xFF3D7BFD.toInt(), 0xFF2F9E6E.toInt()),
        Triple("blue", 0xFF3D7BFD.toInt(), 0xFF3D7BFD.toInt()),
        Triple("purple", 0xFF8B5CF6.toInt(), 0xFF8B5CF6.toInt()),
        Triple("green", 0xFF22A06B.toInt(), 0xFF22A06B.toInt()),
        Triple("teal", 0xFF14B8A6.toInt(), 0xFF14B8A6.toInt()),
        Triple("orange", 0xFFF97316.toInt(), 0xFFF97316.toInt()),
        Triple("pink", 0xFFEC4899.toInt(), 0xFFEC4899.toInt()),
        Triple("red", 0xFFE5484D.toInt(), 0xFFE5484D.toInt())
    )

    fun colors(themeKey: String, systemDark: Boolean): Colors {
        val k = if (themeKey == "auto" || themeKey !in palettes) (if (systemDark) "dark" else "light") else themeKey
        return palettes.getValue(k)
    }

    fun previewColors(themeKey: String) = palettes[themeKey]

    fun accent(key: String) = (accents.firstOrNull { it.first == key } ?: accents[0]).second
    fun enter(key: String) = (accents.firstOrNull { it.first == key } ?: accents[0]).third

    fun accentOf(ctx: Context) =
        accent(ctx.getSharedPreferences("settings", Context.MODE_PRIVATE).getString("accent", "classic") ?: "classic")
}
