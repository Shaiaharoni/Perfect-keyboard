package com.perfekey.app

import android.app.Activity
import android.graphics.PorterDuff
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** סידור סרגל הכלים: סדר הכפתורים ואילו מהם מוצגים */
class ToolbarActivity : Activity() {

    private lateinit var ui: UiKit
    private lateinit var order: MutableList<String>
    private lateinit var hidden: MutableSet<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        ui = UiKit(this)
        ui.applyTheme()
        super.onCreate(savedInstanceState)
        ui.styleWindow()
        order = Themes.toolOrder(this).toMutableList()
        hidden = Themes.hiddenTools(this).toMutableSet()
        render()
    }

    private fun save() {
        getSharedPreferences("settings", MODE_PRIVATE).edit()
            .putString("toolOrder", order.joinToString(","))
            .putStringSet("toolHidden", hidden)
            .apply()
    }

    private fun icon(id: String) = when (id) {
        "settings" -> R.drawable.ic_settings
        "vault" -> R.drawable.ic_lock
        "clipboard" -> R.drawable.ic_clipboard
        "incognito" -> R.drawable.ic_incognito
        else -> R.drawable.ic_one_hand
    }

    private fun name(id: String): String {
        val t = Themes.tools.first { it[0] == id }
        return ui.t(t[2], t[3])
    }

    private fun render() {
        val page = ui.page()
        val col = page.column
        ui.header(col, ui.t("סרגל הכלים", "Toolbar"),
            ui.t("הסדר והכפתורים שמופיעים מעל המקלדת", "Order and buttons shown above the keyboard"), back = true)

        // תצוגה מקדימה של הסרגל, כמו שהוא ייראה במקלדת
        ui.section(col, ui.t("תצוגה מקדימה", "Preview"))
        val preview = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = android.view.View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER_VERTICAL
            setPadding(ui.dp(8), ui.dp(12), ui.dp(8), ui.dp(12))
            background = ui.rounded(ui.surface, 18)
        }
        for (id in order.reversed()) {
            if (id in hidden) continue
            preview.addView(ImageView(this).apply {
                setImageResource(icon(id))
                setColorFilter(ui.textMain, PorterDuff.Mode.SRC_IN)
                scaleType = ImageView.ScaleType.CENTER
            }, LinearLayout.LayoutParams(0, ui.dp(32), 1f))
        }
        col.addView(preview, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        ui.section(col, ui.t("כפתורים", "Buttons"))
        val card = ui.card(col)
        order.forEachIndexed { i, id ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(ui.dp(16), ui.dp(10), ui.dp(8), ui.dp(10))
            }
            val visible = id !in hidden
            row.addView(ui.iconTile(icon(id), if (visible) ui.accent else ui.textSub))
            row.addView(TextView(this).apply {
                text = name(id)
                textSize = 16f
                setTextColor(if (visible) ui.textMain else ui.textSub)
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(arrow(R.drawable.ic_chevron_up, if (i > 0) 255 else 60) {
                if (i > 0) { order.add(i - 1, order.removeAt(i)); save(); render() }
            })
            row.addView(arrow(R.drawable.ic_chevron_down, if (i < order.size - 1) 255 else 60) {
                if (i < order.size - 1) { order.add(i + 1, order.removeAt(i)); save(); render() }
            })
            // הצגה/הסתרה (את ההגדרות אי אפשר להסתיר, אחרת לא תהיה דרך לחזור לכאן)
            if (id != "settings") {
                val (_, sw) = ui.switchRow("", null, visible) { on ->
                    if (on) hidden.remove(id) else hidden.add(id)
                    save()
                    render()
                }
                (sw.parent as? ViewGroup)?.removeView(sw)
                row.addView(sw)
            } else {
                row.addView(android.view.View(this), LinearLayout.LayoutParams(ui.dp(52), 1))
            }
            ui.add(card, row)
        }
        col.addView(TextView(this).apply {
            text = ui.t("הראשון ברשימה מופיע הכי ימני. את כפתור ההגדרות אי אפשר להסתיר.",
                "The first item appears rightmost. The settings button can't be hidden.")
            textSize = 13f
            setTextColor(ui.textSub)
            setPadding(ui.dp(8), ui.dp(12), ui.dp(8), 0)
        })
        col.addView(TextView(this).apply {
            text = ui.t("איפוס לסדר המקורי", "Reset to default")
            textSize = 15f
            setTextColor(ui.accent)
            gravity = Gravity.CENTER
            setPadding(0, ui.dp(14), 0, ui.dp(14))
            background = ui.rounded(ui.surface, 18)
            isClickable = true
            setOnClickListener {
                order = Themes.tools.map { it[0] }.toMutableList()
                hidden.clear()
                save()
                render()
            }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = ui.dp(20) })
    }

    private fun arrow(icon: Int, alpha: Int, onTap: () -> Unit) = ImageView(this).apply {
        if (icon != 0) setImageResource(icon)
        setColorFilter(ui.textMain, PorterDuff.Mode.SRC_IN)
        imageAlpha = alpha
        scaleType = ImageView.ScaleType.CENTER
        background = ui.ripple()
        isClickable = alpha == 255
        setOnClickListener { onTap() }
        layoutParams = LinearLayout.LayoutParams(ui.dp(40), ui.dp(40))
    }
}
