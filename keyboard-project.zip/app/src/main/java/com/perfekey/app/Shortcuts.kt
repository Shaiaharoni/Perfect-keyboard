package com.perfekey.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * קיצורים ומילים שמורות: קיצור שהופך לטקסט מלא (למשל "טל" ← מספר טלפון).
 * לאותו קיצור יכולים להיות כמה טקסטים; אז הם מוצעים בשורת ההצעות במקום החלפה אוטומטית.
 */
object Shortcuts {
    class Entry(var key: String, var value: String)

    fun loadEntries(context: Context): MutableList<Entry> {
        val prefs = context.getSharedPreferences("shortcuts", Context.MODE_PRIVATE)
        val list = mutableListOf<Entry>()
        try {
            val raw = prefs.getString("list", null)
            if (raw != null) {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list += Entry(o.getString("k"), o.getString("v"))
                }
            } else {
                // מעבר מהפורמט הישן (קיצור אחד לכל מילה)
                val o = JSONObject(prefs.getString("map", "{}") ?: "{}")
                o.keys().forEach { k -> list += Entry(k, o.getString(k)) }
            }
        } catch (_: Exception) {
        }
        return list
    }

    fun saveEntries(context: Context, list: List<Entry>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("k", it.key).put("v", it.value)) }
        context.getSharedPreferences("shortcuts", Context.MODE_PRIVATE).edit()
            .putString("list", arr.toString()).remove("map").apply()
    }

    /** קיצור ← כל הטקסטים שלו */
    fun load(context: Context): Map<String, List<String>> =
        loadEntries(context).groupBy({ it.key.lowercase() }, { it.value })
}
