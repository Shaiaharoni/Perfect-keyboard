package com.perfekey.app

import android.content.Context
import kotlin.math.ln

/**
 * חיזוי מילים ואותיות:
 * - מילון בסיס (assets/dict.txt): כ-200 אלף מילים בעברית ו-60 אלף באנגלית, עם שכיחות ודירוג
 * - מילים שהמשתמש מקליד בפועל, וצמדי מילים (מה בא אחרי מה)
 * - מודל "האות הבאה": לפי מה שכבר הוקלד במילה, כמה סביר שכל אות תגיע עכשיו
 *
 * המילון שמור במערכים ממוינים (ולא ב-HashMap) כדי לחסוך זיכרון, ונטען ברקע כדי שהמקלדת תיפתח מהר.
 */
class WordPredictor(context: Context) {

    companion object {
        /** המופע שהמקלדת משתמשת בו כרגע (כדי שמסך ההגדרות יוכל לאפס אותו) */
        @Volatile
        var instance: WordPredictor? = null

        fun clearSaved(context: Context) {
            context.getSharedPreferences("predictor", Context.MODE_PRIVATE).edit().clear().apply()
        }

        private const val HE_SIZE = 200_000
        private const val EN_SIZE = 60_000
        /** תיקון אוטומטי מציע רק מילים נפוצות מספיק (כדי לא "לתקן" למילים נדירות או לשגיאות שבמילון) */
        private const val CORRECTION_RANK_LIMIT = 100_000
    }

    class LetterProbs(val map: Map<Char, Double>, val floor: Double) {
        fun of(c: Char): Double = map[c] ?: floor
    }

    /** המילון הבסיסי: מערכים מקבילים, ממוינים לפי המילה */
    private class Dict(val words: Array<String>, val counts: FloatArray, val ranks: IntArray) {
        fun index(w: String): Int {
            var lo = 0
            var hi = words.size - 1
            while (lo <= hi) {
                val mid = (lo + hi) ushr 1
                val c = words[mid].compareTo(w)
                if (c == 0) return mid
                if (c < 0) lo = mid + 1 else hi = mid - 1
            }
            return -1
        }

        fun lowerBound(pre: String): Int {
            var lo = 0
            var hi = words.size
            while (lo < hi) {
                val mid = (lo + hi) ushr 1
                if (words[mid] < pre) lo = mid + 1 else hi = mid
            }
            return lo
        }
    }

    private val prefs = context.getSharedPreferences("predictor", Context.MODE_PRIVATE)
    @Volatile private var dict = Dict(emptyArray(), FloatArray(0), IntArray(0))
    @Volatile private var learnedLetterWeight = 1.0
    private val learned = HashMap<String, Int>()
    private val bigrams = HashMap<String, HashMap<String, Int>>()
    private var dirty = 0

    private var cachePrefix: String? = null
    private var cacheProbs = LetterProbs(emptyMap(), 1.0)
    private var loader: Thread? = null

    init {
        prefs.getString("learned", null)?.lineSequence()?.forEach { line ->
            val p = line.split('\t')
            if (p.size == 2) p[1].toIntOrNull()?.let { learned[p[0]] = it }
        }
        prefs.getString("bigrams", null)?.lineSequence()?.forEach { line ->
            val p = line.split('\t')
            if (p.size == 3) p[2].toIntOrNull()?.let { bigrams.getOrPut(p[0]) { HashMap() }[p[1]] = it }
        }
        // טעינת המילון ברקע
        val appContext = context.applicationContext
        loader = Thread {
            try {
                val words = ArrayList<String>(262_000)
                val counts = ArrayList<Float>(262_000)
                val ranks = ArrayList<Int>(262_000)
                appContext.assets.open("dict.txt").bufferedReader(Charsets.UTF_8).forEachLine { line ->
                    val a = line.indexOf('\t')
                    val b = line.indexOf('\t', a + 1)
                    if (a > 0 && b > a) {
                        words += line.substring(0, a)
                        counts += line.substring(a + 1, b).toFloatOrNull() ?: 1f
                        ranks += line.substring(b + 1).toIntOrNull() ?: Int.MAX_VALUE
                    }
                }
                val d = Dict(words.toTypedArray(), counts.toFloatArray(), ranks.toIntArray())
                // משקל של מילה שלמדנו מהמשתמש במודל האותיות: כמו מילה שכיחה למדי
                val sortedCounts = d.counts.copyOf().also { it.sort() }
                if (sortedCounts.isNotEmpty()) {
                    learnedLetterWeight = sortedCounts[(sortedCounts.size * 0.98).toInt().coerceAtMost(sortedCounts.size - 1)].toDouble()
                }
                dict = d
                cachePrefix = null
            } catch (_: Exception) {
            }
        }.apply { priority = Thread.MIN_PRIORITY; start() }
    }

    /** למסכים שיוצרים מופע חדש ומיד צריכים לדעת מה במילון (למשל "מילים שלימדת אותי") */
    fun waitUntilLoaded(timeoutMs: Long = 4000) {
        try { loader?.join(timeoutMs) } catch (_: InterruptedException) {}
    }

    // ---------- גישה למילון ----------

    private fun isHebrew(w: String) = w.isNotEmpty() && w[0] in '\u0590'..'\u05FF'

    /** 1..1000 לפי הדירוג בתוך השפה (0 = לא במילון) */
    private fun baseScore(w: String): Int {
        val d = dict
        val i = d.index(w)
        if (i < 0) return 0
        val n = if (isHebrew(w)) HE_SIZE else EN_SIZE
        return 1 + ((n - d.ranks[i]).coerceAtLeast(0).toLong() * 999L / n).toInt()
    }

    private fun baseCount(w: String): Double {
        val d = dict
        val i = d.index(w)
        return if (i < 0) 0.0 else d.counts[i].toDouble()
    }

    private fun inBase(w: String) = dict.index(w) >= 0

    /** עובר על כל מילות הבסיס שמתחילות ב-pre */
    private inline fun forEachBaseWithPrefix(pre: String, f: (String) -> Unit) {
        val d = dict
        var i = d.lowerBound(pre)
        while (i < d.words.size && d.words[i].startsWith(pre)) {
            f(d.words[i])
            i++
        }
    }

    // ---------- הצעות ----------

    fun suggest(prefix: String, prev: String?, limit: Int = 3): List<String> {
        val pre = prefix.lowercase()
        val next = prev?.lowercase()?.let { bigrams[it] }
        val scores = HashMap<String, Double>()

        fun consider(w: String) {
            if (!w.startsWith(pre) || w == pre) return
            val b = baseScore(w)
            val l = learned[w] ?: 0
            val bg = next?.get(w) ?: 0
            // מילה שלא במילון צריכה להופיע לפחות פעמיים לפני שמציעים אותה (סינון שגיאות הקלדה)
            if (b == 0 && l < 2 && bg < 2) return
            scores[w] = b + l * 400.0 + bg * 3000.0
        }

        if (pre.isEmpty()) {
            next?.keys?.forEach { consider(it) }
        } else {
            forEachBaseWithPrefix(pre) { consider(it) }
            learned.keys.forEach { consider(it) }
        }
        return scores.entries.sortedByDescending { it.value }.take(limit).map { it.key }
    }

    /** ההסתברות של כל אות להיות האות הבאה, בהינתן תחילת המילה */
    fun nextLetterProbs(prefix: String): LetterProbs {
        val pre = prefix.lowercase()
        if (pre == cachePrefix) return cacheProbs

        val weights = HashMap<Char, Double>()
        var total = 0.0
        fun add(w: String, weight: Double) {
            if (w.length > pre.length && w.startsWith(pre)) {
                val c = w[pre.length]
                weights[c] = (weights[c] ?: 0.0) + weight
                total += weight
            }
        }
        // בתחילת מילה זה עובר על כל המילון: מוגבל למילים הנפוצות כדי שיהיה מהיר
        val d = dict
        var i = d.lowerBound(pre)
        while (i < d.words.size && d.words[i].startsWith(pre)) {
            if (pre.isNotEmpty() || d.ranks[i] < 30_000) {
                val w = d.words[i]
                add(w, d.counts[i] + (learned[w] ?: 0) * learnedLetterWeight)
            }
            i++
        }
        for ((w, c) in learned) {
            if (c >= 2 && !inBase(w)) add(w, c * learnedLetterWeight)
        }

        val result = if (total <= 0.0) {
            LetterProbs(emptyMap(), 1.0)   // אין מידע: רק מיקום האצבע קובע
        } else {
            val alpha = total * 0.02       // החלקה: גם אות "לא צפויה" תמיד אפשרית
            val denom = total + alpha * 30
            LetterProbs(weights.mapValues { (it.value + alpha) / denom }, alpha / denom)
        }
        cachePrefix = pre
        cacheProbs = result
        return result
    }

    // ---------- מילים מוכרות ותיקון ----------

    /**
     * מילה "מוכרת בוודאות": מהחלק הנפוץ של המילון (100 אלף הראשונות בכל שפה), או שהמשתמש לימד.
     * מילים מהזנב הנדיר של המילון יכולות להיות גם שגיאות כתיב (המילון בנוי מכתוביות),
     * ולכן עליהן עדיין מותר להציע תיקון, אבל רק למילה נפוצה בהרבה (ראו correction).
     */
    private fun knownExact(w: String): Boolean {
        if ((learned[w] ?: 0) >= 2) return true
        val d = dict
        val i = d.index(w)
        return i >= 0 && d.ranks[i] < CORRECTION_RANK_LIMIT
    }

    private val prefixLetters = "והבלמשכ"

    /**
     * האם המילה מוכרת. בעברית מתחשבים באותיות שימוש בתחילת המילה (ו, ה, ב, ל, מ, ש, כ):
     * "ובבית" מוכרת אם "בבית" מוכרת, ו"המקלדת" מוכרת גם אם רק "במקלדת" במילון (אותה מילה עם אות שימוש אחרת).
     */
    fun isKnown(word: String): Boolean {
        val w = word.lowercase()
        // עברית: אות רגילה בסוף מילה (כ, מ, נ, פ, צ) או אות סופית באמצע = כמעט תמיד שגיאה
        if (badFinalForms(w) && (learned[w] ?: 0) < 2) return false
        if (knownExact(w)) return true
        var rest = w
        repeat(2) {
            // אחרי הורדת אות השימוש צריכות להישאר לפחות 3 אותיות
            if (rest.length > 3 && rest[0] in prefixLetters) {
                rest = rest.substring(1)
                if (knownExact(rest)) return true
                // אותה מילה עם אות שימוש אחרת
                for (p in prefixLetters) if (knownExact(p + rest)) return true
            }
        }
        return false
    }

    private val finalForms = "ךםןףץ"
    private val regularOfFinal = "כמנפצ"

    private fun badFinalForms(w: String): Boolean {
        if (!isHebrew(w) || w.length < 2) return false
        if (w.last() in regularOfFinal) return true
        for (i in 0 until w.length - 1) if (w[i] in finalForms) return true
        return false
    }

    /**
     * תיקון אוטומטי: למילה לא מוכרת, מחפש מילה מוכרת במרחק שינוי אחד
     * (אות מוחלפת, חסרה, מיותרת או שתי אותיות בסדר הפוך), או חלוקה לשתי מילים.
     * החלפה במקש שכן זולה יותר, כי זו טעות הקלדה נפוצה.
     */
    fun correction(word: String, prev: String?, alphabet: String, adjacent: (Char, Char) -> Boolean): String? {
        val w = word.lowercase()
        if (w.length < 2 || isKnown(w)) return null
        val maxCost = if (w.length <= 2) 1.0 else 9.0
        val d = dict
        val cands = HashMap<String, Double>()
        // מועמד לתיקון: מילה נפוצה מספיק מהמילון, או מילה שהמשתמש לימד
        fun candidateOk(c: String): Boolean {
            if (badFinalForms(c)) return false
            val i = d.index(c)
            if (i >= 0) return d.ranks[i] < CORRECTION_RANK_LIMIT
            return (learned[c] ?: 0) >= 2
        }
        fun add(c: String, cost: Double) {
            if (cost > maxCost || c.length < 2 || !candidateOk(c)) return
            val old = cands[c]
            if (old == null || cost < old) cands[c] = cost
        }
        // אות מיותרת (זולה יותר כשזו אות כפולה, כמו "helllo")
        for (i in w.indices) add(w.removeRange(i, i + 1), if (i > 0 && w[i] == w[i - 1]) 0.8 else 1.6)
        for (i in w.indices) for (ch in alphabet) {
            if (ch != w[i]) add(w.substring(0, i) + ch + w.substring(i + 1), if (adjacent(w[i], ch)) 0.6 else 1.8)
        }
        // אות חסרה (זולה יותר כשחסרה אות כפולה, כמו "helo")
        for (i in 0..w.length) for (ch in alphabet) {
            val doubled = (i > 0 && w[i - 1] == ch) || (i < w.length && w[i] == ch)
            add(w.substring(0, i) + ch + w.substring(i), if (doubled) 0.8 else 1.4)
        }
        for (i in 0 until w.length - 1) {
            add(w.substring(0, i) + w[i + 1] + w[i] + w.substring(i + 2), 1.0)
        }
        val next = prev?.lowercase()?.let { bigrams[it] }
        fun freq(c: String) = baseCount(c) + (learned[c] ?: 0) * learnedLetterWeight + 1.0
        // המילה שהוקלדה נמצאת בזנב הנדיר של המילון: מתקנים רק אם המועמד נפוץ ממנה פי 300 לפחות
        // (מילה עם אות סופית לא נכונה היא שגיאה בוודאות, אז לא דורשים יחס)
        val typedCount = if (badFinalForms(w)) 0.0 else baseCount(w)
        fun muchMoreCommon(c: String) = typedCount <= 0.0 || freq(c) >= typedCount * 300
        cands.keys.retainAll { muchMoreCommon(it) }
        val scores = HashMap<String, Double>()
        for ((c, cost) in cands) scores[c] = ln(freq(c)) - cost * 3.0 + (next?.get(c) ?: 0) * 1.5

        // רווח חסר ("זהממש" ← "זה ממש"), או אות שנלחצה במקום רווח ("זהבממש" ← "זה ממש")
        fun common(x: String): Boolean {
            val i = d.index(x)
            return (i >= 0 && d.ranks[i] < 8_000) || (learned[x] ?: 0) >= 3
        }
        fun addSplit(a: String, b: String, cost: Double) {
            if (a.length < 2 || b.length < 2 || !common(a) || !common(b)) return
            if (typedCount > 0.0 && minOf(freq(a), freq(b)) < typedCount * 300) return
            val bonus = (bigrams[a]?.get(b) ?: 0) * 1.5
            val sc = ln(kotlin.math.sqrt(freq(a) * freq(b))) - cost * 3.0 + bonus
            val key = "$a $b"
            if (sc > (scores[key] ?: Double.NEGATIVE_INFINITY)) scores[key] = sc
        }
        if (w.length >= 4) {
            for (i in 2..w.length - 2) addSplit(w.substring(0, i), w.substring(i), 1.2)
            for (i in 2..w.length - 3) {
                if (w[i] in "בהנמצcvbnm") addSplit(w.substring(0, i), w.substring(i + 1), 1.5)
            }
        }
        return scores.maxByOrNull { it.value }?.key
    }

    // ---------- למידה ----------

    /** מצב גלישה בסתר: לא לומדים מילים חדשות */
    var paused = false

    fun learn(word: String, prev: String?) {
        if (paused) return
        val w = word.lowercase()
        if (w.length < 2) return
        learned[w] = (learned[w] ?: 0) + 1
        if (!prev.isNullOrEmpty()) {
            val m = bigrams.getOrPut(prev.lowercase()) { HashMap() }
            m[w] = (m[w] ?: 0) + 1
        }
        cachePrefix = null
        dirty++
        if (dirty >= 5) save()
    }

    /** המילים שהמשתמש מקליד הכי הרבה */
    fun topLearned(n: Int): List<Pair<String, Int>> =
        learned.entries.sortedByDescending { it.value }.take(n).map { it.key to it.value }

    fun learnedCount() = learned.size

    /** כל המילים שנלמדו, עם מספר הפעמים שהוקלדו */
    fun allLearned(): List<Pair<String, Int>> = learned.entries.map { it.key to it.value }

    /** רק מילים שהמשתמש לימד: כאלה שלא היו במילון המובנה מההתחלה */
    fun taughtWords(): List<Pair<String, Int>> =
        learned.entries.filter { !inBase(it.key) }.map { it.key to it.value }

    /** מחיקת מילה אחת מהלמידה (למשל מילה פרטית או שגיאה שנלמדה) */
    fun forget(word: String) {
        val w = word.lowercase()
        learned.remove(w)
        bigrams.remove(w)
        bigrams.values.forEach { it.remove(w) }
        cachePrefix = null
        dirty++
        save()
    }

    /** מחיקת כל מה שהמקלדת למדה מהמשתמש (המילון הבסיסי נשאר) */
    fun clearLearned() {
        learned.clear()
        bigrams.clear()
        cachePrefix = null
        dirty = 0
        prefs.edit().clear().apply()
    }

    fun save() {
        if (dirty == 0) return
        if (learned.size > 8000) {
            learned.entries.sortedBy { it.value }.take(learned.size - 6000).forEach { learned.remove(it.key) }
        }
        val l = learned.entries.joinToString("\n") { "${it.key}\t${it.value}" }
        val b = buildString {
            for ((p, m) in bigrams) for ((w, c) in m) append(p).append('\t').append(w).append('\t').append(c).append('\n')
        }
        prefs.edit().putString("learned", l).putString("bigrams", b).apply()
        dirty = 0
    }
}
