package com.perfekey.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** מסך ההגדרות של המקלדת (נפתח מהאפליקציה או מגלגל השיניים בסרגל הכלים) */
class MainActivity : Activity() {

    private lateinit var ui: UiKit
    private lateinit var prefs: SharedPreferences
    private var setupCard: LinearLayout? = null
    private var shotSwitch: Switch? = null
    private var smsSwitch: Switch? = null
    private val permRequest = 7
    private val smsRequest = 8

    private fun t(he: String, en: String) = ui.t(he, en)

    override fun onCreate(savedInstanceState: Bundle?) {
        ui = UiKit(this)
        ui.applyTheme()
        super.onCreate(savedInstanceState)
        ui.styleWindow()
        prefs = getSharedPreferences("settings", MODE_PRIVATE)
        render()

        // הגענו מהבאנר בלוח: מבקשים את ההרשאה מיד
        if (intent.getBooleanExtra("askScreenshots", false) && !hasImagePermission()) {
            requestPermissions(arrayOf(imagePermission()), permRequest)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshSetup()
    }

    private fun bool(key: String, def: Boolean) = prefs.getBoolean(key, def)
    private fun put(key: String, v: Boolean) = prefs.edit().putBoolean(key, v).apply()
    private fun putInt(key: String, v: Int) = prefs.edit().putInt(key, v).apply()

    private fun sw(card: LinearLayout, title: String, sub: String?, key: String, def: Boolean) {
        ui.add(card, ui.switchRow(title, sub, bool(key, def)) { put(key, it) }.first)
    }

    private fun seg(card: LinearLayout, title: String, key: String, options: List<Pair<String, Int>>, def: Int) {
        ui.add(card, ui.segmented(title, options, prefs.getInt(key, def)) { putInt(key, it) })
    }

    private fun render() {
        val page = ui.page()
        val col = page.column
        col.setPadding(ui.dp(16), ui.dp(28), ui.dp(16), ui.dp(40))
        header(col)

        setupCard = ui.card(col)
        refreshSetup()

        ui.section(col, t("כללי", "General"))
        ui.card(col).also { c ->
            ui.add(c, ui.segmented(t("שפת הממשק", "Interface language"),
                listOf("עברית" to "he", "English" to "en"), prefs.getString("uiLang", "he") ?: "he") {
                prefs.edit().putString("uiLang", it).apply()
                recreate()
            })
        }

        ui.section(col, t("מראה", "Appearance"))
        ui.card(col).also { c ->
            seg(c, t("גובה המקשים", "Key height"), "keyHeight",
                listOf(t("נמוך", "Low") to 46, t("בינוני", "Medium") to 54, t("גבוה", "Tall") to 62), 54)
            sw(c, t("שורת מספרים קבועה", "Number row"), t("בלעדיה המספרים במסך הסימנים", "Without it, numbers are on the symbols screen"), "numberRow", true)
        }

        ui.section(col, t("הקלדה", "Typing"))
        ui.card(col).also { c ->
            sw(c, t("רטט בלחיצה", "Vibrate on keypress"), null, "vibrate", true)
            sw(c, t("הצעות מילים", "Word suggestions"), null, "suggestions", true)
            sw(c, t("תיקון אוטומטי", "Autocorrect"), t("מחיקה אחת מיד אחרי מבטלת את התיקון", "One backspace right after undoes it"), "autocorrect", true)
            sw(c, t("הצעות אמוג'י", "Emoji suggestions"), t("למשל ❤️ אחרי \"אוהב\"", "e.g. ❤️ after \"love\""), "emojiSuggest", true)
            sw(c, t("רווח כפול מוסיף נקודה", "Double space adds a period"), null, "doubleSpace", true)
            sw(c, t("אות גדולה אוטומטית באנגלית", "Auto-capitalize in English"), null, "autoCaps", true)
            seg(c, t("הגדלה סמויה של האות הצפויה", "Smart key targets"), "smartLevel",
                listOf(t("כבוי", "Off") to 0, t("עדין", "Light") to 1, t("רגיל", "Normal") to 2, t("חזק", "Strong") to 3), 2)
            seg(c, t("לחיצה ארוכה להזזת הסמן", "Long press to move cursor"), "longPress",
                listOf(t("קצרה", "Short") to 300, t("בינונית", "Medium") to 500, t("ארוכה", "Long") to 800), 500)
        }

        ui.section(col, t("לוח העתקות", "Clipboard"))
        ui.card(col).also { c ->
            seg(c, t("זמן שמירה (נעוצים נשמרים תמיד)", "Keep items for (pinned are kept forever)"), "clipExpiryMin",
                listOf(t("שעה", "1 hour") to 60, t("יום", "1 day") to 1440, t("שבוע", "1 week") to 10080), 60)
            val (row, s) = ui.switchRow(t("צילומי מסך אחרונים בלוח", "Recent screenshots in clipboard"),
                t("התמונות לא יוצאות מהטלפון", "Images never leave your phone"),
                bool("screenshots", true) && hasImagePermission()) { on ->
                put("screenshots", on)
                if (on && !hasImagePermission()) requestPermissions(arrayOf(imagePermission()), permRequest)
            }
            shotSwitch = s
            ui.add(c, row)
        }

        ui.section(col, t("למידה", "Learning"))
        ui.card(col).also { c ->
            ui.add(c, ui.navRow(R.drawable.ic_chart, t("הסטטיסטיקה שלי", "My statistics"),
                t("המילים שלך, מהירות הקלדה ודיוק התיקון", "Your words, typing speed and autocorrect accuracy")) {
                startActivity(Intent(this, StatsActivity::class.java))
            })
        }

        ui.section(col, t("פרטיות ומילוי", "Privacy & autofill"))
        ui.card(col).also { c ->
            ui.add(c, ui.navRow(R.drawable.ic_lock, t("הכספת", "Vault"), t("פרטים אישיים, נפתחים בטביעת אצבע", "Personal details, unlocked by fingerprint")) {
                startActivity(Intent(this, VaultActivity::class.java))
            })
            ui.add(c, ui.navRow(R.drawable.ic_edit, t("קיצורים ומילים שמורות", "Shortcuts & saved text"), t("למשל \"טל\" ← מספר הטלפון", "e.g. \"ph\" → your phone number")) {
                startActivity(Intent(this, ShortcutsActivity::class.java))
            })
            sw(c, t("סיסמאות וכרטיסים שמורים", "Saved passwords & cards"), t("מגוגל, בשורת ההצעות", "From Google, in the suggestion bar"), "inlineAutofill", true)
            val (row, s) = ui.switchRow(t("קודי אימות מ-SMS", "Verification codes from SMS"),
                t("בשיאומי ייתכן שצריך לאשר גם \"הרשאות נוספות\"", "On Xiaomi you may also need \"Other permissions\""),
                bool("smsCodes", true) && hasSmsPermission()) { on ->
                put("smsCodes", on)
                if (on && !hasSmsPermission()) requestPermissions(arrayOf(Manifest.permission.RECEIVE_SMS), smsRequest)
            }
            smsSwitch = s
            ui.add(c, row)
        }

        ui.section(col, t("מילון", "Dictionary"))
        ui.card(col).also { c ->
            ui.add(c, ui.navRow(R.drawable.ic_trash, t("מחיקת המילים שהמקלדת למדה", "Clear learned words"),
                t("המילון הבסיסי יישאר", "The built-in dictionary stays"), danger = true) {
                ui.confirm(t("למחוק את כל המילים והצירופים שהמקלדת למדה ממך?", "Delete all words and phrases the keyboard learned from you?"),
                    t("מחק", "Delete")) {
                    WordPredictor.instance?.clearLearned() ?: WordPredictor.clearSaved(this)
                    Toast.makeText(this, t("נמחק", "Deleted"), Toast.LENGTH_SHORT).show()
                }
            })
        }

        ui.section(col, t("ניסיון", "Try it"))
        ui.card(col).also { c ->
            ui.add(c, EditText(this).apply {
                hint = t("נסה להקליד כאן…", "Try typing here…")
                minLines = 3
                gravity = Gravity.TOP or Gravity.START
                setTextColor(ui.textMain)
                setHintTextColor(ui.textSub)
                background = null
                setPadding(ui.dp(16), ui.dp(14), ui.dp(16), ui.dp(14))
            })
        }
    }

    // ---------- כותרת ומצב התקנה ----------

    private fun header(col: LinearLayout) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(ui.dp(4), 0, ui.dp(4), ui.dp(18))
        }
        row.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_launcher)
            background = GradientDrawable().apply { cornerRadius = ui.dp(14).toFloat(); setColor(ui.accent) }
            clipToOutline = true
        }, LinearLayout.LayoutParams(ui.dp(52), ui.dp(52)))
        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(14), 0, ui.dp(14), 0)
        }
        texts.addView(TextView(this).apply {
            text = "Perfekey"
            textSize = 26f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(ui.textMain)
        })
        texts.addView(TextView(this).apply {
            text = t("הגדרות", "Settings")
            textSize = 15f
            setTextColor(ui.textSub)
        })
        row.addView(texts)
        col.addView(row)
    }

    private fun isEnabled(): Boolean =
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).enabledInputMethodList.any { it.packageName == packageName }

    private fun isDefault(): Boolean =
        Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)?.startsWith(packageName) == true

    /** כרטיס עליון: אם המקלדת פעילה מציג וי ירוק, אחרת את שני שלבי ההתקנה */
    private fun refreshSetup() {
        val c = setupCard ?: return
        c.removeAllViews()
        if (isEnabled() && isDefault()) {
            c.addView(LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(ui.dp(16), ui.dp(14), ui.dp(16), ui.dp(14))
                addView(TextView(this@MainActivity).apply {
                    text = "✓"
                    gravity = Gravity.CENTER
                    setTextColor(Color.WHITE)
                    textSize = 16f
                    setTypeface(typeface, Typeface.BOLD)
                    background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(ui.green) }
                }, LinearLayout.LayoutParams(ui.dp(30), ui.dp(30)))
                addView(TextView(this@MainActivity).apply {
                    text = t("המקלדת פעילה ומוגדרת כברירת מחדל", "The keyboard is on and set as default")
                    textSize = 15f
                    setTextColor(ui.textMain)
                    setPadding(ui.dp(12), 0, ui.dp(12), 0)
                })
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            return
        }
        ui.add(c, ui.navRow(null, t("1. הפעלת המקלדת", "1. Enable the keyboard"),
            if (isEnabled()) t("✓ הופעלה", "✓ Enabled") else t("בהגדרות המערכת", "In system settings")) {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })
        ui.add(c, ui.navRow(null, t("2. בחירה כברירת מחדל", "2. Set as default"), t("בחירה ברשימת המקלדות", "Pick it from the keyboard list")) {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })
    }

    // ---------- הרשאות ----------

    private fun imagePermission() =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasImagePermission() =
        checkSelfPermission(imagePermission()) == PackageManager.PERMISSION_GRANTED

    private fun hasSmsPermission() =
        checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        val sw: Switch?; val key: String; val perm: String; val msg: String
        when (requestCode) {
            smsRequest -> { sw = smsSwitch; key = "smsCodes"; perm = Manifest.permission.RECEIVE_SMS
                msg = t("צריך לאשר הודעות SMS בהגדרות האפליקציה", "Allow SMS in the app settings") }
            permRequest -> { sw = shotSwitch; key = "screenshots"; perm = imagePermission()
                msg = t("צריך לאשר גישה לתמונות בהגדרות האפליקציה", "Allow photo access in the app settings") }
            else -> return
        }
        sw?.isChecked = granted
        prefs.edit().putBoolean(key, granted).apply()
        if (!granted && !shouldShowRequestPermissionRationale(perm)) {
            // ההרשאה נחסמה לצמיתות: שולחים להגדרות האפליקציה
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
    }
}
