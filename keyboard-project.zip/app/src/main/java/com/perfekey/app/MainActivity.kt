package com.perfekey.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** מסך ההגדרות של המקלדת (נפתח מהאפליקציה או מגלגל השיניים בסרגל הכלים) */
class MainActivity : Activity() {

    private lateinit var ui: UiKit
    private lateinit var prefs: SharedPreferences
    private var setupCard: LinearLayout? = null
    private var shotSwitch: Switch? = null
    private var smsSwitch: Switch? = null
    private val permRequest = 7
    private val smsRequest = 8
    private val reqExport = 31
    private val reqImport = 32
    private val reqAuthExport = 33
    private var pendingBackupPassword: String? = null

    private fun t(he: String, en: String) = ui.t(he, en)

    override fun onCreate(savedInstanceState: Bundle?) {
        ui = UiKit(this)
        ui.applyTheme()
        super.onCreate(savedInstanceState)
        ui.styleWindow()
        prefs = getSharedPreferences("settings", MODE_PRIVATE)
        render()

        // הגענו מהבאנר בלוח: מבקשים את ההרשאה מיד
        if (intent.getBooleanExtra("askScreenshots", false) && !hasImagePermission()) {
            requestPermissions(arrayOf(imagePermission()), permRequest)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshSetup()
    }

    private fun bool(key: String, def: Boolean) = prefs.getBoolean(key, def)
    private fun put(key: String, v: Boolean) = prefs.edit().putBoolean(key, v).apply()
    private fun putInt(key: String, v: Int) = prefs.edit().putInt(key, v).apply()

    private fun sw(card: LinearLayout, title: String, sub: String?, key: String, def: Boolean) {
        ui.add(card, ui.switchRow(title, sub, bool(key, def)) { put(key, it) }.first)
    }

    private fun seg(card: LinearLayout, title: String, key: String, options: List<Pair<String, Int>>, def: Int) {
        ui.add(card, ui.segmented(title, options, prefs.getInt(key, def)) { putInt(key, it) })
    }

    private fun render() {
        val page = ui.page()
        val col = page.column
        col.setPadding(ui.dp(16), ui.dp(28), ui.dp(16), ui.dp(40))
        header(col)

        setupCard = ui.card(col)
        refreshSetup()

        ui.section(col, t("כללי", "General"))
        ui.card(col).also { c ->
            ui.add(c, ui.segmented(t("שפת הממשק", "Interface language"),
                listOf("עברית" to "he", "English" to "en"), prefs.getString("uiLang", "he") ?: "he") {
                prefs.edit().putString("uiLang", it).apply()
                recreate()
            })
        }

        ui.section(col, t("מראה", "Appearance"))
        ui.card(col).also { c ->
            // ערכת צבעים למקלדת
            ui.add(c, ui.swatches(t("צבעי המקלדת", "Keyboard colors"),
                Themes.themes.map { (key, he, en) ->
                    val pc = Themes.previewColors(key)
                    if (pc == null) UiKit.Swatch(key, t(he, en), 0xFFEEEFF2.toInt(), 0xFF1B1B1F.toInt())
                    else UiKit.Swatch(key, t(he, en), pc.bg, ring = pc.key)
                }, prefs.getString("theme", "auto") ?: "auto") {
                prefs.edit().putString("theme", it).apply()
            })
            // צבע הדגשה
            val accentNames = mapOf(
                "classic" to t("קלאסי", "Classic"), "blue" to t("כחול", "Blue"), "purple" to t("סגול", "Purple"),
                "green" to t("ירוק", "Green"), "teal" to t("טורקיז", "Teal"), "orange" to t("כתום", "Orange"),
                "pink" to t("ורוד", "Pink"), "red" to t("אדום", "Red")
            )
            ui.add(c, ui.swatches(t("צבע הדגשה", "Accent color"),
                Themes.accents.map { (key, acc, enter) ->
                    UiKit.Swatch(key, accentNames[key] ?: key, acc, if (acc != enter) enter else null, ring = 0x00000000)
                }, prefs.getString("accent", "classic") ?: "classic") {
                prefs.edit().putString("accent", it).apply()
                recreate()   // גם המסך הזה מתעדכן לצבע החדש
            })
            // צבע מקש האנטר
            val enterNames = mapOf(
                "green" to t("ירוק", "Green"), "blue" to t("כחול", "Blue"), "purple" to t("סגול", "Purple"),
                "teal" to t("טורקיז", "Teal"), "orange" to t("כתום", "Orange"), "pink" to t("ורוד", "Pink"), "red" to t("אדום", "Red")
            )
            val accentKey = prefs.getString("accent", "classic") ?: "classic"
            val enterItems = mutableListOf(UiKit.Swatch("auto", t("אוטומטי", "Auto"), Themes.enter(accentKey), ui.accent))
            Themes.enterOptions.forEach { (key, color) -> enterItems += UiKit.Swatch(key, enterNames[key] ?: key, color, ring = 0) }
            val neutral = Themes.colors(prefs.getString("theme", "auto") ?: "auto", ui.dark)
            enterItems += UiKit.Swatch("neutral", t("ניטרלי", "Neutral"), neutral.special, ring = neutral.key)
            ui.add(c, ui.swatches(t("צבע האנטר", "Enter key color"), enterItems, prefs.getString("enterColor", "auto") ?: "auto") {
                prefs.edit().putString("enterColor", it).apply()
            })
            seg(c, t("גובה המקשים", "Key height"), "keyHeight",
                listOf(t("נמוך", "Low") to 46, t("בינוני", "Medium") to 54, t("גבוה", "Tall") to 62), 54)
            sw(c, t("שורת מספרים קבועה", "Number row"), t("בלעדיה המספרים במסך הסימנים", "Without it, numbers are on the symbols screen"), "numberRow", true)
        }

        ui.section(col, t("סרגל הכלים", "Toolbar"))
        ui.card(col).also { c ->
            ui.add(c, ui.navRow(R.drawable.ic_toolbar, t("סידור סרגל הכלים", "Arrange toolbar"),
                t("סדר הכפתורים ואילו מהם מוצגים", "Button order and visibility")) {
                startActivity(Intent(this, ToolbarActivity::class.java))
            })
        }

        ui.section(col, t("הקלדה", "Typing"))
        ui.card(col).also { c ->
            sw(c, t("רטט בלחיצה", "Vibrate on keypress"), null, "vibrate", true)
            sw(c, t("הצעות מילים", "Word suggestions"), null, "suggestions", true)
            sw(c, t("תיקון אוטומטי", "Autocorrect"), t("מחיקה אחת מיד אחרי מבטלת את התיקון", "One backspace right after undoes it"), "autocorrect", true)
            sw(c, t("הצעות אמוג'י", "Emoji suggestions"), t("למשל ❤️ אחרי \"אוהב\"", "e.g. ❤️ after \"love\""), "emojiSuggest", true)
            sw(c, t("רווח כפול מוסיף נקודה", "Double space adds a period"), null, "doubleSpace", true)
            sw(c, t("אות גדולה אוטומטית באנגלית", "Auto-capitalize in English"), null, "autoCaps", true)
            seg(c, t("הגדלה סמויה של האות הצפויה", "Smart key targets"), "smartLevel",
                listOf(t("כבוי", "Off") to 0, t("עדין", "Light") to 1, t("רגיל", "Normal") to 2, t("חזק", "Strong") to 3), 2)
            seg(c, t("לחיצה ארוכה להזזת הסמן", "Long press to move cursor"), "longPress",
                listOf(t("קצרה", "Short") to 300, t("בינונית", "Medium") to 500, t("ארוכה", "Long") to 800), 500)
        }

        ui.section(col, t("לוח העתקות", "Clipboard"))
        ui.card(col).also { c ->
            seg(c, t("זמן שמירה (נעוצים נשמרים תמיד)", "Keep items for (pinned are kept forever)"), "clipExpiryMin",
                listOf(t("שעה", "1 hour") to 60, t("יום", "1 day") to 1440, t("שבוע", "1 week") to 10080), 60)
            val (row, s) = ui.switchRow(t("צילומי מסך אחרונים בלוח", "Recent screenshots in clipboard"),
                t("התמונות לא יוצאות מהטלפון", "Images never leave your phone"),
                bool("screenshots", true) && hasImagePermission()) { on ->
                put("screenshots", on)
                if (on && !hasImagePermission()) requestPermissions(arrayOf(imagePermission()), permRequest)
            }
            shotSwitch = s
            ui.add(c, row)
        }

        ui.section(col, t("למידה", "Learning"))
        ui.card(col).also { c ->
            ui.add(c, ui.navRow(R.drawable.ic_chart, t("הסטטיסטיקה שלי", "My statistics"),
                t("המילים שלך, מהירות הקלדה ודיוק התיקון", "Your words, typing speed and autocorrect accuracy")) {
                startActivity(Intent(this, StatsActivity::class.java))
            })
        }

        ui.section(col, t("פרטיות ומילוי", "Privacy & autofill"))
        ui.card(col).also { c ->
            ui.add(c, ui.navRow(R.drawable.ic_lock, t("הכספת", "Vault"), t("פרטים אישיים, נפתחים בטביעת אצבע", "Personal details, unlocked by fingerprint")) {
                startActivity(Intent(this, VaultActivity::class.java))
            })
            ui.add(c, ui.navRow(R.drawable.ic_edit, t("קיצורים ומילים שמורות", "Shortcuts & saved text"), t("למשל \"טל\" ← מספר הטלפון", "e.g. \"ph\" → your phone number")) {
                startActivity(Intent(this, ShortcutsActivity::class.java))
            })
            sw(c, t("סיסמאות וכרטיסים שמורים", "Saved passwords & cards"), t("מגוגל, בשורת ההצעות", "From Google, in the suggestion bar"), "inlineAutofill", true)
            val (row, s) = ui.switchRow(t("קודי אימות מ-SMS", "Verification codes from SMS"),
                t("בשיאומי ייתכן שצריך לאשר גם \"הרשאות נוספות\"", "On Xiaomi you may also need \"Other permissions\""),
                bool("smsCodes", true) && hasSmsPermission()) { on ->
                put("smsCodes", on)
                if (on && !hasSmsPermission()) requestPermissions(arrayOf(Manifest.permission.RECEIVE_SMS), smsRequest)
            }
            smsSwitch = s
            ui.add(c, row)
        }

        ui.section(col, t("גיבוי ושחזור", "Backup & restore"))
        ui.card(col).also { c ->
            ui.add(c, ui.navRow(R.drawable.ic_upload, t("גיבוי לקובץ", "Back up to a file"),
                t("הגדרות, קיצורים, מילים שנלמדו וסטטיסטיקה. הכספת לפי בחירה, מוצפנת", "Settings, shortcuts, learned words and stats. Vault optional, encrypted")) {
                startBackup()
            })
            ui.add(c, ui.navRow(R.drawable.ic_download, t("שחזור מקובץ", "Restore from a file"),
                t("מחליף את הנתונים הנוכחיים במה שבגיבוי", "Replaces current data with the backup")) {
                ui.confirm(t("השחזור יחליף את ההגדרות, הקיצורים והמילים שנלמדו במה שבקובץ. להמשיך?",
                    "Restoring replaces your settings, shortcuts and learned words with the backup. Continue?"), t("בחירת קובץ", "Choose file"), danger = false) {
                    startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                    }, reqImport)
                }
            })
        }

        ui.section(col, t("מילון", "Dictionary"))
        ui.card(col).also { c ->
            ui.add(c, ui.navRow(R.drawable.ic_trash, t("מחיקת המילים שהמקלדת למדה", "Clear learned words"),
                t("המילון הבסיסי יישאר", "The built-in dictionary stays"), danger = true) {
                ui.confirm(t("למחוק את כל המילים והצירופים שהמקלדת למדה ממך?", "Delete all words and phrases the keyboard learned from you?"),
                    t("מחק", "Delete")) {
                    WordPredictor.instance?.clearLearned() ?: WordPredictor.clearSaved(this)
                    Toast.makeText(this, t("נמחק", "Deleted"), Toast.LENGTH_SHORT).show()
                }
            })
        }

        ui.section(col, t("אודות", "About"))
        ui.card(col).also { c ->
            val version = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (_: Exception) { "" }
            ui.add(c, LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(ui.dp(16), ui.dp(14), ui.dp(16), ui.dp(14))
                addView(ui.titleBlock("Perfekey ${version ?: ""}".trim(),
                    t("מקלדת עברית ואנגלית חכמה ופרטית", "A smart, private Hebrew & English keyboard")))
            })
            ui.add(c, LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(ui.dp(16), ui.dp(14), ui.dp(16), ui.dp(14))
                addView(ui.titleBlock(t("פרטיות", "Privacy"),
                    t("כל הנתונים (מילים שנלמדו, לוח, כספת וסטטיסטיקה) נשמרים רק בטלפון. המקלדת לא שולחת שום מידע לאינטרנט.",
                        "All data (learned words, clipboard, vault and stats) stays on your phone. The keyboard never sends anything to the internet."),
                    maxSubLines = 5))
            })
            ui.add(c, ui.navRow(null, t("קוד פתוח ורישיונות", "Open source & licenses"), null) {
                ui.confirm(t(
                    "מילון השכיחות מבוסס על FrequencyWords מאת Hermit Dave (רישיון MIT), שנבנה מכתוביות OpenSubtitles.\n\nספריות AndroidX של גוגל (רישיון Apache 2.0).",
                    "The frequency dictionary is based on FrequencyWords by Hermit Dave (MIT license), built from OpenSubtitles.\n\nAndroidX libraries by Google (Apache 2.0 license)."),
                    t("סגור", "Close"), danger = false) { }
            })
        }

        ui.section(col, t("ניסיון", "Try it"))
        ui.card(col).also { c ->
            ui.add(c, EditText(this).apply {
                hint = t("נסה להקליד כאן…", "Try typing here…")
                minLines = 3
                gravity = Gravity.TOP or Gravity.START
                setTextColor(ui.textMain)
                setHintTextColor(ui.textSub)
                background = null
                setPadding(ui.dp(16), ui.dp(14), ui.dp(16), ui.dp(14))
            })
        }
    }

    // ---------- כותרת ומצב התקנה ----------

    private fun header(col: LinearLayout) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(ui.dp(4), 0, ui.dp(4), ui.dp(18))
        }
        row.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_launcher)
            background = GradientDrawable().apply { cornerRadius = ui.dp(14).toFloat(); setColor(ui.accent) }
            clipToOutline = true
        }, LinearLayout.LayoutParams(ui.dp(52), ui.dp(52)))
        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(14), 0, ui.dp(14), 0)
        }
        texts.addView(TextView(this).apply {
            text = "Perfekey"
            textSize = 26f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(ui.textMain)
        })
        texts.addView(TextView(this).apply {
            text = t("הגדרות", "Settings")
            textSize = 15f
            setTextColor(ui.textSub)
        })
        row.addView(texts)
        col.addView(row)
    }

    private fun isEnabled(): Boolean =
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).enabledInputMethodList.any { it.packageName == packageName }

    private fun isDefault(): Boolean =
        Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)?.startsWith(packageName) == true

    /** כרטיס עליון: אם המקלדת פעילה מציג וי ירוק, אחרת את שני שלבי ההתקנה */
    private fun refreshSetup() {
        val c = setupCard ?: return
        c.removeAllViews()
        if (isEnabled() && isDefault()) {
            c.addView(LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(ui.dp(16), ui.dp(14), ui.dp(16), ui.dp(14))
                addView(TextView(this@MainActivity).apply {
                    text = "✓"
                    gravity = Gravity.CENTER
                    setTextColor(Color.WHITE)
                    textSize = 16f
                    setTypeface(typeface, Typeface.BOLD)
                    background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(ui.green) }
                }, LinearLayout.LayoutParams(ui.dp(30), ui.dp(30)))
                addView(TextView(this@MainActivity).apply {
                    text = t("המקלדת פעילה ומוגדרת כברירת מחדל", "The keyboard is on and set as default")
                    textSize = 15f
                    setTextColor(ui.textMain)
                    setPadding(ui.dp(12), 0, ui.dp(12), 0)
                })
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            return
        }
        ui.add(c, ui.navRow(null, t("1. הפעלת המקלדת", "1. Enable the keyboard"),
            if (isEnabled()) t("✓ הופעלה", "✓ Enabled") else t("בהגדרות המערכת", "In system settings")) {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })
        ui.add(c, ui.navRow(null, t("2. בחירה כברירת מחדל", "2. Set as default"), t("בחירה ברשימת המקלדות", "Pick it from the keyboard list")) {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })
    }

    // ---------- גיבוי ושחזור ----------

    private fun startBackup() {
        ui.formSheet(
            t("גיבוי לקובץ", "Back up to a file"),
            listOf(UiKit.FieldSpec(t("סיסמה לכספת (לא חובה)", "Vault password (optional)"),
                t("בלי סיסמה, הכספת לא תיכלל", "Without a password the vault is not included"), "", password = true)),
            secure = true, onDelete = null, saveLabel = t("יצירת קובץ", "Create file"),
            note = t("את הסיסמה תצטרך כדי לשחזר את הכספת. אי אפשר לשחזר אותה בלי הסיסמה.",
                "You'll need this password to restore the vault. It can't be recovered without it.")
        ) { values ->
            pendingBackupPassword = values[0].ifEmpty { null }
            if (pendingBackupPassword != null && !Vault.isUnlocked()) {
                // הכספת נכללת: קודם טביעת אצבע
                startActivityForResult(Intent(this, VaultAuthActivity::class.java), reqAuthExport)
            } else {
                askExportLocation()
            }
            true
        }
    }

    private fun askExportLocation() {
        val date = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
            putExtra(Intent.EXTRA_TITLE, "perfekey-backup-$date.json")
        }, reqExport)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            reqAuthExport -> if (resultCode == RESULT_OK) askExportLocation() else pendingBackupPassword = null
            reqExport -> {
                val uri = data?.data
                if (resultCode == RESULT_OK && uri != null) {
                    try {
                        WordPredictor.instance?.save()
                        Stats.get(this).save()
                        contentResolver.openOutputStream(uri)?.use {
                            it.write(Backup.export(this, pendingBackupPassword).toByteArray(Charsets.UTF_8))
                        }
                        Toast.makeText(this, t("הגיבוי נשמר", "Backup saved"), Toast.LENGTH_SHORT).show()
                    } catch (_: Exception) {
                        Toast.makeText(this, t("לא הצלחתי לשמור את הקובץ", "Couldn't save the file"), Toast.LENGTH_LONG).show()
                    }
                }
                pendingBackupPassword = null
            }
            reqImport -> {
                val uri = data?.data ?: return
                if (resultCode != RESULT_OK) return
                val backup = try {
                    val text = contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: return
                    Backup.parse(text)
                } catch (_: Exception) {
                    Toast.makeText(this, t("זה לא קובץ גיבוי של Perfekey", "This isn't a Perfekey backup file"), Toast.LENGTH_LONG).show()
                    return
                }
                if (backup.hasVault) {
                    ui.formSheet(
                        t("שחזור הכספת", "Restore vault"),
                        listOf(UiKit.FieldSpec(t("סיסמת הכספת", "Vault password"), t("ריק = לשחזר בלי הכספת", "Empty = restore without the vault"), "", password = true)),
                        secure = true, onDelete = null, saveLabel = t("שחזור", "Restore"),
                        errorText = t("הסיסמה שגויה", "Wrong password")
                    ) { values ->
                        val ok = Backup.restore(this, backup, values[0].ifEmpty { null })
                        if (ok) restartAfterRestore()
                        ok
                    }
                } else {
                    Backup.restore(this, backup, null)
                    restartAfterRestore()
                }
            }
        }
    }

    /** הנתונים נטענו לזיכרון של המקלדת; הדרך הבטוחה לטעון את החדשים היא להפעיל מחדש */
    private fun restartAfterRestore() {
        Toast.makeText(this, t("השחזור הושלם. Perfekey מופעלת מחדש", "Restore complete. Perfekey is restarting"), Toast.LENGTH_LONG).show()
        android.os.Handler(mainLooper).postDelayed({
            finishAffinity()
            android.os.Process.killProcess(android.os.Process.myPid())
        }, 1200)
    }

    // ---------- הרשאות ----------

    private fun imagePermission() =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasImagePermission() =
        checkSelfPermission(imagePermission()) == PackageManager.PERMISSION_GRANTED

    private fun hasSmsPermission() =
        checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        val sw: Switch?; val key: String; val perm: String; val msg: String
        when (requestCode) {
            smsRequest -> { sw = smsSwitch; key = "smsCodes"; perm = Manifest.permission.RECEIVE_SMS
                msg = t("צריך לאשר הודעות SMS בהגדרות האפליקציה", "Allow SMS in the app settings") }
            permRequest -> { sw = shotSwitch; key = "screenshots"; perm = imagePermission()
                msg = t("צריך לאשר גישה לתמונות בהגדרות האפליקציה", "Allow photo access in the app settings") }
            else -> return
        }
        sw?.isChecked = granted
        prefs.edit().putBoolean(key, granted).apply()
        if (!granted && !shouldShowRequestPermissionRationale(perm)) {
            // ההרשאה נחסמה לצמיתות: שולחים להגדרות האפליקציה
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
    }
}
