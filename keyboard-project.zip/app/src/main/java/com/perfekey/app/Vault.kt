package com.perfekey.app

import android.content.Context
import android.os.SystemClock
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * הכספת: פריטים פרטיים, מוצפנים במפתח שנשמר בשבב האבטחה של הטלפון (Android Keystore).
 * הגישה נפתחת אחרי טביעת אצבע (או קוד הנעילה) ונסגרת שוב אחרי זמן קצר.
 */
object Vault {

    class Item(val id: Long, var label: String, var value: String)

    private const val KEY_ALIAS = "keyboard_vault_key"
    private const val UNLOCK_MS = 2 * 60 * 1000L

    @Volatile
    private var unlockedUntil = 0L

    /** המקלדת ביקשה לפתוח את הכספת; כשהיא תחזור אחרי האימות, היא תציג את הפאנל */
    @Volatile
    var openPanelOnReturn = false

    fun isUnlocked() = SystemClock.elapsedRealtime() < unlockedUntil
    fun unlock() { unlockedUntil = SystemClock.elapsedRealtime() + UNLOCK_MS }
    fun lock() { unlockedUntil = 0L }

    fun load(context: Context): MutableList<Item> {
        val stored = context.getSharedPreferences("vault", Context.MODE_PRIVATE).getString("data", null)
            ?: return mutableListOf()
        return try {
            val json = JSONArray(decrypt(stored))
            MutableList(json.length()) { i ->
                val o = json.getJSONObject(i)
                Item(o.getLong("id"), o.getString("label"), o.getString("value"))
            }
        } catch (_: Exception) {
            mutableListOf()
        }
    }

    fun save(context: Context, items: List<Item>) {
        val json = JSONArray()
        items.forEach { json.put(JSONObject().put("id", it.id).put("label", it.label).put("value", it.value)) }
        context.getSharedPreferences("vault", Context.MODE_PRIVATE).edit()
            .putString("data", encrypt(json.toString())).apply()
    }

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    private fun encrypt(plain: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val ct = cipher.doFinal(plain.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(cipher.iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(ct, Base64.NO_WRAP)
    }

    private fun decrypt(stored: String): String {
        val (ivB64, ctB64) = stored.split(":", limit = 2)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, Base64.decode(ivB64, Base64.NO_WRAP)))
        return String(cipher.doFinal(Base64.decode(ctB64, Base64.NO_WRAP)), Charsets.UTF_8)
    }
}
