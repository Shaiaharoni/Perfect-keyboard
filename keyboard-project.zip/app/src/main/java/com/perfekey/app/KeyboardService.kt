package com.perfekey.app

import android.Manifest
import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.ContentUris
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.drawable.Icon
import android.view.ViewGroup
import android.view.inputmethod.InlineSuggestionsRequest
import android.view.inputmethod.InlineSuggestionsResponse
import android.widget.HorizontalScrollView
import android.widget.inline.InlinePresentationSpec
import androidx.autofill.inline.UiVersions
import androidx.autofill.inline.common.ImageViewStyle
import androidx.autofill.inline.common.TextViewStyle
import androidx.autofill.inline.common.ViewStyle
import androidx.autofill.inline.v1.InlineSuggestionUi
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import android.widget.FrameLayout
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.core.view.inputmethod.EditorInfoCompat
import androidx.core.view.inputmethod.InputConnectionCompat
import androidx.core.view.inputmethod.InputContentInfoCompat
import java.io.File
import java.util.concurrent.Executors
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.ln

class KeyboardService : InputMethodService() {

    // ====== הגדרות קבועות ======
    private val numberRowHeightDp = 36  // גובה שורת המספרים
    private val suggestionBarDp = 42    // גובה שורת ההצעות / הכלים
    private val swipeThresholdDp = 40   // כמה לגרור את הרווח כדי להחליף שפה
    private val oneHandWidth = 0.8f     // רוחב המקלדת במצב יד אחת
    private val clipColumns = 3         // כרטיסים בשורה בלוח
    private val clipRowsVisible = 4     // שורות כרטיסים שנראות בלי גלילה
    private val cursorStepDp = 12       // מרחק גרירה לתזוזת סמן של תו אחד
    private val cursorLineDp = 32       // מרחק גרירה לתזוזה של שורה

    // ====== הגדרות שנטענות ממסך ההגדרות ======
    private var keyHeightDp = 54
    private var showNumberRow = true
    private var vibrateOn = true
    private var suggestionsOn = true
    private var smartTargetStrength = 0.35
    private var doubleSpacePeriod = true
    private var autoCapsOn = true
    private var longPressMs = 500L
    private var screenshotsOn = true
    private var autocorrectOn = true
    private var emojiSuggestOn = true
    private var inlineAutofillOn = true
    private var shortcuts: Map<String, List<String>> = emptyMap()

    private enum class Lang { HE, EN }
    private enum class Mode { LETTERS, SYMBOLS, CLIPBOARD, VAULT, EMOJI, NUMPAD }

    private data class Key(val label: String, val action: String = label, val weight: Float = 1f)

    private class Palette(c: Themes.Colors, val accent: Int, enterColor: Int?) {
        // אנטר "ניטרלי" = בצבע המקשים המיוחדים, עם אייקון בצבע הטקסט
        val enter = enterColor ?: c.special
        val enterText = if (enterColor == null) c.text else Color.WHITE
        val bg = c.bg
        val key = c.key
        val special = c.special
        val num = c.num          // שורת המספרים
        val pressed = c.pressed
        val text = c.text
        val dark = c.dark
    }

    /** הצבעים לפי ערכת הצבעים וצבע ההדגשה שנבחרו בהגדרות */
    private fun makePalette(): Palette {
        val s = getSharedPreferences("settings", Context.MODE_PRIVATE)
        val accentKey = s.getString("accent", "classic") ?: "classic"
        return Palette(Themes.colors(s.getString("theme", "auto") ?: "auto", isDark()),
            Themes.accent(accentKey), Themes.enterColor(s.getString("enterColor", "auto") ?: "auto", accentKey))
    }

    companion object {
        const val A_BACK = "#back"
        const val A_SHIFT = "#shift"
        const val A_ENTER = "#enter"
        const val A_SPACE = "#space"
        const val A_SYM = "#sym"
        const val A_ABC = "#abc"
        const val A_GAP = "#gap"
        const val A_EMOJI = "#emoji"
    }

    private lateinit var predictor: WordPredictor
    private lateinit var stats: Stats
    private lateinit var root: LinearLayout
    private lateinit var suggestionBar: LinearLayout
    private lateinit var keysContainer: LinearLayout
    private lateinit var body: LinearLayout
    private lateinit var sidePanel: LinearLayout
    private lateinit var clipboard: ClipboardManager
    private val handler = Handler(Looper.getMainLooper())
    private val letterKeys = mutableListOf<Pair<View, String>>()
    private var spaceKeyView: View? = null   // לחישוב "רווח מוגדל" כשמילה כבר שלמה
    private lateinit var clips: ClipStore
    private val io = Executors.newSingleThreadExecutor()
    private val thumbCache = LruCache<String, Bitmap>(40)
    private var ignoreClipUntil = 0L
    private val authority get() = "$packageName.fileprovider"
    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { captureClip(fresh = true) }
    private var pal = Palette(Themes.colors("light", false), Themes.accent("classic"), Themes.enter("classic"))

    private var lang = Lang.HE
    private var mode = Mode.LETTERS
    private var shift = false
    private var capsLock = false
    private var lastShiftTime = 0L
    private var lastSpaceTime = 0L
    private var isPassword = false
    private var noAutoCaps = false
    private var numpadKind: String? = null   // "phone" / "number" / "date" = שדה מספרים: לוח מספרים גדול
    private var isUrlField = false     // שורת כתובת בדפדפן / שדה קישור
    private var isEmailField = false   // שדה מייל
    private var domainChips = false    // לחיצה ארוכה על .com: סיומות נוספות בשורת ההצעות
    private var autofillViews: List<View> = emptyList()   // הצעות מילוי אוטומטי (סיסמאות, כרטיסים, כתובות)
    private var autofillToken = 0
    private var toolsOpen = false
    private var incognito = false

    // הצעות "עכשיו": מה שהועתק הרגע וצילום מסך שצולם הרגע
    private val recentCopyMs = 90_000L
    private val recentShotMs = 3 * 60_000L
    private var recentCopyText: String? = null
    private var recentCopyImage: String? = null
    private var recentCopyTime = 0L
    private var recentShot: String? = null
    private var recentShotTime = 0L
    private val dismissedRecent = mutableSetOf<String>()
    private var mediaObserver: android.database.ContentObserver? = null
    private val centerViews = mutableListOf<View>()   // פריטים שממוקמים באמצע שורת ההצעות
    private var barState = ""
    private var oneHand = 0   // 0 = רגיל, 1 = יד ימין, 2 = יד שמאל

    // מצב "משטח מגע" להזזת הסמן (לחיצה ארוכה ואז גרירה)
    private var trackpad = false
    private var tpX = 0f
    private var tpY = 0f

    private val repeatDelete = object : Runnable {
        override fun run() {
            deleteBack()
            handler.postDelayed(this, 50)
        }
    }

    // ---------- מחזור חיים ----------

    override fun onCreate() {
        super.onCreate()
        predictor = WordPredictor(this)
        stats = Stats.get(this)
        WordPredictor.instance = predictor
        val settings = getSharedPreferences("settings", Context.MODE_PRIVATE)
        lang = if (settings.getString("lang", "HE") == "EN") Lang.EN else Lang.HE
        oneHand = settings.getInt("oneHand", 0)
        clips = ClipStore(this)
        loadSettings()
        // צילומי מסך חדשים: מאזינים לשינויים בגלריה
        mediaObserver = object : android.database.ContentObserver(handler) {
            override fun onChange(selfChange: Boolean) {
                handler.removeCallbacks(checkShotRunnable)
                handler.postDelayed(checkShotRunnable, 700)   // לתת לקובץ להיכתב עד הסוף
            }
        }
        try {
            contentResolver.registerContentObserver(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, mediaObserver!!)
        } catch (_: Exception) {
        }
        clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.addPrimaryClipChangedListener(clipListener)
        OtpStore.listener = {
            handler.post {
                barState = ""
                updateSuggestions()
            }
        }
    }

    private fun loadSettings() {
        val s = getSharedPreferences("settings", Context.MODE_PRIVATE)
        keyHeightDp = s.getInt("keyHeight", 54)
        showNumberRow = s.getBoolean("numberRow", true)
        vibrateOn = s.getBoolean("vibrate", true)
        suggestionsOn = s.getBoolean("suggestions", true)
        smartTargetStrength = when (s.getInt("smartLevel", 2)) {
            0 -> 0.0
            1 -> 0.2
            3 -> 0.5
            else -> 0.35
        }
        doubleSpacePeriod = s.getBoolean("doubleSpace", true)
        autoCapsOn = s.getBoolean("autoCaps", true)
        longPressMs = s.getInt("longPress", 500).toLong()
        screenshotsOn = s.getBoolean("screenshots", true)
        incognito = s.getBoolean("incognito", false)
        applyIncognito()
        autocorrectOn = s.getBoolean("autocorrect", true)
        emojiSuggestOn = s.getBoolean("emojiSuggest", true)
        inlineAutofillOn = s.getBoolean("inlineAutofill", true)
        shortcuts = Shortcuts.load(this)
        if (::clips.isInitialized) clips.expiryMs = s.getInt("clipExpiryMin", 60) * 60_000L
    }

    override fun onCreateInputView(): View {
        pal = makePalette()
        suggestionBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; isBaselineAligned = false }
        keysContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setOnTouchListener(smartTouch)
        }
        sidePanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        body = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; isBaselineAligned = false
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(3), 0, dp(3), 0)   // את המרווח התחתון "תופסת" השורה התחתונה (bottomReach)
            addView(suggestionBar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(suggestionBarDp)))
            addView(body, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        root.setBackgroundColor(pal.bg)
        styleNavBar()
        barState = ""
        applyOneHand()
        buildKeys()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        loadSettings()
        val type = info?.inputType ?: 0
        val cls = type and InputType.TYPE_MASK_CLASS
        val variation = type and InputType.TYPE_MASK_VARIATION
        isPassword = (cls == InputType.TYPE_CLASS_TEXT && variation in setOf(
            InputType.TYPE_TEXT_VARIATION_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
        )) || (cls == InputType.TYPE_CLASS_NUMBER && variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD) ||
            // שדות שביקשו בלי הצעות / בלי למידה (כמו שדות הכספת) מטופלים כפרטיים
            (type and InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS) != 0 ||
            ((info?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING) != 0
        noAutoCaps = isPassword || (cls == InputType.TYPE_CLASS_TEXT && variation in setOf(
            InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS,
            InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS,
            InputType.TYPE_TEXT_VARIATION_URI
        ))

        numpadKind = when (cls) {
            InputType.TYPE_CLASS_PHONE -> "phone"
            InputType.TYPE_CLASS_NUMBER -> "number"
            InputType.TYPE_CLASS_DATETIME -> "date"
            else -> null
        }
        isUrlField = cls == InputType.TYPE_CLASS_TEXT && variation == InputType.TYPE_TEXT_VARIATION_URI
        isEmailField = cls == InputType.TYPE_CLASS_TEXT && (variation == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
            variation == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS)
        domainChips = false
        // כתובות ומיילים נכתבים באנגלית: עוברים לאנגלית רק לשדה הזה, בלי לשנות את השפה השמורה
        lang = if (isUrlField || isEmailField) Lang.EN
        else if (getSharedPreferences("settings", Context.MODE_PRIVATE).getString("lang", "HE") == "EN") Lang.EN else Lang.HE

        pal = makePalette()
        if (::root.isInitialized) root.setBackgroundColor(pal.bg)
        styleNavBar()
        mode = Mode.LETTERS
        shift = false
        capsLock = false
        barState = ""
        checkRecentShot()
        clearClipSelection()
        clearVaultSelection()
        // שדה של מספר טלפון / מספר / תאריך: מתחילים בלוח המספרים
        if (numpadKind != null) mode = Mode.NUMPAD
        // חזרנו מאימות טביעת האצבע: פותחים את הכספת
        if (Vault.openPanelOnReturn && Vault.isUnlocked()) {
            Vault.openPanelOnReturn = false
            toolsOpen = true
            mode = Mode.VAULT
        }
        buildKeys()
        autoShift()
        updateSuggestions()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        autofillViews = emptyList()
        handler.removeCallbacks(repeatDelete)
        handler.removeCallbacks(letterLongPress)
        if (trackpad) endTrackpad()
        if (mode == Mode.VAULT) {
            Vault.lock()
            mode = Mode.LETTERS
        }
        predictor.save()
        stats.save()
    }

    override fun onDestroy() {
        mediaObserver?.let { try { contentResolver.unregisterContentObserver(it) } catch (_: Exception) {} }
        clipboard.removePrimaryClipChangedListener(clipListener)
        OtpStore.listener = null
        stats.save()
        io.shutdown()
        predictor.save()
        if (WordPredictor.instance === predictor) WordPredictor.instance = null
        super.onDestroy()
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        if (!trackpad) updateSuggestions()
    }

    // ---------- פריסות ----------

    private fun numberRow(): List<Key> = "1234567890".map { Key(it.toString()) }

    private fun letterRows(): List<List<Key>> = when (lang) {
        Lang.HE -> listOf(
            listOf(Key("", A_GAP, 1f)) + "קראטוןםפ".map { Key(it.toString()) } + Key("", A_GAP, 1f),
            "שדגכעיחלךף".map { Key(it.toString()) },
            "זסבהנמצתץ".map { Key(it.toString()) } + Key("⌫", A_BACK, 1.2f)
        )
        Lang.EN -> listOf(
            "qwertyuiop".map { Key(it.toString()) },
            listOf(Key("", A_GAP, 0.5f)) + "asdfghjkl".map { Key(it.toString()) } + Key("", A_GAP, 0.5f),
            listOf(Key("⇧", A_SHIFT, 1.5f)) + "zxcvbnm".map { Key(it.toString()) } + Key("⌫", A_BACK, 1.5f)
        )
    }

    private fun symbolRows(): List<List<Key>> {
        val rows = mutableListOf<List<Key>>()
        if (!showNumberRow) rows.add(numberRow())   // בלי שורת מספרים קבועה, המספרים נמצאים במסך הסימנים
        // בדומה ל-Gboard: סימני הפיסוק הנפוצים בשורה התחתונה, ו-! ? צמודים למחיקה
        rows.add("@#₪_&-+()/".map { Key(it.toString()) })
        rows.add("$€%=<>[]{}".map { Key(it.toString()) })
        rows.add("\\~*\"':;!?".map { Key(it.toString()) } + Key("⌫", A_BACK, 1.2f))
        return rows
    }

    private fun bottomRow(): List<Key> {
        val modeKey = if (mode == Mode.LETTERS) Key("?123", A_SYM, 1.4f)
        else Key(if (lang == Lang.HE) "אבג" else "ABC", A_ABC, 1.4f)
        val langName = if (lang == Lang.HE) "עברית" else "English"
        val spaceLabel = if (incognito) "‹  ${if (lang == Lang.HE) "בסתר" else "Private"} · $langName  ›" else "‹  $langName  ›"
        // בדפדפן: "/" ו-".com" במקום אמוג'י ופסיק. במייל: "@" ו-".com"
        if (isUrlField || isEmailField) {
            val special = if (isUrlField) "/" else "@"
            return listOf(modeKey, Key(special), Key(".com", ".com", 1.6f), Key(spaceLabel, A_SPACE, 3.4f), Key("."), Key("⏎", A_ENTER, 1.6f))
        }
        return listOf(modeKey, Key("😊", A_EMOJI), Key(","), Key(spaceLabel, A_SPACE, 4f), Key("."), Key("⏎", A_ENTER, 1.6f))
    }

    // ---------- בניית המקלדת ----------

    private fun buildKeys() {
        if (!::keysContainer.isInitialized) return
        keysContainer.removeAllViews()
        letterKeys.clear()
        spaceKeyView = null
        if (mode == Mode.CLIPBOARD) {
            buildClipboardPanel()
            return
        }
        if (mode == Mode.VAULT) {
            buildVaultPanel()
            return
        }
        if (mode == Mode.EMOJI) {
            buildEmojiPanel()
            return
        }
        if (mode == Mode.NUMPAD) {
            buildNumpad()
            return
        }
        val rows = mutableListOf<List<Key>>()
        if (showNumberRow) rows.add(numberRow())
        rows.addAll(if (mode == Mode.LETTERS) letterRows() else symbolRows())
        rows.add(bottomRow())

        rows.forEachIndexed { index, row ->
            val rowLayout = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; isBaselineAligned = false
                layoutDirection = View.LAYOUT_DIRECTION_LTR
            }
            val isNumbers = showNumberRow && index == 0
            val isLast = index == rows.lastIndex
            val h = dp(if (isNumbers) numberRowHeightDp else keyHeightDp)
            for (key in row) {
                val v = makeKey(key, isNumbers)
                rowLayout.addView(v, if (isLast) bottomRowParams(h, key.weight, v) else
                    LinearLayout.LayoutParams(0, h, key.weight).apply { setMargins(dp(3), dp(4), dp(3), dp(4)) })
            }
            keysContainer.addView(rowLayout)
        }
    }

    /** כמה השורה התחתונה (רווח, אנטר וכו') מקבלת למטה מעבר למה שנראה */
    private val bottomReachDp = 12

    /**
     * השורה התחתונה: אזור הלחיצה נמשך עד תחתית המקלדת, בלי לשנות את המראה.
     * המקש נראה באותו גודל (הרקע "מוזח" פנימה), אבל לחיצה נמוכה מדי עדיין נקלטת.
     */
    private fun bottomRowParams(h: Int, weight: Float, v: View): LinearLayout.LayoutParams {
        val extra = dp(bottomReachDp)
        v.background = v.background?.let { android.graphics.drawable.InsetDrawable(it, 0, 0, 0, extra) }
        v.setPadding(v.paddingLeft, v.paddingTop, v.paddingRight, v.paddingBottom + extra)
        return LinearLayout.LayoutParams(0, h + extra, weight).apply { setMargins(dp(3), dp(4), dp(3), 0) }
    }

    private fun makeKey(key: Key, isNumberRow: Boolean): View {
        if (key.action == A_GAP) return View(this)
        val isSpecial = key.action.startsWith("#") && key.action != A_SPACE
        val shiftOn = key.action == A_SHIFT && shift
        val isEnter = key.action == A_ENTER
        val isSmartLetter = mode == Mode.LETTERS && !isNumberRow &&
            key.action.length == 1 && key.action[0].isLetter()

        val tv = TextView(this).apply {
            text = labelFor(key)
            gravity = Gravity.CENTER
            setTextColor(if (isEnter) pal.enterText else if (shiftOn) Color.WHITE else pal.text)
            val size = when {
                isSpecial -> 17f
                key.action == A_SPACE -> 14f
                isNumberRow -> 16f
                else -> 22f
            }
            setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
            background = keyBackground(
                when {
                    shiftOn -> pal.accent
                    isEnter -> pal.enter
                    isSpecial -> pal.special
                    isNumberRow -> pal.num
                    else -> pal.key
                }
            )
            isClickable = true
        }

        // מחיקה ואנטר: אייקון מצויר במקום תו
        val iconRes = when (key.action) {
            A_BACK -> R.drawable.ic_backspace
            A_ENTER -> enterIcon()
            A_SHIFT -> if (capsLock) R.drawable.ic_caps else if (shift) R.drawable.ic_shift_on else R.drawable.ic_shift
            else -> 0
        }
        val view: View = if (iconRes != 0) ImageView(this).apply {
            setImageResource(iconRes)
            scaleType = ImageView.ScaleType.CENTER
            setColorFilter(if (isEnter) pal.enterText else if (shiftOn) Color.WHITE else pal.text, PorterDuff.Mode.SRC_IN)
            background = tv.background
            isClickable = true
            contentDescription = when (key.action) { A_ENTER -> "Enter"; A_SHIFT -> "Shift"; else -> "מחיקה" }
        } else tv

        if (isSmartLetter) {
            // מקשי אותיות לא מטפלים בלחיצה בעצמם: המקלדת כולה מחליטה איזו אות התכוונת (smartTouch)
            tv.isClickable = false
            letterKeys += tv to key.action
            return tv
        }

        when (key.action) {
            A_BACK -> view.setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        v.isPressed = true
                        haptic(v)
                        // מחיקה מיד אחרי תיקון אוטומטי / קיצור: מחזירה את מה שהקלדת
                        if (!tryUndoReplacement()) {
                            deleteBack()
                            handler.postDelayed(repeatDelete, 400)
                        }
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        v.isPressed = false
                        handler.removeCallbacks(repeatDelete)
                        autoShift()
                        updateSuggestions()
                    }
                }
                true
            }
            A_SPACE -> {
                attachSpaceGestures(tv, key)
                if (mode == Mode.LETTERS) spaceKeyView = tv
            }
            else -> view.setOnClickListener { v ->
                haptic(v)
                onKey(key)
            }
        }
        if (key.action == ".com") {
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            view.setOnLongClickListener { v ->
                if (vibrateOn) v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                domainChips = true
                updateSuggestions()
                true
            }
        }
        return view
    }

    /** אייקון האנטר לפי מה שהשדה מבקש: חיפוש, מעבר לכתובת, או שורה חדשה */
    private fun enterIcon(): Int {
        val ei = currentInputEditorInfo ?: return R.drawable.ic_enter
        if ((ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0) return R.drawable.ic_enter
        return when (ei.imeOptions and EditorInfo.IME_MASK_ACTION) {
            EditorInfo.IME_ACTION_SEARCH -> R.drawable.ic_search
            EditorInfo.IME_ACTION_GO, EditorInfo.IME_ACTION_NEXT, EditorInfo.IME_ACTION_SEND -> R.drawable.ic_go
            else -> R.drawable.ic_enter
        }
    }

    /** רווח: לחיצה = רווח, גרירה מהירה = החלפת שפה, לחיצה ארוכה ואז גרירה = הזזת הסמן */
    private fun attachSpaceGestures(tv: TextView, key: Key) {
        var downX = 0f
        var downY = 0f
        var swiped = false
        val longPress = Runnable {
            if (!swiped) {
                tv.isPressed = false
                startTrackpad(downX, downY)
            }
        }
        tv.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    swiped = false
                    v.isPressed = true
                    handler.postDelayed(longPress, longPressMs)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (trackpad) {
                        trackpadMove(e.rawX, e.rawY)
                    } else {
                        val dx = e.rawX - downX
                        if (abs(dx) > dp(10) || abs(e.rawY - downY) > dp(10)) handler.removeCallbacks(longPress)
                        if (!swiped && abs(dx) > dp(swipeThresholdDp)) {
                            swiped = true
                            v.isPressed = false
                            haptic(v)
                            switchLanguage()
                        }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longPress)
                    v.isPressed = false
                    if (trackpad) endTrackpad()
                    else if (!swiped) {
                        haptic(v)
                        onKey(key)
                    }
                }
                MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longPress)
                    v.isPressed = false
                    if (trackpad) endTrackpad()
                }
            }
            true
        }
    }

    private fun labelFor(key: Key): String = when {
        key.action == A_SHIFT -> if (capsLock) "⇪" else "⇧"
        lang == Lang.EN && mode == Mode.LETTERS && shift && key.label.length == 1 -> key.label.uppercase()
        else -> key.label
    }

    private fun keyBackground(normal: Int): StateListDrawable {
        fun shape(c: Int) = GradientDrawable().apply {
            cornerRadius = dp(8).toFloat()
            setColor(c)
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), shape(pal.pressed))
            addState(intArrayOf(), shape(normal))
        }
    }

    // ---------- אותיות חכמות + לחיצה ארוכה ----------

    private var lpTypedLetter = false
    private var lpDownX = 0f
    private var lpDownY = 0f

    private val letterLongPress = Runnable {
        // האות שהוקלדה בנגיעה נמחקת, כי המשתמש התכוון להזיז את הסמן
        if (lpTypedLetter) deleteBack()
        startTrackpad(lpDownX, lpDownY)
    }

    private val smartTouch = View.OnTouchListener { _, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val hit = resolveLetter(e.x, e.y)
                lpTypedLetter = hit != null
                if (hit != null) typeHit(hit)
                lpDownX = e.rawX
                lpDownY = e.rawY
                if (mode == Mode.LETTERS || mode == Mode.SYMBOLS) handler.postDelayed(letterLongPress, longPressMs)
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                handler.removeCallbacks(letterLongPress)
                if (!trackpad) {
                    val i = e.actionIndex
                    resolveLetter(e.getX(i), e.getY(i))?.let { typeHit(it) }
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (trackpad) trackpadMove(e.rawX, e.rawY)
                else if (abs(e.rawX - lpDownX) > dp(15) || abs(e.rawY - lpDownY) > dp(15)) {
                    handler.removeCallbacks(letterLongPress)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(letterLongPress)
                if (trackpad) endTrackpad()
            }
        }
        true
    }

    private fun typeHit(hit: Pair<View, String>) {
        val v = hit.first
        v.isPressed = true
        v.postDelayed({ v.isPressed = false }, 90)
        haptic(v)
        if (hit.second == " ") onKey(Key("", A_SPACE)) else onKey(Key(hit.second))
    }

    /**
     * בוחר את האות לפי שני דברים: כמה קרובה הנגיעה למרכז כל מקש,
     * וכמה סביר שהאות הזאת תגיע עכשיו לפי המילון והמילים שלך.
     */
    private fun resolveLetter(x: Float, y: Float): Pair<View, String>? {
        val probs = if (smartTargetStrength > 0 && !isPassword)
            predictor.nextLetterProbs(wordsBeforeCursor().first) else null
        // רווח מוגדל: כשהמילה כבר שלמה ונפוצה, נגיעה ליד הגבול התחתון של שורת האותיות יכולה להיות רווח
        val pEnd = if (probs != null && !isUrlField && !isEmailField) probs.end.coerceIn(0.0, 0.95) else 0.0
        val letterScale = 1.0 - pEnd
        var best: Pair<View, String>? = null
        var bestScore = Double.NEGATIVE_INFINITY
        for (k in letterKeys) {
            val v = k.first
            val row = v.parent as? View ?: continue
            val w = v.width.toFloat()
            val h = v.height.toFloat()
            if (w <= 0f || h <= 0f) continue
            val dx = ((x - (row.left + v.left + w / 2f)) / w).toDouble()
            val dy = ((y - (row.top + v.top + h / 2f)) / h).toDouble()
            if (abs(dx) > 1.3 || abs(dy) > 1.0) continue
            var score = -(dx * dx + dy * dy) / (2.0 * 0.45 * 0.45)
            if (probs != null) score += smartTargetStrength * ln(probs.of(k.second[0].lowercaseChar()) * letterScale)
            if (score > bestScore) {
                bestScore = score
                best = k
            }
        }
        val sp = spaceKeyView
        if (pEnd > 0.05 && sp != null && best != null) {
            val row = sp.parent as? View
            val keyH = best.first.height.toFloat()
            if (row != null && sp.width > 0 && keyH > 0f) {
                // מרחק אופקי: מחוץ לגבולות הרווח בלבד; אנכי: ביחידות של גובה מקש אות
                val left = row.left + sp.left
                val right = left + sp.width
                val outside = when {
                    x < left -> (left - x) / keyH
                    x > right -> (x - right) / keyH
                    else -> 0f
                }.toDouble()
                val dy = ((y - (row.top + sp.top + sp.height / 2f)) / keyH).toDouble()
                if (dy > -1.3) {
                    val score = -(outside * outside + dy * dy) / (2.0 * 0.45 * 0.45) + smartTargetStrength * ln(pEnd)
                    if (score > bestScore) return sp to " "
                }
            }
        }
        return best
    }


    // ---------- הזזת סמן בגרירה ----------

    private fun startTrackpad(x: Float, y: Float) {
        trackpad = true
        tpX = x
        tpY = y
        keysContainer.alpha = 0.35f
        if (vibrateOn) keysContainer.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
    }

    private fun trackpadMove(x: Float, y: Float) {
        val stepX = dp(cursorStepDp).toFloat()
        val stepY = dp(cursorLineDp).toFloat()
        while (x - tpX > stepX) { sendDownUpKeyEvents(KeyEvent.KEYCODE_DPAD_RIGHT); tpX += stepX }
        while (tpX - x > stepX) { sendDownUpKeyEvents(KeyEvent.KEYCODE_DPAD_LEFT); tpX -= stepX }
        while (y - tpY > stepY) { sendDownUpKeyEvents(KeyEvent.KEYCODE_DPAD_DOWN); tpY += stepY }
        while (tpY - y > stepY) { sendDownUpKeyEvents(KeyEvent.KEYCODE_DPAD_UP); tpY -= stepY }
    }

    private fun endTrackpad() {
        trackpad = false
        keysContainer.alpha = 1f
        autoShift()
        updateSuggestions()
    }

    // ---------- טיפול בלחיצות ----------

    private fun onKey(key: Key) {
        val ic = currentInputConnection ?: return
        if (!isPassword) stats.keyPressed(SystemClock.uptimeMillis())
        if (domainChips) {
            domainChips = false
            barState = ""
        }
        when (key.action) {
            A_SHIFT -> { handleShift(); return }
            A_SYM -> { mode = if (numpadKind != null) Mode.NUMPAD else Mode.SYMBOLS; buildKeys(); return }
            A_EMOJI -> { mode = Mode.EMOJI; buildKeys(); return }
            A_ABC -> { mode = Mode.LETTERS; buildKeys(); autoShift(); return }
            A_ENTER -> {
                applyAutoReplace()
                learnCurrentWord()
                handleEnter(ic)
                lastReplacement?.suffix = "\n"
            }
            A_SPACE -> handleSpace(ic)
            else -> {
                val text = if (lang == Lang.EN && mode == Mode.LETTERS && shift && key.action.length == 1) key.action.uppercase() else key.action
                    .let { if (lang == Lang.HE) mirrorBrackets(it) else it }
                val endsWord = text[0] in ".,!?;:)(\""
                if (endsWord) applyAutoReplace() else lastReplacement = null
                if (toolsOpen && text[0].isLetter()) toolsOpen = false
                if (!text[0].isLetter() && text != "'") learnCurrentWord()
                // פיסוק חכם: סימן פיסוק אחרי "מילה + רווח" נצמד למילה, והרווח עובר אחריו ("שלום ?" ← "שלום? ")
                var moveSpace = false
                if (text.length == 1 && text[0] in ".,!?;:") {
                    val b = ic.getTextBeforeCursor(2, 0)?.toString() ?: ""
                    if (b.length == 2 && b[1] == ' ' && b[0].isLetterOrDigit()) {
                        ic.deleteSurroundingText(1, 0)
                        moveSpace = true
                        lastReplacement = null   // התיקון נשאר; מחיקה אחרי זה היא מחיקה רגילה
                    }
                }
                ic.commitText(if (moveSpace) "$text " else text, 1)
                if (endsWord) lastReplacement?.suffix = text
                if (shift && !capsLock) {
                    shift = false
                    buildKeys()
                }
            }
        }
        autoShift()
        updateSuggestions()
    }

    /**
     * בטקסט עברי (מימין לשמאל) אנדרואיד הופך סוגריים בתצוגה, כך ש"(" נראה כמו ")".
     * כדי שמה שמופיע בטקסט יתאים לציור על המקש, מחליפים את הסוגר לפני ההקלדה (כמו Gboard).
     */
    private fun mirrorBrackets(t: String): String = when (t) {
        "(" -> ")"; ")" -> "("
        "[" -> "]"; "]" -> "["
        "{" -> "}"; "}" -> "{"
        "<" -> ">"; ">" -> "<"
        else -> t
    }

    private fun switchLanguage() {
        lang = if (lang == Lang.HE) Lang.EN else Lang.HE
        getSharedPreferences("settings", Context.MODE_PRIVATE).edit()
            .putString("lang", lang.name).apply()
        shift = false
        capsLock = false
        mode = Mode.LETTERS
        buildKeys()
        autoShift()
        updateSuggestions()
    }

    private fun handleShift() {
        val now = SystemClock.uptimeMillis()
        when {
            !shift -> { shift = true; capsLock = false }
            !capsLock && now - lastShiftTime < 350 -> capsLock = true
            else -> { shift = false; capsLock = false }
        }
        lastShiftTime = now
        buildKeys()
    }

    private fun handleSpace(ic: InputConnection) {
        val now = SystemClock.uptimeMillis()
        val before = ic.getTextBeforeCursor(2, 0)?.toString() ?: ""
        if (doubleSpacePeriod && now - lastSpaceTime < 350 && before.length == 2 &&
            before[1] == ' ' && before[0].isLetterOrDigit()
        ) {
            ic.deleteSurroundingText(1, 0)
            ic.commitText(". ", 1)
            lastSpaceTime = 0
            lastReplacement = null
            return
        }
        applyAutoReplace()
        learnCurrentWord()
        ic.commitText(" ", 1)
        lastReplacement?.suffix = " "
        lastSpaceTime = now
    }

    private fun handleEnter(ic: InputConnection) {
        val ei = currentInputEditorInfo
        val action = ei.imeOptions and EditorInfo.IME_MASK_ACTION
        val noEnterAction = (ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noEnterAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            ic.commitText("\n", 1)
        }
    }

    private fun deleteBack() {
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
    }

    private fun autoShift() {
        if (!autoCapsOn || lang != Lang.EN || mode != Mode.LETTERS || capsLock || noAutoCaps) return
        val ic = currentInputConnection ?: return
        val t = ic.getTextBeforeCursor(3, 0)?.toString() ?: ""
        val should = t.isEmpty() || t.endsWith("\n") ||
            (t.endsWith(" ") && t.trimEnd().let { it.isEmpty() || it.last() in ".!?" })
        if (should != shift) {
            shift = should
            buildKeys()
        }
    }

    // ---------- חיזוי מילים ----------

    private fun isWordChar(c: Char) = c.isLetter() || c == '\''

    /** מחזיר (המילה שמוקלדת עכשיו, המילה שלפניה) */
    private fun wordsBeforeCursor(): Pair<String, String?> {
        val t = currentInputConnection?.getTextBeforeCursor(80, 0)?.toString() ?: return "" to null
        var i = t.length
        while (i > 0 && isWordChar(t[i - 1])) i--
        val current = t.substring(i)
        var j = i
        while (j > 0 && t[j - 1] == ' ') j--
        if (j == i && i > 0) return current to null
        var k = j
        while (k > 0 && isWordChar(t[k - 1])) k--
        val prev = t.substring(k, j)
        return current to prev.ifEmpty { null }
    }

    private fun learnCurrentWord() {
        if (isPassword) return
        val (cur, prev) = wordsBeforeCursor()
        if (cur.isNotEmpty()) stats.wordTyped()
        if (cur.length >= 2) predictor.learn(cur, prev)
    }

    private fun pickSuggestion(cur: String, prev: String?, word: String) {
        val ic = currentInputConnection ?: return
        lastReplacement = null
        if (cur.isNotEmpty()) ic.deleteSurroundingText(cur.length, 0)
        ic.commitText("$word ", 1)
        predictor.learn(word, prev)
        if (!isPassword) {
            stats.wordTyped()
            stats.suggestionUsed(word.length - cur.length)
        }
        if (shift && !capsLock) {
            shift = false
            buildKeys()
        }
        autoShift()
        updateSuggestions()
    }

    // ---------- שורת הצעות / כלים ----------

    private fun updateSuggestions() {
        if (!::suggestionBar.isInitialized) return
        if (autofillViews.isNotEmpty() && mode == Mode.LETTERS && wordsBeforeCursor().first.isEmpty()) {
            showAutofillChips()
            return
        }
        if (domainChips) {
            barState = "domains"
            suggestionBar.removeAllViews()
            suggestionBar.layoutDirection = View.LAYOUT_DIRECTION_LTR
            for (tld in listOf(".co.il", ".org", ".net", ".il", ".io")) {
                suggestionBar.addView(chip(tld, outlined = true) {
                    currentInputConnection?.commitText(tld, 1)
                    domainChips = false
                    barState = ""
                    updateSuggestions()
                }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
            }
            return
        }
        // סרגל הכלים מוצג כשאין הצעות, כשהמשתמש פתח אותו, או כשפאנל (לוח/כספת) פתוח
        val forceTools = toolsOpen || mode == Mode.CLIPBOARD || mode == Mode.VAULT
        val words = if (forceTools) null else buildWordChips()
        val showTools = words == null || words.childCount == 0
        val state = "tools$toolsOpen$oneHand$mode"
        if (showTools && state == barState) return
        barState = if (showTools) state else "words"

        suggestionBar.removeAllViews()
        suggestionBar.layoutDirection = View.LAYOUT_DIRECTION_LTR
        val sideLp = LinearLayout.LayoutParams(dp(48), LinearLayout.LayoutParams.MATCH_PARENT)
        if (!showTools) {
            suggestionBar.addView(textButton("⋯", 20f) {
                toolsOpen = true
                updateSuggestions()
            }, sideLp)
            suggestionBar.addView(words, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f))
            return
        }
        if (toolsOpen) {
            suggestionBar.addView(textButton("✕", 20f) {
                toolsOpen = false
                barState = ""
                updateSuggestions()
            }, sideLp)
        }
        val content = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; isBaselineAligned = false }
        suggestionBar.addView(content, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f))
        val lp = {
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
                .apply { setMargins(dp(4), dp(3), dp(4), dp(3)) }
        }
        // סדר הכלים נקבע בהגדרות: הראשון ברשימה הוא הכי ימני
        content.layoutDirection = View.LAYOUT_DIRECTION_LTR
        val hidden = Themes.hiddenTools(this)
        for (id in Themes.toolOrder(this).reversed()) {
            if (id in hidden) continue
            val button = when (id) {
                "settings" -> iconButton(R.drawable.ic_settings, false) { openSettings() }
                "vault" -> iconButton(R.drawable.ic_lock, mode == Mode.VAULT) { toggleVault() }
                "clipboard" -> iconButton(R.drawable.ic_clipboard, mode == Mode.CLIPBOARD) {
                    clearClipSelection()
                    if (mode == Mode.CLIPBOARD) {
                        mode = Mode.LETTERS
                        buildKeys()
                        autoShift()
                    } else {
                        captureClip()
                        refreshScreenshots()
                        mode = Mode.CLIPBOARD
                        buildKeys()
                    }
                    updateSuggestions()
                }
                "incognito" -> iconButton(R.drawable.ic_incognito, incognito) {
                    incognito = !incognito
                    getSharedPreferences("settings", Context.MODE_PRIVATE).edit().putBoolean("incognito", incognito).apply()
                    applyIncognito()
                    toast(if (incognito) L.t(this, "מצב בסתר: לא לומדים, לא שומרים העתקות ולא אוספים סטטיסטיקה", "Private mode: no learning, no clipboard history, no stats")
                          else L.t(this, "מצב בסתר כבוי", "Private mode off"))
                    buildKeys()
                    barState = ""
                    updateSuggestions()
                }
                "onehand" -> iconButton(R.drawable.ic_one_hand, oneHand != 0) {
                    oneHand = if (oneHand == 0) 1 else 0
                    saveOneHand()
                    applyOneHand()
                    updateSuggestions()
                }
                else -> null
            } ?: continue
            content.addView(button, lp())
        }
    }

    // ---------- מילוי אוטומטי בתוך המקלדת (אנדרואיד 11 ומעלה) ----------

    /** המערכת שואלת אם המקלדת יודעת להציג הצעות מילוי; מחזירים את העיצוב של הצ'יפים */
    override fun onCreateInlineSuggestionsRequest(uiExtras: Bundle): InlineSuggestionsRequest? {
        if (!inlineAutofillOn || Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return null
        val textColor = pal.text
        // הצ'יפ של גוגל בלי רקע ובלי אייקון: את המרובע והמפתח מציירת המקלדת (showAutofillChips)
        val style = InlineSuggestionUi.newStyleBuilder()
            .setChipStyle(
                ViewStyle.Builder()
                    .setBackground(Icon.createWithResource(this, R.drawable.chip_bg_clear))
                    .setPadding(dp(4), 0, dp(10), 0)
                    .build()
            )
            .setStartIconStyle(
                ImageViewStyle.Builder()
                    .setMaxWidth(0)
                    .setMaxHeight(0)
                    .setTintList(android.content.res.ColorStateList.valueOf(Color.TRANSPARENT))
                    .build()
            )
            .setTitleStyle(TextViewStyle.Builder().setTextColor(textColor).setTextSize(recentTextSp).build())
            .setSubtitleStyle(TextViewStyle.Builder().setTextColor((textColor and 0x00FFFFFF) or (0xAA shl 24)).setTextSize(recentTextSp).build())
            .build()
        val styles = UiVersions.newStylesBuilder().addStyle(style).build()
        val spec = InlinePresentationSpec.Builder(Size(dp(80), dp(34)), Size(dp(280), dp(34)))
            .setStyle(styles).build()
        return InlineSuggestionsRequest.Builder(List(6) { spec })
            .setMaxSuggestionCount(6)
            .build()
    }

    /** הגיעו הצעות (למשל סיסמה שמורה או כרטיס אשראי מחשבון גוגל): מציגים אותן בשורת ההצעות */
    override fun onInlineSuggestionsResponse(response: InlineSuggestionsResponse): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return false
        val token = ++autofillToken
        val suggestions = response.inlineSuggestions
        if (suggestions.isEmpty()) {
            autofillViews = emptyList()
            barState = ""
            updateSuggestions()
            return true
        }
        val views = arrayOfNulls<View>(suggestions.size)
        var pending = suggestions.size
        suggestions.forEachIndexed { i, sug ->
            sug.inflate(this, Size(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT), mainExecutor) { v ->
                views[i] = v
                pending--
                if (pending == 0 && token == autofillToken) {
                    autofillViews = views.filterNotNull()
                    barState = ""
                    updateSuggestions()
                }
            }
        }
        return true
    }

    private fun showAutofillChips() {
        val state = "autofill$autofillToken"
        if (barState == state) return
        barState = state
        suggestionBar.removeAllViews()
        suggestionBar.layoutDirection = View.LAYOUT_DIRECTION_LTR
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; isBaselineAligned = false
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = if (lang == Lang.HE) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
            setPadding(dp(4), 0, dp(4), 0)
        }
        for (v in autofillViews) {
            (v.parent as? ViewGroup)?.removeView(v)
            // מרובע כמו שאר הפריטים: המפתח שלנו משמאל, והצ'יפ של גוגל (החשבון) מימין לו
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; isBaselineAligned = false
                gravity = Gravity.CENTER_VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_LTR
                setPadding(dp(10), 0, dp(2), 0)
                background = GradientDrawable().apply {
                    cornerRadius = dp(10).toFloat()
                    setColor((pal.accent and 0x00FFFFFF) or (0x26 shl 24))
                }
                addView(ImageView(this@KeyboardService).apply {
                    setImageResource(R.drawable.ic_key)
                    setColorFilter(pal.accent, PorterDuff.Mode.SRC_IN)
                    scaleType = ImageView.ScaleType.FIT_CENTER
                }, LinearLayout.LayoutParams(dp(19), dp(19)))
                addView(v, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            }
            row.addView(box, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(36))
                .apply { setMargins(dp(3), 0, dp(3), 0); gravity = Gravity.CENTER_VERTICAL })
        }
        val scroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(row, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        suggestionBar.addView(scroll, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f))
    }

    /** בונה את שורת ההצעות (קוד אימות, תיקון, קיצור, מילים, אמוג'י). ריקה = אין מה להציע */
    private fun buildWordChips(): LinearLayout {
        val content = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; isBaselineAligned = false }
        val lp = {
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
                .apply { setMargins(dp(4), dp(3), dp(4), dp(3)) }
        }
        content.layoutDirection = if (lang == Lang.HE) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        // קוד אימות שהגיע בהודעה: מוצג ראשון, לחיצה מקלידה אותו
        OtpStore.fresh(this)?.let { code ->
            // רק הקוד עצמו, בגלולה קטנה באמצע השורה, עם X להעלמה
            val codeView = recentText(code)
            centerViews += centerPill(codeView, icon = R.drawable.ic_sms,
                onTap = {
                    currentInputConnection?.commitText(code, 1)
                    OtpStore.markUsed(this@KeyboardService)
                    barState = ""
                    updateSuggestions()
                },
                onDismiss = {
                    OtpStore.markUsed(this@KeyboardService)
                    barState = ""
                    updateSuggestions()
                })
        }
        if (isPassword) {
            placeCenterViews(content)
            return content
        }
        val (cur, prev) = wordsBeforeCursor()
        var slots = 3
        // מה שהועתק או צולם הרגע: מוצע כשלא באמצע מילה
        if (cur.isEmpty() && tokenBeforeCursor().isEmpty()) slots -= addRecentChips(content, lp)

        // חזרה למילה שתוקנה קודם: מציעים את מה שהקלדת במקור
        val revert = findRevertible()
        if (revert != null) {
            val (r, suffix) = revert
            content.addView(chip("“${r.original}”", outlined = true) { revertReplacement(r, suffix) }, lp())
            slots--
        }

        // קיצורים: כל הטקסטים של הקיצור, וכל הטקסטים השמורים שמתחילים במה שהוקלד
        val token = tokenBeforeCursor()
        val keyMatches = if (token.isNotEmpty()) shortcuts[token.lowercase()].orEmpty() else emptyList()
        val snippets = (keyMatches + snippetsFor(token)).distinct()
        val correction = if (revert == null && snippets.isEmpty() && autocorrectOn && !noAutoCaps &&
            cur.length >= 2 && token == cur)
            predictor.correction(cur, prev, alphabet(), ::isAdjacent)?.let { matchCase(cur, it) } else null

        fun snippetChip(full: String): TextView {
            val preview = if (full.length > 18) full.take(17) + "…" else full
            return chip("↪ $preview", outlined = true) {
                stats.shortcutUsed(full.length - token.length)
                replaceCurrent(token, full)
            }
        }
        if (snippets.isNotEmpty() && snippets.size <= slots) {
            snippets.forEach { content.addView(snippetChip(it), lp()) }
            slots -= snippets.size
        } else if (snippets.isNotEmpty()) {
            // יותר ממה שנכנס: שורה נגללת עם כולם
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; isBaselineAligned = false
                layoutDirection = content.layoutDirection
            }
            snippets.forEach {
                row.addView(snippetChip(it).apply { setPadding(dp(12), 0, dp(12), 0) },
                    LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.MATCH_PARENT)
                        .apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
            }
            content.addView(HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                addView(row)
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f))
            slots = 0
        } else if (correction != null) {
            // התיקון שיוחל ברווח (מודגש), ואפשרות להשאיר את מה שהקלדת
            content.addView(chip(correction, outlined = true) { replaceCurrent(cur, correction) }, lp())
            content.addView(chip("“$cur”") {
                predictor.learn(cur, prev)
                predictor.learn(cur, prev)
                currentInputConnection?.commitText(" ", 1)
                updateSuggestions()
            }, lp())
            slots -= 2
        }

        if (suggestionsOn && slots > 0) {
            val words = predictor.suggest(cur, prev, 4).filter { !it.equals(correction, ignoreCase = true) }.take(slots)
            for (raw in words) {
                val w = matchCase(cur, raw)
                content.addView(chip(w) { pickSuggestion(cur, prev, w) }, lp())
            }
        }

        // אמוג'י שמתאים למילה
        if (emojiSuggestOn) {
            val emojiWord = if (cur.isNotEmpty()) cur else prev
            EmojiData.suggest(emojiWord).take(2).forEach { em ->
                content.addView(chip(em) {
                    lastReplacement = null
                    currentInputConnection?.commitText(if (cur.isNotEmpty()) " $em " else "$em ", 1)
                    rememberEmoji(em)
                    updateSuggestions()
                }, LinearLayout.LayoutParams(dp(44), LinearLayout.LayoutParams.MATCH_PARENT).apply { setMargins(dp(2), dp(3), dp(2), dp(3)) })
            }
        }
        placeCenterViews(content)
        return content
    }

    private val emailRegex = Regex("""[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}""")
    private val phoneRegex = Regex("""(?<![\w@])(\+?\d[\d \-()]{7,18}\d)(?![\w@])""")

    /**
     * מוצא מספרי טלפון ומיילים בתוך טקסט שהועתק (למשל תגובה מפייסבוק או הודעה מוואטסאפ).
     * טלפון: 9-15 ספרות, מתחיל ב-0 או ב-+ (מתעלם מסכומים, תאריכים, שעות וקודים).
     * אם כל הטקסט הוא בעצמו טלפון/מייל, אין צורך להציג אותו פעמיים.
     */
    private fun extractContacts(text: String): List<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        emailRegex.findAll(text).forEach { out += "mail" to it.value }
        phoneRegex.findAll(text).forEach { m ->
            val raw = m.value
            val digits = raw.filter { it.isDigit() }
            if (digits.length in 9..15 && (raw.startsWith("+") || digits.startsWith("0") || digits.length >= 10)) {
                out += "phone" to ((if (raw.startsWith("+")) "+" else "") + digits)
            }
        }
        val distinct = out.distinctBy { it.second }.take(2)
        if (distinct.size == 1 && text.trim().filter { !it.isWhitespace() && it != '-' } ==
            distinct[0].second.filter { !it.isWhitespace() }) return emptyList()
        return distinct
    }

    /** הטקסט בפריטי "קרה הרגע": אותו גודל, צבע ומשקל לכולם */
    private fun recentText(t: String) = TextView(this).apply {
        text = t
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
        maxWidth = dp(150)
        setTextColor(pal.text)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, recentTextSp)
        textDirection = View.TEXT_DIRECTION_FIRST_STRONG
    }

    private val recentTextSp = 14f

    /** מרובע לפריטי "קרה הרגע": אייקון (אופציונלי), תוכן, ו-X להעלמה */
    private fun centerPill(inner: View, onTap: () -> Unit, onDismiss: () -> Unit, icon: Int = 0): View =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; isBaselineAligned = false
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(9), dp(2), dp(2), dp(2))
            background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor((pal.accent and 0x00FFFFFF) or (0x26 shl 24))
            }
            isClickable = true
            setOnClickListener { v ->
                haptic(v)
                onTap()
            }
            if (icon != 0) addView(ImageView(this@KeyboardService).apply {
                setImageResource(icon)
                setColorFilter(pal.accent, PorterDuff.Mode.SRC_IN)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }, LinearLayout.LayoutParams(dp(19), dp(19)).apply { marginEnd = dp(7) })
            addView(inner)
            addView(ImageView(this@KeyboardService).apply {
                setImageResource(R.drawable.ic_close)
                setColorFilter(pal.text, PorterDuff.Mode.SRC_IN)
                alpha = 0.55f
                scaleType = ImageView.ScaleType.CENTER_INSIDE
                setPadding(dp(7), dp(7), dp(7), dp(7))
                isClickable = true
                setOnClickListener { v ->
                    haptic(v)
                    onDismiss()
                }
            }, LinearLayout.LayoutParams(dp(30), dp(30)))
        }

    /** פריטי "קרה הרגע" (קוד, צילום, העתקה) מוצמדים לצד ימין של השורה, וההצעות אחריהם */
    private fun placeCenterViews(content: LinearLayout) {
        if (centerViews.isEmpty()) return
        val special = centerViews.toList()
        centerViews.clear()
        val others = (0 until content.childCount).map { content.getChildAt(it) }
        content.removeAllViews()
        // 3 פריטים ומעלה (למשל הודעה + טלפון + מייל): שורה נגללת, כדי ששום פריט לא ייחתך
        if (special.size >= 3) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; isBaselineAligned = false
                gravity = Gravity.CENTER_VERTICAL
                layoutDirection = content.layoutDirection
            }
            special.forEach {
                row.addView(it, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(36)).apply {
                    gravity = Gravity.CENTER_VERTICAL
                    setMargins(dp(3), 0, dp(3), 0)
                })
            }
            content.addView(HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                layoutDirection = content.layoutDirection
                addView(row, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f))
            return
        }
        val rtl = content.layoutDirection == View.LAYOUT_DIRECTION_RTL
        fun addSpecial() = special.forEach {
            content.addView(it, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(36)).apply {
                gravity = Gravity.CENTER_VERTICAL
                setMargins(dp(3), 0, dp(3), 0)
            })
        }
        // ב-RTL הילד הראשון הוא הימני; ב-LTR שמים אותם בסוף כדי שיהיו מימין
        if (rtl) {
            addSpecial()
            others.forEach { content.addView(it) }
        } else {
            others.forEach { content.addView(it) }
            if (others.isEmpty()) content.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            addSpecial()
        }
    }

    private fun chip(label: String, filled: Boolean = false, outlined: Boolean = false, onTap: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            gravity = Gravity.CENTER
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            setTextColor(if (filled) Color.WHITE else if (outlined) pal.accent else pal.text)
            if (outlined) setTypeface(typeface, android.graphics.Typeface.BOLD)
            background = keyBackground(if (filled) pal.accent else Color.TRANSPARENT)
            isClickable = true
            setOnClickListener { v ->
                haptic(v)
                onTap()
            }
        }

    // ---------- תיקון אוטומטי וקיצורים ----------

    private class Replacement(val original: String, val replaced: String, val isShortcut: Boolean, var suffix: String = "")
    private var lastReplacement: Replacement? = null
    // תיקונים אחרונים: אם חוזרים אחורה למילה שתוקנה, המילה המקורית מוצעת בשורת ההצעות
    private val recentReplacements = ArrayDeque<Replacement>()
    private var suppressOnce: String? = null

    private fun alphabet() = if (lang == Lang.HE) "אבגדהוזחטיכךלמםנןסעפףצץקרשת" else "abcdefghijklmnopqrstuvwxyz"

    private val finals = mapOf('ך' to 'כ', 'ם' to 'מ', 'ן' to 'נ', 'ף' to 'פ', 'ץ' to 'צ')
    private val keyPos: Map<Char, Pair<Float, Int>> by lazy {
        val m = HashMap<Char, Pair<Float, Int>>()
        listOf(1f to "קראטוןםפ", 0f to "שדגכעיחלךף", 0f to "זסבהנמצתץ").forEachIndexed { r, (off, row) ->
            row.forEachIndexed { i, c -> m[c] = (off + i) to r }
        }
        listOf(0f to "qwertyuiop", 0.5f to "asdfghjkl", 1.5f to "zxcvbnm").forEachIndexed { r, (off, row) ->
            row.forEachIndexed { i, c -> m[c] = (off + i) to r }
        }
        m
    }

    /** האם שתי אותיות שכנות במקלדת (או אותה אות בצורה סופית/רגילה) */
    private fun isAdjacent(a: Char, b: Char): Boolean {
        if (finals[a] == b || finals[b] == a) return true
        val pa = keyPos[a] ?: return false
        val pb = keyPos[b] ?: return false
        return abs(pa.first - pb.first) <= 1.1f && abs(pa.second - pb.second) <= 1
    }

    private fun matchCase(typed: String, word: String): String = when {
        typed.length > 1 && typed.all { !it.isLetter() || it.isUpperCase() } && typed.any { it.isUpperCase() } -> word.uppercase()
        typed.isNotEmpty() && typed[0].isUpperCase() -> word.replaceFirstChar { it.uppercase() }
        else -> word
    }

    /** לפני סיום מילה (רווח, פיסוק, אנטר): מחליף קיצור או מתקן שגיאה */
    private fun applyAutoReplace() {
        lastReplacement = null
        if (isPassword || noAutoCaps || mode != Mode.LETTERS) return
        val ic = currentInputConnection ?: return
        val (word, prev) = wordsBeforeCursor()
        val token = tokenBeforeCursor()
        if (token.isEmpty()) return
        if (token == suppressOnce) {
            suppressOnce = null
            return
        }
        // קיצורים לא מוחלפים ברווח: הם רק מוצגים בשורת ההצעות בזמן ההקלדה.
        // קיצור הוא מילה שהמשתמש הגדיר, אז גם לא מתקנים אותו.
        if (shortcuts.containsKey(token.lowercase())) return
        val shortcut: String? = null
        val cur = word
        if (cur.isEmpty()) return
        val replacement =
            if (autocorrectOn && token == word)
                predictor.correction(cur, prev, alphabet(), ::isAdjacent)?.let { matchCase(cur, it) }
            else null
        if (replacement == null || replacement == cur) return
        ic.deleteSurroundingText(cur.length, 0)
        ic.commitText(replacement, 1)
        lastReplacement = Replacement(cur, replacement, shortcut != null)
        recentReplacements.addFirst(lastReplacement!!)
        while (recentReplacements.size > 10) recentReplacements.removeLast()
        if (shortcut != null) stats.shortcutUsed(replacement.length - cur.length) else stats.correctionApplied()
    }

    /** הרצף שלפני הסמן: אותיות, ספרות, + וגרש (למשל קיצור או תחילת מספר טלפון) */
    private fun tokenBeforeCursor(): String {
        val t = currentInputConnection?.getTextBeforeCursor(64, 0)?.toString() ?: return ""
        var i = t.length
        while (i > 0 && (t[i - 1].isLetterOrDigit() || t[i - 1] == '+' || t[i - 1] == '\'')) i--
        return t.substring(i)
    }

    /**
     * השלמה מתוך הקיצורים: אם מה שמוקלד הוא תחילת אחד הטקסטים השמורים
     * (למשל "052" ← מספר הטלפון המלא), מחזיר אותו.
     */
    private fun snippetsFor(token: String): List<String> {
        if (token.length < 2) return emptyList()
        return shortcuts.values.flatten().distinct()
            .filter { it.length > token.length && it.startsWith(token, ignoreCase = true) }
            .sortedBy { it.length }
    }

    /** החלפה ידנית מתוך שורת ההצעות */
    private fun replaceCurrent(cur: String, replacement: String) {
        val ic = currentInputConnection ?: return
        if (cur.isNotEmpty()) ic.deleteSurroundingText(cur.length, 0)
        ic.commitText("$replacement ", 1)
        lastReplacement = null
        if (!shortcuts.containsKey(cur.lowercase()) && shortcuts.values.none { replacement in it }) predictor.learn(replacement, wordsBeforeCursor().second)
        autoShift()
        updateSuggestions()
    }

    /** האם הסמן נמצא מיד אחרי מילה שתוקנה לאחרונה (או אחריה ורווח) */
    private fun findRevertible(): Pair<Replacement, String>? {
        if (recentReplacements.isEmpty()) return null
        val before = currentInputConnection?.getTextBeforeCursor(80, 0)?.toString() ?: return null
        for (r in recentReplacements) {
            for (suffix in listOf("", " ")) {
                val tail = r.replaced + suffix
                if (!before.endsWith(tail)) continue
                // גבול מילה: לפני התיקון לא צריכה להיות אות (כדי לא להתבלבל עם מילה ארוכה יותר)
                val i = before.length - tail.length - 1
                if (i >= 0 && isWordChar(before[i])) continue
                return r to suffix
            }
        }
        return null
    }

    /** מחזיר את המילה המקורית במקום התיקון, גם אם כבר עברת למילה הבאה ומחקת חזרה */
    private fun revertReplacement(r: Replacement, suffix: String) {
        val ic = currentInputConnection ?: return
        ic.deleteSurroundingText(r.replaced.length + suffix.length, 0)
        ic.commitText(r.original + suffix, 1)
        recentReplacements.remove(r)
        lastReplacement = null
        if (r.isShortcut) suppressOnce = r.original
        else {
            stats.correctionUndone()
            // המשתמש התכוון למילה הזאת: מעכשיו היא נחשבת מוכרת
            predictor.learn(r.original, null)
            predictor.learn(r.original, null)
        }
        updateSuggestions()
    }

    private fun tryUndoReplacement(): Boolean {
        val r = lastReplacement ?: return false
        lastReplacement = null
        recentReplacements.remove(r)
        val ic = currentInputConnection ?: return false
        val tail = r.replaced + r.suffix
        if (ic.getTextBeforeCursor(tail.length, 0)?.toString() != tail) return false
        ic.deleteSurroundingText(tail.length, 0)
        ic.commitText(r.original, 1)
        if (!r.isShortcut) stats.correctionUndone()
        if (r.isShortcut) {
            suppressOnce = r.original     // לא להחליף שוב ברווח הבא
        } else {
            // המשתמש התכוון למילה הזאת: מעכשיו היא נחשבת מוכרת
            predictor.learn(r.original, null)
            predictor.learn(r.original, null)
        }
        updateSuggestions()
        return true
    }

    // ---------- אמוג'י ----------

    private var emojiTab = 0   // 0 = אחרונים

    private fun recentEmojis(): List<String> =
        getSharedPreferences("settings", Context.MODE_PRIVATE).getString("emojiRecent", "")!!
            .split(" ").filter { it.isNotBlank() }

    private fun rememberEmoji(em: String) {
        if (!isPassword) stats.emojiUsed(em)
        val list = (listOf(em) + recentEmojis().filter { it != em }).take(32)
        getSharedPreferences("settings", Context.MODE_PRIVATE).edit().putString("emojiRecent", list.joinToString(" ")).apply()
    }

    /** לוח מספרים גדול, כמו בחייגן, לשדות טלפון, מספר ותאריך */
    private fun buildNumpad() {
        val kind = numpadKind ?: "number"
        val abc = Key(if (lang == Lang.HE) "אבג" else "ABC", A_ABC)
        val rows: List<List<Key>> = when (kind) {
            "phone" -> listOf(
                listOf(Key("1"), Key("2"), Key("3"), Key("⌫", A_BACK)),
                listOf(Key("4"), Key("5"), Key("6"), Key("+")),
                listOf(Key("7"), Key("8"), Key("9"), Key("⏎", A_ENTER)),
                listOf(Key("*"), Key("0"), Key("#"), abc)
            )
            "date" -> listOf(
                listOf(Key("1"), Key("2"), Key("3"), Key("⌫", A_BACK)),
                listOf(Key("4"), Key("5"), Key("6"), Key("-")),
                listOf(Key("7"), Key("8"), Key("9"), Key("⏎", A_ENTER)),
                listOf(Key("/"), Key("0"), Key(":"), abc)
            )
            else -> listOf(
                listOf(Key("1"), Key("2"), Key("3"), Key("⌫", A_BACK)),
                listOf(Key("4"), Key("5"), Key("6"), Key("-")),
                listOf(Key("7"), Key("8"), Key("9"), Key("⏎", A_ENTER)),
                listOf(Key(","), Key("0"), Key("."), abc)
            )
        }
        // אותו גובה כולל כמו המקלדת הרגילה, כדי שהמסך לא יקפוץ
        val keyboardH = (if (showNumberRow) dp(numberRowHeightDp + 8) else 0) + 4 * dp(keyHeightDp + 8) + dp(8)
        val rowH = (keyboardH - dp(8)) / 4 - dp(8)
        for (row in rows) {
            val rowLayout = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; isBaselineAligned = false
                layoutDirection = View.LAYOUT_DIRECTION_LTR
            }
            val isLast = row === rows.last()
            row.forEachIndexed { i, key ->
                val w = if (i == 3) 0.9f else 1f
                val v = makeKey(key, false)
                (v as? TextView)?.setTextSize(TypedValue.COMPLEX_UNIT_SP, if (key.action.length == 1 && key.action[0].isDigit()) 26f else 20f)
                rowLayout.addView(v, if (isLast) bottomRowParams(rowH, w, v) else
                    LinearLayout.LayoutParams(0, rowH, w).apply { setMargins(dp(3), dp(4), dp(3), dp(4)) })
            }
            keysContainer.addView(rowLayout)
        }
    }

    private fun buildEmojiPanel() {
        val tabsH = dp(numberRowHeightDp)
        val bottomH = dp(keyHeightDp)
        val keyboardH = (if (showNumberRow) dp(numberRowHeightDp + 8) else 0) + 4 * dp(keyHeightDp + 8) + dp(8)
        val gridH = keyboardH - (tabsH + dp(8)) - (bottomH + dp(4) + dp(bottomReachDp))

        // לשוניות קטגוריות
        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; isBaselineAligned = false
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val tabIcons = listOf("🕘") + EmojiData.categories.map { it.first }
        tabIcons.forEachIndexed { i, icon ->
            tabs.addView(TextView(this).apply {
                text = icon
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
                background = keyBackground(if (i == emojiTab) pal.special else Color.TRANSPARENT)
                isClickable = true
                setOnClickListener { v ->
                    haptic(v)
                    emojiTab = i
                    buildKeys()
                }
            }, LinearLayout.LayoutParams(0, tabsH, 1f).apply { setMargins(dp(1), dp(4), dp(1), dp(4)) })
        }
        keysContainer.addView(tabs)

        // רשת האמוג'י
        val list = if (emojiTab == 0) recentEmojis() else EmojiData.categories[emojiTab - 1].second
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (list.isEmpty()) {
            grid.addView(TextView(this).apply {
                text = L.t(this@KeyboardService, "כאן יופיעו האמוג'י שהשתמשת בהם לאחרונה", "Your recent emoji will show up here")
                gravity = Gravity.CENTER
                setTextColor(pal.text)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                setPadding(dp(12), dp(40), dp(12), dp(12))
            })
        }
        for (rowItems in list.chunked(8)) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; isBaselineAligned = false
                layoutDirection = View.LAYOUT_DIRECTION_LTR
            }
            for (i in 0 until 8) {
                val em = rowItems.getOrNull(i)
                val lp = LinearLayout.LayoutParams(0, dp(46), 1f)
                if (em == null) {
                    row.addView(View(this), lp)
                    continue
                }
                row.addView(TextView(this).apply {
                    text = em
                    gravity = Gravity.CENTER
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
                    background = keyBackground(Color.TRANSPARENT)
                    isClickable = true
                    setOnClickListener { v ->
                        haptic(v)
                        currentInputConnection?.commitText(em, 1)
                        rememberEmoji(em)
                    }
                }, lp)
            }
            grid.addView(row)
        }
        keysContainer.addView(ScrollView(this).apply { addView(grid) },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, gridH))

        // שורה תחתונה: חזרה, רווח, מחיקה
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; isBaselineAligned = false
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        fun addBottom(key: Key) {
            val v = makeKey(key, false)
            bottom.addView(v, bottomRowParams(bottomH, key.weight, v))
        }
        addBottom(Key(if (lang == Lang.HE) "אבג" else "ABC", A_ABC, 1.4f))
        addBottom(Key(if (lang == Lang.HE) "רווח" else "space", A_SPACE, 5f))
        addBottom(Key("⌫", A_BACK, 1.4f))
        keysContainer.addView(bottom)
    }

    private fun toggleVault() {
        clearVaultSelection()
        if (mode == Mode.VAULT) {
            // יציאה מהכספת נועלת אותה
            Vault.lock()
            mode = Mode.LETTERS
            buildKeys()
            autoShift()
            updateSuggestions()
            return
        }
        if (Vault.isUnlocked()) {
            mode = Mode.VAULT
            buildKeys()
            updateSuggestions()
            return
        }
        // פותחים את מסך טביעת האצבע; כשהוא ייסגר והמקלדת תחזור, הכספת תיפתח
        Vault.openPanelOnReturn = true
        startActivity(Intent(this, VaultAuthActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private val selectedVault = mutableSetOf<Long>()
    private var selectingVault = false

    private fun clearVaultSelection() {
        selectingVault = false
        selectedVault.clear()
    }

    private fun openVaultManager() {
        mode = Mode.LETTERS   // כדי שהכספת לא תינעל כשהמקלדת נסגרת
        clearVaultSelection()
        startActivity(Intent(this, VaultActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun buildVaultPanel() {
        val keyboardH = (if (showNumberRow) dp(numberRowHeightDp + 8) else 0) + 4 * dp(keyHeightDp + 8) + dp(8)
        val cardH = keyboardH / clipRowsVisible - dp(6)
        val items = Vault.load(this)
        val grid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            if (selectingVault) setPadding(0, 0, 0, dp(72))
        }
        // הכרטיסים + כרטיס "הוספה" בסוף
        val cells: List<Vault.Item?> = items + listOf<Vault.Item?>(null)
        for (rowItems in cells.chunked(2)) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; isBaselineAligned = false
                layoutDirection = View.LAYOUT_DIRECTION_RTL
            }
            for (i in 0 until 2) {
                val lp = LinearLayout.LayoutParams(0, cardH, 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
                when {
                    i >= rowItems.size -> row.addView(View(this), lp)
                    rowItems[i] == null -> row.addView(addVaultCard(items.isEmpty()), lp)
                    else -> row.addView(vaultCard(rowItems[i]!!), lp)
                }
            }
            grid.addView(row)
        }
        val frame = FrameLayout(this)
        frame.addView(ScrollView(this).apply { clipToPadding = false; addView(grid) },
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        if (selectingVault) {
            frame.addView(floatingBar(selectedVault.size, { clearVaultSelection(); buildKeys() }, listOf(
                R.drawable.ic_edit to { openVaultManager() },
                R.drawable.ic_trash to {
                    Vault.save(this, items.filter { it.id !in selectedVault })
                    clearVaultSelection()
                    buildKeys()
                }
            )), floatingLp())
        }
        keysContainer.addView(frame, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, keyboardH))
    }

    private fun vaultCard(item: Vault.Item): View {
        val selected = selectingVault && item.id in selectedVault
        val frame = FrameLayout(this).apply {
            background = cardBackground(selected)
            isClickable = true
        }
        frame.addView(TextView(this).apply {
            // הערך עצמו לא מוצג, רק השם; לחיצה מקלידה אותו ישירות (בלי לעבור בלוח)
            text = "${item.label}\n${"•".repeat(item.value.length.coerceIn(4, 10))}"
            gravity = Gravity.CENTER
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(pal.text)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setPadding(dp(10), dp(4), dp(10), dp(4))
        }, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        if (selectingVault) addSelectionCircle(frame, selected)
        frame.setOnClickListener { v ->
            haptic(v)
            if (selectingVault) {
                if (!selectedVault.remove(item.id)) selectedVault.add(item.id)
                if (selectedVault.isEmpty()) selectingVault = false
                buildKeys()
            } else {
                Vault.unlock()
                currentInputConnection?.commitText(item.value, 1)
            }
        }
        frame.setOnLongClickListener { v ->
            if (vibrateOn) v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            if (!selectedVault.remove(item.id)) selectedVault.add(item.id)
            selectingVault = selectedVault.isNotEmpty()
            buildKeys()
            true
        }
        return frame
    }

    private fun addVaultCard(empty: Boolean): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        background = cardBackground(false)
        isClickable = true
        addView(ImageView(this@KeyboardService).apply {
            setImageResource(R.drawable.ic_plus)
            setColorFilter(pal.accent, PorterDuff.Mode.SRC_IN)
        })
        addView(TextView(this@KeyboardService).apply {
            text = if (empty) L.t(this@KeyboardService, "הכספת ריקה · הוספת פריט", "Vault is empty · Add item") else L.t(this@KeyboardService, "הוספת פריט", "Add item")
            gravity = Gravity.CENTER
            setTextColor(pal.accent)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        })
        setOnClickListener { v ->
            haptic(v)
            openVaultManager()
        }
    }

    // ---------- רכיבים משותפים: סרגל פעולות צף ועיגול בחירה ----------

    /** סרגל פעולות צף בתחתית הפאנל: סגירה (עם מספר הנבחרים) ואייקוני פעולה */
    private fun floatingBar(count: Int, onClose: () -> Unit, actions: List<Pair<Int, () -> Unit>>): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; isBaselineAligned = false
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(4), dp(6), dp(4))
            background = GradientDrawable().apply {
                cornerRadius = dp(26).toFloat()
                // מעט שקוף, כדי שהכרטיסים ייראו מתחת
                setColor((pal.special and 0x00FFFFFF) or (0xEE shl 24))
                setStroke(dp(1), (pal.pressed and 0x00FFFFFF) or (0x55 shl 24))
            }
            elevation = dp(10).toFloat()
        }
        // סגירה + מספר הנבחרים
        val close = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; isBaselineAligned = false
            gravity = Gravity.CENTER
            setPadding(dp(10), 0, dp(12), 0)
            background = keyBackground(Color.TRANSPARENT)
            isClickable = true
            addView(ImageView(this@KeyboardService).apply {
                setImageResource(R.drawable.ic_close)
                setColorFilter(pal.text, PorterDuff.Mode.SRC_IN)
            })
            addView(TextView(this@KeyboardService).apply {
                text = count.toString()
                setTextColor(pal.text)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setPadding(dp(6), 0, 0, 0)
            })
            setOnClickListener { v ->
                haptic(v)
                onClose()
            }
        }
        bar.addView(close, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(44)))
        bar.addView(View(this).apply { setBackgroundColor((pal.text and 0x00FFFFFF) or (0x33 shl 24)) },
            LinearLayout.LayoutParams(dp(1), dp(24)).apply { setMargins(dp(4), 0, dp(4), 0) })
        for ((icon, onTap) in actions) {
            bar.addView(ImageView(this).apply {
                setImageResource(icon)
                scaleType = ImageView.ScaleType.CENTER
                setColorFilter(pal.text, PorterDuff.Mode.SRC_IN)
                background = keyBackground(Color.TRANSPARENT)
                isClickable = true
                setOnClickListener { v ->
                    haptic(v)
                    onTap()
                }
            }, LinearLayout.LayoutParams(dp(52), dp(44)))
        }
        return bar
    }

    private fun floatingLp() = FrameLayout.LayoutParams(
        FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
        Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
    ).apply { setMargins(dp(12), dp(12), dp(12), dp(14)) }

    private fun addSelectionCircle(frame: FrameLayout, selected: Boolean) {
        frame.addView(TextView(this).apply {
            text = if (selected) "✓" else ""
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(if (selected) pal.accent else pal.key)
                setStroke(dp(2), if (selected) pal.accent else pal.pressed)
            }
        }, FrameLayout.LayoutParams(dp(18), dp(18), Gravity.TOP or Gravity.START).apply { setMargins(dp(6), dp(6), dp(6), 0) })
    }

    private fun textButton(label: String, size: Float, onTap: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            gravity = Gravity.CENTER
            setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
            setTextColor(pal.text)
            background = keyBackground(Color.TRANSPARENT)
            isClickable = true
            setOnClickListener { v ->
                haptic(v)
                onTap()
            }
        }

    private fun iconButton(res: Int, active: Boolean, onTap: () -> Unit): ImageView =
        ImageView(this).apply {
            setImageResource(res)
            scaleType = ImageView.ScaleType.CENTER
            setColorFilter(if (active) Color.WHITE else pal.text, PorterDuff.Mode.SRC_IN)
            background = keyBackground(if (active) pal.accent else Color.TRANSPARENT)
            isClickable = true
            setOnClickListener { v ->
                haptic(v)
                onTap()
            }
        }

    private fun openSettings(askScreenshots: Boolean = false) {
        val intent = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("askScreenshots", askScreenshots)
        startActivity(intent)
        requestHideSelf(0)
    }

    // ---------- מצב יד אחת ----------

    private fun saveOneHand() {
        getSharedPreferences("settings", Context.MODE_PRIVATE).edit().putInt("oneHand", oneHand).apply()
    }

    private fun applyOneHand() {
        if (!::body.isInitialized) return
        body.removeAllViews()
        sidePanel.removeAllViews()
        if (oneHand == 0) {
            body.addView(keysContainer, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            return
        }
        val btnLp = { LinearLayout.LayoutParams(dp(48), dp(48)).apply { setMargins(0, dp(8), 0, dp(8)) } }
        sidePanel.addView(sideButton(R.drawable.ic_expand) {
            oneHand = 0
            saveOneHand()
            applyOneHand()
            updateSuggestions()
        }, btnLp())
        sidePanel.addView(sideButton(if (oneHand == 1) R.drawable.ic_chevron_left else R.drawable.ic_chevron_right) {
            oneHand = if (oneHand == 1) 2 else 1
            saveOneHand()
            applyOneHand()
        }, btnLp())
        val keysLp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, oneHandWidth)
        val sideLp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f - oneHandWidth)
        if (oneHand == 1) {
            body.addView(sidePanel, sideLp)
            body.addView(keysContainer, keysLp)
        } else {
            body.addView(keysContainer, keysLp)
            body.addView(sidePanel, sideLp)
        }
    }

    private fun sideButton(icon: Int, onTap: () -> Unit): ImageView = ImageView(this).apply {
        setImageResource(icon)
        scaleType = ImageView.ScaleType.CENTER
        setColorFilter(pal.text, PorterDuff.Mode.SRC_IN)
        background = keyBackground(pal.special)
        isClickable = true
        setOnClickListener { v ->
            haptic(v)
            onTap()
        }
    }

    // ---------- לוח (Clipboard) ----------

    private fun captureClip(fresh: Boolean = false) {
        if (SystemClock.uptimeMillis() < ignoreClipUntil) return   // העתקה שהמקלדת עצמה עשתה
        try {
            val clip = clipboard.primaryClip ?: return
            if (clip.itemCount == 0) return
            val desc = clip.description
            // לא שומרים טקסט שהאפליקציה סימנה כרגיש (למשל סיסמה ממנהל סיסמאות)
            if (desc?.extras?.getBoolean("android.content.extra.IS_SENSITIVE", false) == true) return
            val item = clip.getItemAt(0)
            val uri = item.uri
            if (uri != null) {
                val type = contentResolver.getType(uri)
                    ?: if (desc?.hasMimeType("image/*") == true) "image/png" else null
                if (type != null && type.startsWith("image/")) {
                    if (!incognito) saveClipImage(uri, type, fresh)
                    return
                }
            }
            val text = item.coerceToText(this)?.toString()?.trim() ?: return
            if (text.isNotEmpty()) {
                clips.add(text)
                if (fresh) {
                    recentCopyText = text
                    recentCopyImage = null
                    recentCopyTime = System.currentTimeMillis()
                    scheduleRecentRefresh(recentCopyMs)
                    barState = ""
                    updateSuggestions()
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun extFor(mime: String) = when {
        mime.contains("png") -> "png"
        mime.contains("gif") -> "gif"
        mime.contains("webp") -> "webp"
        else -> "jpg"
    }

    /** תמונה שהועתקה: שומרים עותק בתיקייה של האפליקציה, כי ההרשאה לקובץ המקורי זמנית */
    private fun saveClipImage(uri: Uri, mime: String, fresh: Boolean = false) {
        io.execute {
            try {
                val dir = File(filesDir, "clip_images").apply { mkdirs() }
                val f = File(dir, "img_${System.currentTimeMillis()}.${extFor(mime)}")
                val input = contentResolver.openInputStream(uri) ?: return@execute
                input.use { inp -> f.outputStream().use { inp.copyTo(it) } }
                val local = FileProvider.getUriForFile(this, authority, f).toString()
                handler.post {
                    clips.addImage(local, System.currentTimeMillis())
                    if (fresh) {
                        recentCopyImage = local
                        recentCopyText = null
                        recentCopyTime = System.currentTimeMillis()
                        scheduleRecentRefresh(recentCopyMs)
                        barState = ""
                        updateSuggestions()
                    }
                    if (mode == Mode.CLIPBOARD) buildKeys()
                }
            } catch (_: Exception) {
            }
        }
    }

    private fun applyIncognito() {
        if (::predictor.isInitialized) predictor.paused = incognito
        if (::stats.isInitialized) stats.paused = incognito
        if (::clips.isInitialized) clips.paused = incognito
    }

    private val checkShotRunnable = Runnable { checkRecentShot() }

    /** מחפש צילום מסך שצולם בדקות האחרונות, כדי להציע אותו בשורת ההצעות */
    private fun checkRecentShot() {
        if (!screenshotsOn || !hasImagePermission()) return
        val since = (System.currentTimeMillis() - recentShotMs) / 1000
        val collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        @Suppress("DEPRECATION")
        val pathCol = if (Build.VERSION.SDK_INT >= 29) MediaStore.Images.Media.RELATIVE_PATH else MediaStore.Images.Media.DATA
        try {
            contentResolver.query(
                collection,
                arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DATE_ADDED),
                "${MediaStore.Images.Media.DATE_ADDED} >= ? AND $pathCol LIKE ?",
                arrayOf(since.toString(), "%Screenshot%"),
                "${MediaStore.Images.Media.DATE_ADDED} DESC"
            )?.use { c ->
                if (!c.moveToFirst()) return
                val uri = ContentUris.withAppendedId(collection, c.getLong(0)).toString()
                val time = c.getLong(1) * 1000
                if (uri == recentShot || uri in dismissedRecent) return
                recentShot = uri
                recentShotTime = time
                clips.addImage(uri, time)
                scheduleRecentRefresh(recentShotMs - (System.currentTimeMillis() - time))
                barState = ""
                updateSuggestions()
            }
        } catch (_: Exception) {
        }
    }

    /** מרענן את שורת ההצעות כשההצעה "עכשיו" פגה */
    private fun scheduleRecentRefresh(afterMs: Long) {
        handler.postDelayed({
            barState = ""
            updateSuggestions()
        }, afterMs.coerceAtLeast(0) + 200)
    }

    /** צ'יפ "עכשיו": תמונה ממוזערת או אייקון, טקסט, ו-X להעלמה */
    private fun recentChip(thumb: String?, icon: Int, label: String, onTap: () -> Unit, onDismiss: () -> Unit): View {
        val chipView = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; isBaselineAligned = false
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), 0, dp(4), 0)
            background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor((pal.accent and 0x00FFFFFF) or (0x22 shl 24))
            }
            isClickable = true
            setOnClickListener { v ->
                haptic(v)
                onTap()
            }
        }
        if (thumb != null) {
            val iv = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                background = GradientDrawable().apply { cornerRadius = dp(5).toFloat(); setColor(pal.special) }
                clipToOutline = true
            }
            chipView.addView(iv, LinearLayout.LayoutParams(dp(26), dp(26)))
            loadThumb(thumb, iv)
        } else {
            chipView.addView(ImageView(this).apply {
                setImageResource(icon)
                setColorFilter(pal.accent, PorterDuff.Mode.SRC_IN)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }, LinearLayout.LayoutParams(dp(20), dp(20)))
        }
        chipView.addView(TextView(this).apply {
            text = label
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(pal.text)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            setPadding(dp(6), 0, dp(4), 0)
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        chipView.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_close)
            setColorFilter(pal.text, PorterDuff.Mode.SRC_IN)
            alpha = 0.6f
            scaleType = ImageView.ScaleType.CENTER
            isClickable = true
            setOnClickListener { v ->
                haptic(v)
                onDismiss()
            }
        }, LinearLayout.LayoutParams(dp(28), LinearLayout.LayoutParams.MATCH_PARENT))
        return chipView
    }

    /** מוסיף לשורת ההצעות את "הודבק הרגע" ו"צולם הרגע", אם עדיין בתוקף */
    private fun addRecentChips(content: LinearLayout, lp: () -> LinearLayout.LayoutParams): Int {
        var added = 0
        val now = System.currentTimeMillis()
        fun refresh() { barState = ""; updateSuggestions() }
        val shot = recentShot
        if (shot != null && now - recentShotTime < recentShotMs && shot !in dismissedRecent) {
            // צילום מסך: תמונה ממוזערת עומדת (בצורת מסך הטלפון) בגלולה באמצע השורה, עם X להעלמה
            val iv = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                background = GradientDrawable().apply {
                    cornerRadius = dp(3).toFloat()
                    setColor(pal.special)
                }
                clipToOutline = true
                contentDescription = L.t(this@KeyboardService, "צילום מסך", "Screenshot")
                layoutParams = LinearLayout.LayoutParams(dp(15), dp(26))
            }
            loadThumb(shot, iv)
            centerViews += centerPill(iv, icon = R.drawable.ic_screenshot,
                onTap = {
                    pasteImage(shot)
                    dismissedRecent += shot
                    refresh()
                },
                onDismiss = {
                    dismissedRecent += shot
                    refresh()
                })
        }
        val copyKey = recentCopyText ?: recentCopyImage
        if (copyKey != null && now - recentCopyTime < recentCopyMs && copyKey !in dismissedRecent && copyKey != shot) {
            val img = recentCopyImage
            val text = recentCopyText
            val onTap = {
                if (img != null) pasteImage(img) else currentInputConnection?.commitText(text, 1)
                dismissedRecent += copyKey
                refresh()
            }
            val onDismiss = { dismissedRecent += copyKey; refresh() }
            if (img != null) {
                // תמונה שהועתקה: בדיוק כמו צילום מסך
                val iv = ImageView(this).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    background = GradientDrawable().apply { cornerRadius = dp(4).toFloat(); setColor(pal.special) }
                    clipToOutline = true
                    layoutParams = LinearLayout.LayoutParams(dp(15), dp(26))
                }
                loadThumb(img, iv)
                centerViews += centerPill(iv, onTap, onDismiss, icon = R.drawable.ic_image)
            } else {
                val ents = extractContacts(text ?: "")
                val tv = recentText(text?.replace('\n', ' ') ?: "")
                // כשיש גם טלפון/מייל, הטקסט המלא מוצג קצר יותר כדי שהכל ייכנס
                if (ents.isNotEmpty()) tv.maxWidth = dp(70)
                centerViews += centerPill(tv, onTap, onDismiss, icon = R.drawable.ic_clipboard)
                // טלפונים ומיילים מתוך הטקסט שהועתק: כל אחד בנפרד, להדבקה ישירה
                for ((kind, value) in ents) {
                    val key = "ent:$value"
                    if (key in dismissedRecent) continue
                    centerViews += centerPill(recentText(value).apply { maxWidth = dp(130) },
                        onTap = {
                            currentInputConnection?.commitText(value, 1)
                            dismissedRecent += key
                            refresh()
                        },
                        onDismiss = { dismissedRecent += key; refresh() },
                        icon = if (kind == "mail") R.drawable.ic_mail else R.drawable.ic_phone)
                }
            }
        }
        return centerViews.size
    }

    private fun imagePermission() =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasImagePermission() =
        checkSelfPermission(imagePermission()) == PackageManager.PERMISSION_GRANTED

    /** מוסיף ללוח את צילומי המסך שצולמו בתוך זמן השמירה */
    private fun refreshScreenshots() {
        if (!screenshotsOn || !hasImagePermission()) return
        val since = (System.currentTimeMillis() - clips.expiryMs) / 1000
        val collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        @Suppress("DEPRECATION")
        val pathCol = if (Build.VERSION.SDK_INT >= 29) MediaStore.Images.Media.RELATIVE_PATH else MediaStore.Images.Media.DATA
        val found = mutableListOf<Pair<String, Long>>()
        try {
            contentResolver.query(
                collection,
                arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DATE_ADDED),
                "${MediaStore.Images.Media.DATE_ADDED} >= ? AND $pathCol LIKE ?",
                arrayOf(since.toString(), "%Screenshot%"),
                "${MediaStore.Images.Media.DATE_ADDED} DESC"
            )?.use { c ->
                val idIdx = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val dateIdx = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
                while (c.moveToNext() && found.size < 6) {
                    found += ContentUris.withAppendedId(collection, c.getLong(idIdx)).toString() to c.getLong(dateIdx) * 1000
                }
            }
        } catch (_: Exception) {
        }
        for ((uri, time) in found) clips.addImage(uri, time)
    }

    // ---------- בחירה מרובה בלוח ----------

    private val selectedClips = mutableSetOf<ClipStore.Item>()
    private var selectingClips = false

    private fun clearClipSelection() {
        selectingClips = false
        selectedClips.clear()
    }

    private fun toggleClipSelection(item: ClipStore.Item) {
        if (!selectedClips.remove(item)) selectedClips.add(item)
        if (selectedClips.isEmpty()) selectingClips = false
        buildKeys()
    }

    private fun buildClipboardPanel() {
        val keyboardH = (if (showNumberRow) dp(numberRowHeightDp + 8) else 0) + 4 * dp(keyHeightDp + 8) + dp(8)
        val cardH = keyboardH / clipRowsVisible - dp(6)
        val grid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            // מקום לסרגל הצף, כדי שהשורה האחרונה לא תוסתר
            if (selectingClips) setPadding(0, 0, 0, dp(72))
        }
        val items = clips.list()
        if (screenshotsOn && !hasImagePermission()) {
            grid.addView(TextView(this).apply {
                text = L.t(this@KeyboardService, "כדי לראות כאן צילומי מסך, לחץ ואשר גישה לתמונות", "Tap to allow photo access and see screenshots here")
                gravity = Gravity.CENTER
                setTextColor(pal.text)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                setPadding(dp(10), dp(10), dp(10), dp(10))
                background = cardBackground(true)
                isClickable = true
                setOnClickListener { v ->
                    haptic(v)
                    openSettings(askScreenshots = true)
                }
            }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
        }
        if (items.isEmpty()) {
            grid.addView(TextView(this).apply {
                text = L.t(this@KeyboardService, "עדיין אין כאן כלום. מה שתעתיק יופיע כאן.", "Nothing here yet. Things you copy will show up here.")
                gravity = Gravity.CENTER
                setTextColor(pal.text)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                setPadding(dp(12), dp(50), dp(12), dp(12))
            })
        }
        for (rowItems in items.chunked(clipColumns)) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; isBaselineAligned = false
                layoutDirection = View.LAYOUT_DIRECTION_RTL
            }
            for (i in 0 until clipColumns) {
                val lp = LinearLayout.LayoutParams(0, cardH, 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
                val item = rowItems.getOrNull(i)
                row.addView(if (item == null) View(this) else clipCardView(item), lp)
            }
            grid.addView(row)
        }
        val frame = FrameLayout(this)
        frame.addView(ScrollView(this).apply { clipToPadding = false; addView(grid) },
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        if (selectingClips) {
            val allPinned = selectedClips.all { it.pinned }
            frame.addView(floatingBar(selectedClips.size, { clearClipSelection(); buildKeys() }, listOf(
                R.drawable.ic_pin to {
                    selectedClips.forEach { if (it.pinned == allPinned) clips.togglePin(it) }
                    clearClipSelection(); buildKeys()
                },
                R.drawable.ic_lock to { moveSelectedToVault(); clearClipSelection(); buildKeys() },
                R.drawable.ic_trash to {
                    selectedClips.toList().forEach { clips.remove(it) }
                    clearClipSelection(); buildKeys()
                }
            )), floatingLp())
        }
        keysContainer.addView(frame, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, keyboardH))
    }

    /** כרטיס בלוח: טקסט או תמונה. לחיצה = הדבקה; לחיצה ארוכה = מצב בחירה */
    private fun clipCardView(item: ClipStore.Item): View {
        val selected = selectingClips && item in selectedClips
        val frame = FrameLayout(this).apply {
            background = cardBackground(item.pinned || selected)
            setPadding(dp(2), dp(2), dp(2), dp(2))
            isClickable = true
        }
        val match = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        if (item.image) {
            val iv = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                background = GradientDrawable().apply {
                    cornerRadius = dp(6).toFloat()
                    setColor(pal.special)
                }
                clipToOutline = true
            }
            frame.addView(iv, match)
            loadThumb(item.text, iv)
        } else {
            frame.addView(TextView(this).apply {
                text = item.text
                maxLines = 3
                ellipsize = TextUtils.TruncateAt.END
                textDirection = View.TEXT_DIRECTION_FIRST_STRONG
                textAlignment = View.TEXT_ALIGNMENT_TEXT_START
                gravity = Gravity.TOP
                setTextColor(pal.text)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                // מקום לעיגול הבחירה / הסיכה בפינות
                setPadding(dp(8), dp(if (selectingClips || item.pinned) 18 else 6), dp(8), dp(4))
            }, match)
        }
        if (item.pinned) {
            frame.addView(ImageView(this).apply {
                setImageResource(R.drawable.ic_pin)
                setColorFilter(pal.accent, PorterDuff.Mode.SRC_IN)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }, FrameLayout.LayoutParams(dp(15), dp(15), Gravity.TOP or Gravity.END).apply { setMargins(dp(5), dp(4), dp(5), 0) })
        }
        if (selectingClips) addSelectionCircle(frame, selected)
        frame.setOnClickListener { v ->
            haptic(v)
            when {
                selectingClips -> toggleClipSelection(item)
                item.image -> pasteImage(item.text)
                else -> currentInputConnection?.commitText(item.text, 1)
            }
        }
        frame.setOnLongClickListener { v ->
            if (vibrateOn) v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            if (selectingClips) toggleClipSelection(item)
            else {
                selectingClips = true
                selectedClips.add(item)
                buildKeys()
            }
            true
        }
        return frame
    }

    /** מעביר את הטקסטים שנבחרו לכספת (ומוחק אותם מהלוח) */
    private fun moveSelectedToVault() {
        val texts = selectedClips.filter { !it.image }
        if (texts.isEmpty()) {
            toast(L.t(this, "אפשר להעביר לכספת רק טקסט", "Only text can be moved to the vault"))
            return
        }
        val vaultItems = Vault.load(this)
        texts.forEachIndexed { i, clip ->
            val label = clip.text.replace('\n', ' ').let { if (it.length > 24) it.take(23) + "…" else it }
            vaultItems += Vault.Item(System.currentTimeMillis() + i, label, clip.text)
            clips.remove(clip)
        }
        Vault.save(this, vaultItems)
        toast(if (texts.size == 1) L.t(this, "הועבר לכספת", "Moved to vault") else L.t(this, "${texts.size} פריטים הועברו לכספת", "${texts.size} items moved to vault"))
    }

    private fun loadThumb(src: String, into: ImageView) {
        thumbCache.get(src)?.let {
            into.setImageBitmap(it)
            return
        }
        into.tag = src
        io.execute {
            val bmp = try { decodeThumb(src) } catch (_: Exception) { null }
            handler.post {
                if (bmp != null) {
                    thumbCache.put(src, bmp)
                    if (into.tag == src) into.setImageBitmap(bmp)
                } else {
                    // התמונה נמחקה מהטלפון: מורידים אותה מהלוח
                    clips.forget(src)
                    if (mode == Mode.CLIPBOARD) buildKeys()
                }
            }
        }
    }

    private fun decodeThumb(src: String): Bitmap? {
        val uri = Uri.parse(src)
        if (Build.VERSION.SDK_INT >= 29) return contentResolver.loadThumbnail(uri, Size(320, 320), null)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) } ?: return null
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 320 && bounds.outHeight / (sample * 2) >= 320) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    }

    /** שולח תמונה לאפליקציה; אם היא לא מקבלת תמונות מהמקלדת, מעתיק את התמונה ללוח של המערכת */
    private fun pasteImage(src: String) {
        val ei = currentInputEditorInfo ?: return
        io.execute {
            val shared = try { shareableUri(Uri.parse(src)) } catch (_: Exception) { null }
            handler.post {
                if (shared == null) {
                    toast(L.t(this, "לא הצלחתי לפתוח את התמונה", "Couldn't open the image"))
                    return@post
                }
                val (uri, mime) = shared
                val ic = currentInputConnection
                val accepts = EditorInfoCompat.getContentMimeTypes(ei).any { ClipDescription.compareMimeTypes(mime, it) }
                var sent = false
                if (ic != null && accepts) {
                    val info = InputContentInfoCompat(uri, ClipDescription("image", arrayOf(mime)), null)
                    sent = InputConnectionCompat.commitContent(
                        ic, ei, info, InputConnectionCompat.INPUT_CONTENT_GRANT_READ_URI_PERMISSION, null
                    )
                }
                if (!sent) {
                    ignoreClipUntil = SystemClock.uptimeMillis() + 1500
                    clipboard.setPrimaryClip(ClipData.newUri(contentResolver, "image", uri))
                    toast(L.t(this, "האפליקציה הזאת לא מקבלת תמונות מהמקלדת. התמונה הועתקה, הדבק אותה בלחיצה ארוכה בשדה", "This app doesn't accept images from keyboards. The image was copied, long-press the field to paste"))
                }
            }
        }
    }

    /** מחזיר כתובת שאפשר לתת לאפליקציה אחרת (עותק דרך FileProvider) */
    private fun shareableUri(src: Uri): Pair<Uri, String> {
        val mime = contentResolver.getType(src) ?: "image/png"
        if (src.authority == authority) return src to mime
        val dir = File(cacheDir, "share").apply { mkdirs() }
        dir.listFiles()?.forEach { if (System.currentTimeMillis() - it.lastModified() > 3_600_000) it.delete() }
        val f = File(dir, "img_${System.currentTimeMillis()}.${extFor(mime)}")
        val input = contentResolver.openInputStream(src) ?: throw IllegalStateException("no stream")
        input.use { inp -> f.outputStream().use { inp.copyTo(it) } }
        return FileProvider.getUriForFile(this, authority, f) to mime
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    private fun cardBackground(highlight: Boolean): StateListDrawable {
        fun shape(c: Int) = GradientDrawable().apply {
            cornerRadius = dp(8).toFloat()
            setColor(c)
            if (highlight) setStroke(dp(2), pal.accent)
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), shape(pal.pressed))
            addState(intArrayOf(), shape(pal.key))
        }
    }

    /**
     * השורה שמתחת למקלדת (חץ ההסתרה וכדור הארץ להחלפת מקלדת) שייכת למערכת,
     * אבל הצבעים שלה נלקחים מחלון המקלדת: רקע בצבע המקלדת, ואייקונים כהים במצב בהיר.
     */
    private fun styleNavBar() {
        val w = window?.window ?: return
        try {
            w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            w.navigationBarColor = pal.bg
            if (Build.VERSION.SDK_INT >= 28) w.navigationBarDividerColor = pal.bg
            val light = !pal.dark
            if (Build.VERSION.SDK_INT >= 30) {
                val flag = android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
                w.insetsController?.setSystemBarsAppearance(if (light) flag else 0, flag)
            } else if (Build.VERSION.SDK_INT >= 26) {
                @Suppress("DEPRECATION")
                val v = w.decorView.systemUiVisibility
                @Suppress("DEPRECATION")
                w.decorView.systemUiVisibility = if (light) v or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
                else v and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
            }
        } catch (_: Exception) {
        }
    }

    // ---------- עזרים ----------

    private fun haptic(v: View) {
        if (vibrateOn) v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }

    private fun isDark(): Boolean =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
