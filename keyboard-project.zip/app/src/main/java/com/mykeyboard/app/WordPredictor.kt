package com.mykeyboard.app

import android.content.Context
import kotlin.math.ln

/**
 * חיזוי מילים ואותיות:
 * - מילון בסיס (assets): מילה + שכיחות
 * - מילים שהמשתמש מקליד בפועל, וצמדי מילים (מה בא אחרי מה)
 * - מודל "האות הבאה": לפי מה שכבר הוקלד במילה, כמה סביר שכל אות תגיע עכשיו
 */
class WordPredictor(context: Context) {

    companion object {
        /** המופע שהמקלדת משתמשת בו כרגע (כדי שמסך ההגדרות יוכל לאפס אותו) */
        @Volatile
        var instance: WordPredictor? = null

        fun clearSaved(context: Context) {
            context.getSharedPreferences("predictor", Context.MODE_PRIVATE).edit().clear().apply()
        }
    }

    class LetterProbs(val map: Map<Char, Double>, val floor: Double) {
        fun of(c: Char): Double = map[c] ?: floor
    }

    private val prefs = context.getSharedPreferences("predictor", Context.MODE_PRIVATE)
    private val baseScore = HashMap<String, Int>()      // 1..1000 לפי דירוג שכיחות
    private val baseCount = HashMap<String, Double>()   // שכיחות גולמית
    private var sorted: Array<String> = emptyArray()
    private var learnedLetterWeight = 1.0
    private val learned = HashMap<String, Int>()
    private val bigrams = HashMap<String, HashMap<String, Int>>()
    private var dirty = 0

    private var cachePrefix: String? = null
    private var cacheProbs = LetterProbs(emptyMap(), 1.0)

    init {
        for (file in listOf("he_words.txt", "en_words.txt")) {
            try {
                val lines = context.assets.open(file).bufferedReader(Charsets.UTF_8)
                    .readLines().filter { it.isNotBlank() }
                val n = lines.size
                lines.forEachIndexed { i, line ->
                    val parts = line.trim().split(' ', '\t')
                    val w = parts[0].lowercase()
                    if (w.isNotEmpty() && !baseScore.containsKey(w)) {
                        baseScore[w] = 1 + ((n - i).toLong() * 999L / n).toInt()
                        baseCount[w] = parts.getOrNull(1)?.toDoubleOrNull() ?: (n - i).toDouble()
                    }
                }
            } catch (_: Exception) {
            }
        }
        sorted = baseScore.keys.toTypedArray()
        sorted.sort()
        // משקל של מילה שלמדנו מהמשתמש במודל האותיות: כמו מילה שכיחה בינונית
        val counts = baseCount.values.sorted()
        if (counts.isNotEmpty()) learnedLetterWeight = counts[(counts.size * 0.98).toInt().coerceAtMost(counts.size - 1)]

        prefs.getString("learned", null)?.lineSequence()?.forEach { line ->
            val p = line.split('\t')
            if (p.size == 2) p[1].toIntOrNull()?.let { learned[p[0]] = it }
        }
        prefs.getString("bigrams", null)?.lineSequence()?.forEach { line ->
            val p = line.split('\t')
            if (p.size == 3) p[2].toIntOrNull()?.let { bigrams.getOrPut(p[0]) { HashMap() }[p[1]] = it }
        }
    }

    /** עובר על כל מילות הבסיס שמתחילות ב-pre (חיפוש בינארי במערך ממוין) */
    private inline fun forEachBaseWithPrefix(pre: String, f: (String) -> Unit) {
        var lo = 0
        var hi = sorted.size
        while (lo < hi) {
            val mid = (lo + hi) ushr 1
            if (sorted[mid] < pre) lo = mid + 1 else hi = mid
        }
        var i = lo
        while (i < sorted.size && sorted[i].startsWith(pre)) {
            f(sorted[i])
            i++
        }
    }

    fun suggest(prefix: String, prev: String?, limit: Int = 3): List<String> {
        val pre = prefix.lowercase()
        val next = prev?.lowercase()?.let { bigrams[it] }
        val scores = HashMap<String, Double>()

        fun consider(w: String) {
            if (!w.startsWith(pre) || w == pre) return
            val b = baseScore[w] ?: 0
            val l = learned[w] ?: 0
            val bg = next?.get(w) ?: 0
            // מילה שלא במילון צריכה להופיע לפחות פעמיים לפני שמציעים אותה (סינון שגיאות הקלדה)
            if (b == 0 && l < 2 && bg < 2) return
            scores[w] = b + l * 400.0 + bg * 3000.0
        }

        if (pre.isEmpty()) {
            next?.keys?.forEach { consider(it) }
        } else {
            forEachBaseWithPrefix(pre) { consider(it) }
            learned.keys.forEach { consider(it) }
        }
        return scores.entries.sortedByDescending { it.value }.take(limit).map { it.key }
    }

    /** ההסתברות של כל אות להיות האות הבאה, בהינתן תחילת המילה */
    fun nextLetterProbs(prefix: String): LetterProbs {
        val pre = prefix.lowercase()
        if (pre == cachePrefix) return cacheProbs

        val weights = HashMap<Char, Double>()
        var total = 0.0
        fun add(w: String, weight: Double) {
            if (w.length > pre.length && w.startsWith(pre)) {
                val c = w[pre.length]
                weights[c] = (weights[c] ?: 0.0) + weight
                total += weight
            }
        }
        forEachBaseWithPrefix(pre) { w ->
            add(w, (baseCount[w] ?: 0.0) + (learned[w] ?: 0) * learnedLetterWeight)
        }
        for ((w, c) in learned) {
            if (c >= 2 && !baseScore.containsKey(w)) add(w, c * learnedLetterWeight)
        }

        val result = if (total <= 0.0) {
            LetterProbs(emptyMap(), 1.0)   // אין מידע: רק מיקום האצבע קובע
        } else {
            val alpha = total * 0.02       // החלקה: גם אות "לא צפויה" תמיד אפשרית
            val denom = total + alpha * 30
            LetterProbs(weights.mapValues { (it.value + alpha) / denom }, alpha / denom)
        }
        cachePrefix = pre
        cacheProbs = result
        return result
    }

    private fun knownExact(w: String) = baseScore.containsKey(w) || (learned[w] ?: 0) >= 2

    /** האם המילה מוכרת (כולל אותיות שימוש בעברית בתחילת המילה: ו, ה, ב, ל, מ, ש, כ) */
    fun isKnown(word: String): Boolean {
        val w = word.lowercase()
        if (knownExact(w)) return true
        var rest = w
        repeat(2) {
            if (rest.length > 2 && rest[0] in "והבלמשכ") {
                rest = rest.substring(1)
                if (knownExact(rest)) return true
            }
        }
        return false
    }

    /**
     * תיקון אוטומטי: למילה לא מוכרת, מחפש מילה מוכרת במרחק שינוי אחד
     * (אות מוחלפת, חסרה, מיותרת או שתי אותיות בסדר הפוך).
     * החלפה במקש שכן זולה יותר, כי זו טעות הקלדה נפוצה.
     */
    fun correction(word: String, prev: String?, alphabet: String, adjacent: (Char, Char) -> Boolean): String? {
        val w = word.lowercase()
        if (w.length < 2 || isKnown(w)) return null
        val maxCost = if (w.length <= 2) 1.0 else 9.0
        val cands = HashMap<String, Double>()
        fun add(c: String, cost: Double) {
            if (cost > maxCost || c.length < 2 || !knownExact(c)) return
            val old = cands[c]
            if (old == null || cost < old) cands[c] = cost
        }
        // אות מיותרת (זולה יותר כשזו אות כפולה, כמו "helllo")
        for (i in w.indices) add(w.removeRange(i, i + 1), if (i > 0 && w[i] == w[i - 1]) 0.8 else 1.6)
        for (i in w.indices) for (ch in alphabet) {
            if (ch != w[i]) add(w.substring(0, i) + ch + w.substring(i + 1), if (adjacent(w[i], ch)) 0.6 else 1.8)
        }
        // אות חסרה (זולה יותר כשחסרה אות כפולה, כמו "helo")
        for (i in 0..w.length) for (ch in alphabet) {
            val doubled = (i > 0 && w[i - 1] == ch) || (i < w.length && w[i] == ch)
            add(w.substring(0, i) + ch + w.substring(i), if (doubled) 0.8 else 1.4)
        }
        for (i in 0 until w.length - 1) {
            add(w.substring(0, i) + w[i + 1] + w[i] + w.substring(i + 2), 1.0)
        }
        val next = prev?.lowercase()?.let { bigrams[it] }
        fun freq(c: String) = (baseCount[c] ?: 0.0) + (learned[c] ?: 0) * learnedLetterWeight + 1.0
        val scores = HashMap<String, Double>()
        for ((c, cost) in cands) scores[c] = ln(freq(c)) - cost * 3.0 + (next?.get(c) ?: 0) * 1.5

        // רווח חסר ("זהממש" ← "זה ממש"), או אות שנלחצה במקום רווח ("זהבממש" ← "זה ממש")
        fun common(x: String) = (baseScore[x] ?: 0) >= 680 || (learned[x] ?: 0) >= 3
        fun addSplit(a: String, b: String, cost: Double) {
            if (a.length < 2 || b.length < 2 || !common(a) || !common(b)) return
            val bonus = (bigrams[a]?.get(b) ?: 0) * 1.5
            val sc = ln(kotlin.math.sqrt(freq(a) * freq(b))) - cost * 3.0 + bonus
            val key = "$a $b"
            if (sc > (scores[key] ?: Double.NEGATIVE_INFINITY)) scores[key] = sc
        }
        if (w.length >= 4) {
            for (i in 2..w.length - 2) addSplit(w.substring(0, i), w.substring(i), 1.2)
            for (i in 2..w.length - 3) {
                if (w[i] in "בהנמצcvbnm") addSplit(w.substring(0, i), w.substring(i + 1), 1.5)
            }
        }
        return scores.maxByOrNull { it.value }?.key
    }

    fun learn(word: String, prev: String?) {
        val w = word.lowercase()
        if (w.length < 2) return
        learned[w] = (learned[w] ?: 0) + 1
        if (!prev.isNullOrEmpty()) {
            val m = bigrams.getOrPut(prev.lowercase()) { HashMap() }
            m[w] = (m[w] ?: 0) + 1
        }
        cachePrefix = null
        dirty++
        if (dirty >= 5) save()
    }

    /** המילים שהמשתמש מקליד הכי הרבה */
    fun topLearned(n: Int): List<Pair<String, Int>> =
        learned.entries.sortedByDescending { it.value }.take(n).map { it.key to it.value }

    fun learnedCount() = learned.size

    /** מחיקת מילה אחת מהלמידה (למשל מילה פרטית או שגיאה שנלמדה) */
    fun forget(word: String) {
        val w = word.lowercase()
        learned.remove(w)
        bigrams.remove(w)
        bigrams.values.forEach { it.remove(w) }
        cachePrefix = null
        dirty++
        save()
    }

    /** מחיקת כל מה שהמקלדת למדה מהמשתמש (המילון הבסיסי נשאר) */
    fun clearLearned() {
        learned.clear()
        bigrams.clear()
        cachePrefix = null
        dirty = 0
        prefs.edit().clear().apply()
    }

    fun save() {
        if (dirty == 0) return
        if (learned.size > 8000) {
            learned.entries.sortedBy { it.value }.take(learned.size - 6000).forEach { learned.remove(it.key) }
        }
        val l = learned.entries.joinToString("\n") { "${it.key}\t${it.value}" }
        val b = buildString {
            for ((p, m) in bigrams) for ((w, c) in m) append(p).append('\t').append(w).append('\t').append(c).append('\n')
        }
        prefs.edit().putString("learned", l).putString("bigrams", b).apply()
        dirty = 0
    }
}
