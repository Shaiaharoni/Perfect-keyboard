package com.mykeyboard.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

/** מזהה קוד אימות בתוך טקסט של הודעה */
object OtpParser {
    private val keywords = listOf(
        "קוד", "אימות", "סיסמ", "חד פעמי", "חד-פעמי", "כניסה",
        "code", "otp", "verification", "verify", "pin", "passcode", "password"
    )
    // 4-8 ספרות (או 123-456), שלא חלק ממספר טלפון, סכום, תאריך או שעה
    private val codeRegex = Regex("""(?<![\d₪$.,/:+])(?<!\d-)(\d{3}[- ]\d{3}|\d{4,8})(?![\d%₪/:\-])""")

    fun extract(message: String): String? {
        val lower = message.lowercase()
        val keywordPositions = keywords.flatMap { k ->
            generateSequence(lower.indexOf(k).takeIf { it >= 0 }) { prev ->
                lower.indexOf(k, prev + 1).takeIf { it >= 0 }
            }.toList()
        }
        if (keywordPositions.isEmpty()) return null
        val matches = codeRegex.findAll(message).toList()
        if (matches.isEmpty()) return null
        // בוחרים את המספר הכי קרוב למילת מפתח (עדיפות למספר שבא אחריה)
        val best = matches.minByOrNull { m ->
            keywordPositions.minOf { k -> if (m.range.first >= k) m.range.first - k else (k - m.range.last) * 2 }
        } ?: return null
        return best.value.replace("-", "").replace(" ", "")
    }
}

/** הקוד האחרון שהתקבל, שמור בטלפון כדי שהמקלדת תציג אותו גם אם לא רצה כשההודעה הגיעה */
object OtpStore {
    private const val VALID_MS = 10 * 60 * 1000L
    var listener: (() -> Unit)? = null

    fun save(context: Context, code: String) {
        context.getSharedPreferences("otp", Context.MODE_PRIVATE).edit()
            .putString("code", code).putLong("time", System.currentTimeMillis()).putBoolean("used", false).apply()
        listener?.invoke()
    }

    fun fresh(context: Context): String? {
        val p = context.getSharedPreferences("otp", Context.MODE_PRIVATE)
        if (p.getBoolean("used", true)) return null
        if (System.currentTimeMillis() - p.getLong("time", 0) > VALID_MS) return null
        return p.getString("code", null)
    }

    fun markUsed(context: Context) {
        context.getSharedPreferences("otp", Context.MODE_PRIVATE).edit().putBoolean("used", true).apply()
    }
}

/** מקבל הודעות SMS נכנסות ושומר קוד אימות אם יש בהן */
class SmsCodeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        if (!context.getSharedPreferences("settings", Context.MODE_PRIVATE).getBoolean("smsCodes", true)) return
        val body = try {
            Telephony.Sms.Intents.getMessagesFromIntent(intent).joinToString("") { it.messageBody ?: "" }
        } catch (_: Exception) {
            return
        }
        OtpParser.extract(body)?.let { OtpStore.save(context, it) }
    }
}
