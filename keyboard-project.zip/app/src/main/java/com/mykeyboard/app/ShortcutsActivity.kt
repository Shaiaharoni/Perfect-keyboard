package com.mykeyboard.app

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** ניהול קיצורי הטקסט */
class ShortcutsActivity : Activity() {

    private lateinit var list: LinearLayout
    private lateinit var map: MutableMap<String, String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "קיצורי טקסט"
        map = Shortcuts.load(this)
        val pad = dp(20)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(pad, dp(12), pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "כשתקליד את הקיצור ותלחץ רווח, הוא יוחלף בטקסט המלא. מחיקה אחת מיד אחרי מבטלת את ההחלפה."
            textSize = 14f
            setPadding(0, 0, 0, dp(12))
        })
        root.addView(Button(this).apply {
            text = "+ קיצור חדש"
            isAllCaps = false
            setOnClickListener { editDialog(null) }
        })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        setContentView(ScrollView(this).apply { addView(root) })
        render()
    }

    private fun render() {
        list.removeAllViews()
        if (map.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "עדיין אין קיצורים. למשל: \"כת\" ← הכתובת שלך, \"תח\" ← תודה רבה וחג שמח."
                textSize = 15f
                setPadding(0, dp(24), 0, 0)
            })
        }
        for ((key, value) in map) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(12), 0, dp(12))
                isClickable = true
                setOnClickListener { editDialog(key) }
            }
            row.addView(TextView(this).apply {
                text = key
                textSize = 16f
                setTypeface(typeface, Typeface.BOLD)
            })
            row.addView(TextView(this).apply {
                text = value
                textSize = 14f
                maxLines = 2
            })
            list.addView(row)
            list.addView(View(this).apply { setBackgroundColor(0x22000000) },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1))
        }
    }

    private fun editDialog(existing: String?) {
        // NO_SUGGESTIONS: המקלדת לא תחליף קיצורים ולא תתקן בתוך השדות האלה
        val shortField = EditText(this).apply {
            hint = "הקיצור (מילה אחת, למשל: כת)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setText(existing ?: "")
        }
        val fullField = EditText(this).apply {
            hint = "הטקסט המלא"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setText(existing?.let { map[it] } ?: "")
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(shortField)
            addView(fullField)
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle(if (existing == null) "קיצור חדש" else "עריכת קיצור")
            .setView(box)
            .setPositiveButton("שמור") { _, _ ->
                val k = shortField.text.toString().trim().lowercase()
                val v = fullField.text.toString()
                if (k.isEmpty() || v.isEmpty() || k.contains(' ')) return@setPositiveButton
                if (existing != null && existing != k) map.remove(existing)
                map[k] = v
                Shortcuts.save(this, map)
                render()
            }
            .setNegativeButton("ביטול", null)
        if (existing != null) {
            dialog.setNeutralButton("מחק") { _, _ ->
                map.remove(existing)
                Shortcuts.save(this, map)
                render()
            }
        }
        dialog.show()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
