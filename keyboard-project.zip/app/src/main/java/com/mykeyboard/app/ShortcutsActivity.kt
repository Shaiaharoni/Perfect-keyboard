package com.mykeyboard.app

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

/** ניהול הקיצורים והמילים השמורות */
class ShortcutsActivity : Activity() {

    private lateinit var ui: UiKit
    private lateinit var map: MutableMap<String, String>

    override fun onCreate(savedInstanceState: Bundle?) {
        ui = UiKit(this)
        ui.applyTheme()
        super.onCreate(savedInstanceState)
        ui.styleWindow()
        map = Shortcuts.load(this)
        render()
    }

    private fun render() {
        val page = ui.page()
        val col = page.column
        ui.header(col, ui.t("קיצורים ומילים שמורות", "Shortcuts & saved text"),
            ui.t("טקסט שחוזר על עצמו, בלחיצה אחת", "Text you type often, in one tap"), back = true)

        // הסבר קצר איך זה עובד
        val how = ui.card(col)
        ui.add(how, LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(16), ui.dp(14), ui.dp(16), ui.dp(14))
            addView(ui.titleBlock(ui.t("איך זה עובד", "How it works"),
                ui.t("מקלידים את הקיצור ולוחצים רווח, והוא מוחלף בטקסט המלא. או שמתחילים להקליד את הטקסט עצמו (למשל 05 של מספר טלפון), וכל מה שמתאים מוצע בשורת ההצעות.",
                    "Type the shortcut and press space to expand it. Or start typing the saved text itself (like 05 of a phone number) and every match shows up in the suggestion bar."),
                maxSubLines = 6))
        })

        if (map.isEmpty()) {
            ui.emptyState(col, R.drawable.ic_edit, ui.t("עדיין אין קיצורים", "No shortcuts yet"),
                ui.t("למשל \"טל\" ← מספר הטלפון שלך, או \"כת\" ← הכתובת שלך.", "For example \"ph\" → your phone number, or \"addr\" → your address."))
        } else {
            ui.section(col, ui.t("${map.size} קיצורים", "${map.size} shortcuts"))
            val card = ui.card(col)
            for ((key, value) in map) {
                ui.add(card, LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(ui.dp(16), ui.dp(12), ui.dp(12), ui.dp(12))
                    background = ui.ripple()
                    isClickable = true
                    setOnClickListener { edit(key) }
                    // הקיצור בתוך "גלולה" צבעונית
                    addView(TextView(this@ShortcutsActivity).apply {
                        text = key
                        textSize = 14f
                        setTypeface(typeface, Typeface.BOLD)
                        setTextColor(ui.accent)
                        gravity = Gravity.CENTER
                        background = ui.rounded(ui.tint(ui.accent, 0x22), 10)
                        setPadding(ui.dp(10), ui.dp(6), ui.dp(10), ui.dp(6))
                        minWidth = ui.dp(48)
                    }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = ui.dp(12) })
                    addView(TextView(this@ShortcutsActivity).apply {
                        text = value
                        textSize = 15f
                        setTextColor(ui.textMain)
                        maxLines = 2
                        ellipsize = android.text.TextUtils.TruncateAt.END
                        textDirection = android.view.View.TEXT_DIRECTION_FIRST_STRONG
                    }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                    addView(android.widget.ImageView(this@ShortcutsActivity).apply {
                        setImageResource(R.drawable.ic_edit)
                        setColorFilter(ui.textSub, android.graphics.PorterDuff.Mode.SRC_IN)
                    })
                })
            }
        }
        ui.fab(page) { edit(null) }
    }

    private fun edit(existing: String?) {
        ui.formSheet(
            if (existing == null) ui.t("קיצור חדש", "New shortcut") else ui.t("עריכת קיצור", "Edit shortcut"),
            listOf(
                UiKit.FieldSpec(ui.t("קיצור", "Shortcut"), ui.t("מילה אחת, למשל: טל", "One word, e.g. ph"), existing ?: ""),
                UiKit.FieldSpec(ui.t("טקסט מלא", "Full text"), ui.t("למשל: 0523675306", "e.g. 0523675306"), existing?.let { map[it] } ?: "", multiline = true)
            ),
            secure = true,   // שהמקלדת לא תחליף קיצורים בתוך השדות האלה
            onDelete = existing?.let { { map.remove(it); Shortcuts.save(this, map); render() } }
        ) { values ->
            val k = values[0].trim().lowercase()
            val v = values[1]
            if (k.isEmpty() || v.isEmpty() || k.contains(' ')) return@formSheet false
            if (existing != null && existing != k) map.remove(existing)
            map[k] = v
            Shortcuts.save(this, map)
            render()
            true
        }
    }
}
