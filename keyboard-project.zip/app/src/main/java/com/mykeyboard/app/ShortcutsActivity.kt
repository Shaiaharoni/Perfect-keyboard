package com.mykeyboard.app

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

/** ניהול הקיצורים והמילים השמורות */
class ShortcutsActivity : Activity() {

    private lateinit var ui: UiKit
    private lateinit var entries: MutableList<Shortcuts.Entry>

    override fun onCreate(savedInstanceState: Bundle?) {
        ui = UiKit(this)
        ui.applyTheme()
        super.onCreate(savedInstanceState)
        ui.styleWindow()
        entries = Shortcuts.loadEntries(this)
        render()
    }

    private fun render() {
        val page = ui.page()
        val col = page.column
        ui.header(col, ui.t("קיצורים ומילים שמורות", "Shortcuts & saved text"),
            ui.t("טקסט שחוזר על עצמו, בלחיצה אחת", "Text you type often, in one tap"), back = true)

        // הסבר קצר איך זה עובד
        val how = ui.card(col)
        ui.add(how, LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(16), ui.dp(14), ui.dp(16), ui.dp(14))
            addView(ui.titleBlock(ui.t("איך זה עובד", "How it works"),
                ui.t("כשמקלידים את הקיצור, הטקסט המלא מופיע בשורת ההצעות ולוחצים עליו. אפשר גם להתחיל להקליד את הטקסט עצמו: למשל 05 יציג את כל המספרים השמורים שמתחילים ב-05. לאותו קיצור אפשר לשמור כמה טקסטים, וכולם יוצעו לבחירה.",
                    "When you type the shortcut, the full text shows up in the suggestion bar, tap it to insert. You can also start typing the text itself: 05 will show every saved number starting with 05. A shortcut can have several texts, and they are all offered to pick from."),
                maxSubLines = 6))
        })

        if (entries.isEmpty()) {
            ui.emptyState(col, R.drawable.ic_edit, ui.t("עדיין אין קיצורים", "No shortcuts yet"),
                ui.t("למשל \"טל\" ← מספר הטלפון שלך, או \"כת\" ← הכתובת שלך.", "For example \"ph\" → your phone number, or \"addr\" → your address."))
        } else {
            ui.section(col, ui.t("${entries.size} קיצורים", "${entries.size} shortcuts"))
            val card = ui.card(col)
            // ממוינים לפי הקיצור, כך שכמה טקסטים לאותו קיצור מופיעים יחד
            for (entry in entries.sortedBy { it.key.lowercase() }) {
                val key = entry.key
                val value = entry.value
                ui.add(card, LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(ui.dp(16), ui.dp(12), ui.dp(12), ui.dp(12))
                    background = ui.ripple()
                    isClickable = true
                    setOnClickListener { edit(entry) }
                    // הקיצור בתוך "גלולה" צבעונית
                    addView(TextView(this@ShortcutsActivity).apply {
                        text = key
                        textSize = 14f
                        setTypeface(typeface, Typeface.BOLD)
                        setTextColor(ui.accent)
                        gravity = Gravity.CENTER
                        background = ui.rounded(ui.tint(ui.accent, 0x22), 10)
                        setPadding(ui.dp(10), ui.dp(6), ui.dp(10), ui.dp(6))
                        minWidth = ui.dp(48)
                    }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = ui.dp(12) })
                    addView(TextView(this@ShortcutsActivity).apply {
                        text = value
                        textSize = 15f
                        setTextColor(ui.textMain)
                        maxLines = 2
                        ellipsize = android.text.TextUtils.TruncateAt.END
                        textDirection = android.view.View.TEXT_DIRECTION_FIRST_STRONG
                    }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                    addView(android.widget.ImageView(this@ShortcutsActivity).apply {
                        setImageResource(R.drawable.ic_edit)
                        setColorFilter(ui.textSub, android.graphics.PorterDuff.Mode.SRC_IN)
                    })
                })
            }
        }
        ui.fab(page) { edit(null) }
    }

    private fun edit(existing: Shortcuts.Entry?) {
        ui.formSheet(
            if (existing == null) ui.t("קיצור חדש", "New shortcut") else ui.t("עריכת קיצור", "Edit shortcut"),
            listOf(
                UiKit.FieldSpec(ui.t("קיצור", "Shortcut"), ui.t("מילה אחת, למשל: טל", "One word, e.g. ph"), existing?.key ?: ""),
                UiKit.FieldSpec(ui.t("טקסט מלא", "Full text"), ui.t("למשל: 0523675306", "e.g. 0523675306"), existing?.value ?: "", multiline = true)
            ),
            secure = true,   // שהמקלדת לא תחליף קיצורים בתוך השדות האלה
            onDelete = existing?.let { { entries.remove(it); Shortcuts.saveEntries(this, entries); render() } }
        ) { values ->
            val k = values[0].trim().lowercase()
            val v = values[1]
            if (k.isEmpty() || v.isEmpty() || k.contains(' ')) return@formSheet false
            if (existing == null) {
                // אותו קיצור יכול לקבל כמה טקסטים; רק כפילות מדויקת לא נשמרת
                if (entries.none { it.key == k && it.value == v }) entries += Shortcuts.Entry(k, v)
            } else {
                existing.key = k
                existing.value = v
            }
            Shortcuts.saveEntries(this, entries)
            render()
            true
        }
    }
}
