package com.mykeyboard.app

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * היסטוריית הלוח, שמורה בזיכרון הפרטי של האפליקציה בטלפון.
 * פריט הוא טקסט או תמונה (לתמונה נשמרת הכתובת שלה).
 * פריטים רגילים נמחקים אחרי זמן שנקבע בהגדרות; פריטים נעוצים נשמרים עד שמוחקים אותם.
 */
class ClipStore(context: Context) {

    class Item(val text: String, var time: Long, var pinned: Boolean, val image: Boolean)

    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("clipboard", Context.MODE_PRIVATE)
    private val items = mutableListOf<Item>()
    private val dismissed = LinkedHashSet<String>()   // צילומי מסך שהמשתמש מחק מהלוח, כדי שלא יחזרו
    private val ownPrefix = "content://${app.packageName}.fileprovider/clips/"
    private val maxUnpinned = 24
    private val maxPinned = 50
    var expiryMs: Long = 60 * 60 * 1000L

    init {
        try {
            val arr = JSONArray(prefs.getString("items", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                items += Item(o.getString("t"), o.getLong("time"), o.optBoolean("pin", false), o.optBoolean("img", false))
            }
            val d = JSONArray(prefs.getString("dismissed", "[]"))
            for (i in 0 until d.length()) dismissed += d.getString(i)
        } catch (_: Exception) {
        }
    }

    /** הפריטים לתצוגה: נעוצים קודם, ואז החדשים ביותר */
    fun list(): List<Item> {
        prune()
        return items.sortedWith(compareByDescending<Item> { it.pinned }.thenByDescending { it.time })
    }

    fun add(text: String) {
        val existing = items.firstOrNull { !it.image && it.text == text }
        if (existing != null) existing.time = System.currentTimeMillis()
        else items += Item(text, System.currentTimeMillis(), false, false)
        prune()
        save()
    }

    /** מוסיף תמונה (אם היא לא כבר בלוח ולא נמחקה בעבר). מחזיר true אם נוספה */
    fun addImage(uri: String, time: Long): Boolean {
        if (uri in dismissed || items.any { it.image && it.text == uri }) return false
        if (System.currentTimeMillis() - time > expiryMs) return false
        items += Item(uri, time, false, true)
        prune()
        save()
        return true
    }

    fun togglePin(item: Item) {
        item.pinned = !item.pinned
        item.time = System.currentTimeMillis()
        prune()
        save()
    }

    fun remove(item: Item) {
        items.remove(item)
        dropImage(item, dismiss = true)
        save()
    }

    /** הסרה שקטה, למשל כשתמונה נמחקה מהגלריה */
    fun forget(uri: String) {
        val it = items.firstOrNull { x -> x.image && x.text == uri } ?: return
        items.remove(it)
        dropImage(it, dismiss = false)
        save()
    }

    /** מוחק את כל הפריטים שאינם נעוצים */
    fun clearUnpinned() {
        val gone = items.filter { !it.pinned }
        items.removeAll(gone.toSet())
        gone.forEach { dropImage(it, dismiss = true) }
        save()
    }

    private fun dropImage(item: Item, dismiss: Boolean) {
        if (!item.image) return
        if (dismiss) {
            dismissed += item.text
            while (dismissed.size > 200) dismissed.remove(dismissed.first())
        }
        // תמונה שהעתקנו לתיקייה של האפליקציה נמחקת מהטלפון כדי לא לתפוס מקום
        if (item.text.startsWith(ownPrefix)) {
            Uri.parse(item.text).lastPathSegment?.let { File(File(app.filesDir, "clip_images"), it).delete() }
        }
    }

    private fun prune() {
        val now = System.currentTimeMillis()
        val gone = mutableSetOf<Item>()
        gone += items.filter { !it.pinned && now - it.time > expiryMs }
        val unpinned = items.filter { !it.pinned && it !in gone }.sortedByDescending { it.time }
        if (unpinned.size > maxUnpinned) gone += unpinned.drop(maxUnpinned)
        val pinned = items.filter { it.pinned }.sortedByDescending { it.time }
        if (pinned.size > maxPinned) gone += pinned.drop(maxPinned)
        if (gone.isEmpty()) return
        items.removeAll(gone)
        gone.forEach { dropImage(it, dismiss = false) }
        save()
    }

    private fun save() {
        val arr = JSONArray()
        for (x in items) arr.put(JSONObject().put("t", x.text).put("time", x.time).put("pin", x.pinned).put("img", x.image))
        val d = JSONArray()
        dismissed.forEach { d.put(it) }
        prefs.edit().putString("items", arr.toString()).putString("dismissed", d.toString()).apply()
    }
}
