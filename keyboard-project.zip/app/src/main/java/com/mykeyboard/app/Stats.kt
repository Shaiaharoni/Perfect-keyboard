package com.mykeyboard.app

import android.content.Context
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * סטטיסטיקת הקלדה, נשמרת רק בטלפון.
 * לא נאספת בשדות פרטיים (סיסמאות, הכספת וכו').
 */
class Stats private constructor(context: Context) {

    companion object {
        @Volatile private var inst: Stats? = null
        fun get(context: Context): Stats = inst ?: synchronized(this) {
            inst ?: Stats(context.applicationContext).also { inst = it }
        }
        private val dayFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        fun dayKey(daysAgo: Int = 0): String {
            val c = Calendar.getInstance()
            c.add(Calendar.DAY_OF_YEAR, -daysAgo)
            return dayFmt.format(c.time)
        }
    }

    private val prefs = context.getSharedPreferences("stats", Context.MODE_PRIVATE)
    var totalWords = 0L; private set
    var corrections = 0L; private set
    var correctionsUndone = 0L; private set
    var suggestionsUsed = 0L; private set
    var shortcutsUsed = 0L; private set
    var charsSaved = 0L; private set
    private var typedChars = 0L
    private var activeMs = 0L
    private val days = HashMap<String, Int>()
    private val emoji = HashMap<String, Int>()
    private var lastKey = 0L
    private var dirty = 0

    init {
        totalWords = prefs.getLong("totalWords", 0)
        corrections = prefs.getLong("corrections", 0)
        correctionsUndone = prefs.getLong("undone", 0)
        suggestionsUsed = prefs.getLong("suggestions", 0)
        shortcutsUsed = prefs.getLong("shortcuts", 0)
        charsSaved = prefs.getLong("charsSaved", 0)
        typedChars = prefs.getLong("typedChars", 0)
        activeMs = prefs.getLong("activeMs", 0)
        readMap("days", days)
        readMap("emoji", emoji)
    }

    private fun readMap(key: String, into: HashMap<String, Int>) {
        try {
            val o = JSONObject(prefs.getString(key, "{}") ?: "{}")
            o.keys().forEach { into[it] = o.getInt(it) }
        } catch (_: Exception) {
        }
    }

    // ---------- אירועים ----------

    /** כל לחיצה על מקש: משמש לחישוב מהירות ההקלדה (רק רצפים, בלי הפסקות של יותר מ-2 שניות) */
    fun keyPressed(now: Long) {
        val gap = now - lastKey
        if (gap in 1..1999) {
            activeMs += gap
            typedChars++
        }
        lastKey = now
    }

    fun wordTyped() {
        totalWords++
        val k = dayKey()
        days[k] = (days[k] ?: 0) + 1
        bump()
    }

    fun correctionApplied() { corrections++; bump() }
    fun correctionUndone() { correctionsUndone++; bump() }
    fun suggestionUsed(saved: Int) { suggestionsUsed++; charsSaved += saved.coerceAtLeast(0); bump() }
    fun shortcutUsed(saved: Int) { shortcutsUsed++; charsSaved += saved.coerceAtLeast(0); bump() }
    fun emojiUsed(e: String) { emoji[e] = (emoji[e] ?: 0) + 1; bump() }

    // ---------- נתונים לתצוגה ----------

    fun wordsOn(daysAgo: Int) = days[dayKey(daysAgo)] ?: 0

    /** מילים לדקה (מילה = 5 תווים, כמקובל) */
    fun wpm(): Int = if (activeMs < 30_000) 0 else ((typedChars / 5.0) / (activeMs / 60_000.0)).toInt()

    fun topEmoji(n: Int) = emoji.entries.sortedByDescending { it.value }.take(n).map { it.key to it.value }

    fun correctionAccuracy(): Int? =
        if (corrections < 5) null else (100 * (corrections - correctionsUndone) / corrections).toInt()

    // ---------- שמירה ----------

    private fun bump() {
        if (++dirty >= 15) save()
    }

    fun save() {
        if (dirty == 0) return
        // שומרים רק 60 ימים אחרונים
        val keep = (0 until 60).map { dayKey(it) }.toSet()
        days.keys.retainAll(keep)
        prefs.edit()
            .putLong("totalWords", totalWords).putLong("corrections", corrections).putLong("undone", correctionsUndone)
            .putLong("suggestions", suggestionsUsed).putLong("shortcuts", shortcutsUsed).putLong("charsSaved", charsSaved)
            .putLong("typedChars", typedChars).putLong("activeMs", activeMs)
            .putString("days", JSONObject(days as Map<*, *>).toString())
            .putString("emoji", JSONObject(emoji as Map<*, *>).toString())
            .apply()
        dirty = 0
    }

    fun reset() {
        totalWords = 0; corrections = 0; correctionsUndone = 0; suggestionsUsed = 0
        shortcutsUsed = 0; charsSaved = 0; typedChars = 0; activeMs = 0
        days.clear(); emoji.clear()
        dirty = 0
        prefs.edit().clear().apply()
    }
}
