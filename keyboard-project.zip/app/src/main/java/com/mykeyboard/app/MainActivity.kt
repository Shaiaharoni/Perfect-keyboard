package com.mykeyboard.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** מסך ההגדרות של המקלדת (נפתח מהאפליקציה או מגלגל השיניים בסרגל הכלים) */
class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var root: LinearLayout
    private var setupCard: LinearLayout? = null
    private var shotSwitch: Switch? = null
    private var smsSwitch: Switch? = null
    private val permRequest = 7
    private val smsRequest = 8

    // צבעים לפי מצב בהיר/כהה
    private var dark = false
    private val bg get() = if (dark) 0xFF121214.toInt() else 0xFFF2F3F6.toInt()
    private val surface get() = if (dark) 0xFF1E1F23.toInt() else 0xFFFFFFFF.toInt()
    private val textMain get() = if (dark) 0xFFF2F2F2.toInt() else 0xFF1A1A1A.toInt()
    private val textSub get() = if (dark) 0xFF9A9CA3.toInt() else 0xFF6B6E76.toInt()
    private val divider get() = if (dark) 0x22FFFFFF else 0x14000000
    private val accent = 0xFF3D7BFD.toInt()
    private val green = 0xFF2F9E6E.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        setTheme(if (dark) android.R.style.Theme_Material_NoActionBar else android.R.style.Theme_Material_Light_NoActionBar)
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("settings", MODE_PRIVATE)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        @Suppress("DEPRECATION")
        if (!dark) window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or (if (Build.VERSION.SDK_INT >= 26) View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR else 0)

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(28), dp(16), dp(40))
        }
        header()

        setupCard = card()
        refreshSetup()

        section("מראה")
        card().apply {
            add(segmented("גובה המקשים", "keyHeight", listOf("נמוך" to 46, "בינוני" to 54, "גבוה" to 62), 54))
            add(switchRow("שורת מספרים קבועה", "בלעדיה המספרים במסך הסימנים", "numberRow", true))
        }

        section("הקלדה")
        card().apply {
            add(switchRow("רטט בלחיצה", null, "vibrate", true))
            add(switchRow("הצעות מילים", null, "suggestions", true))
            add(switchRow("תיקון אוטומטי", "מחיקה אחת מיד אחרי מבטלת את התיקון", "autocorrect", true))
            add(switchRow("הצעות אמוג'י", "למשל ❤️ אחרי \"אוהב\"", "emojiSuggest", true))
            add(switchRow("רווח כפול מוסיף נקודה", null, "doubleSpace", true))
            add(switchRow("אות גדולה אוטומטית באנגלית", null, "autoCaps", true))
            add(segmented("הגדלה סמויה של האות הצפויה", "smartLevel",
                listOf("כבוי" to 0, "עדין" to 1, "רגיל" to 2, "חזק" to 3), 2))
            add(segmented("לחיצה ארוכה להזזת הסמן", "longPress",
                listOf("קצרה" to 300, "בינונית" to 500, "ארוכה" to 800), 500))
        }

        section("לוח העתקות")
        card().apply {
            add(segmented("זמן שמירה (נעוצים נשמרים תמיד)", "clipExpiryMin",
                listOf("שעה" to 60, "יום" to 1440, "שבוע" to 10080), 60))
            val shots = switchRow("צילומי מסך אחרונים בלוח", "התמונות לא יוצאות מהטלפון", "screenshots", true,
                isOn = { prefs.getBoolean("screenshots", true) && hasImagePermission() }) { on ->
                if (on && !hasImagePermission()) requestPermissions(arrayOf(imagePermission()), permRequest)
            }
            shotSwitch = shots.findViewWithTag("switch")
            add(shots)
        }

        section("למידה")
        card().apply {
            add(navRow(R.drawable.ic_chart, "הסטטיסטיקה שלי", "המילים שלך, מהירות הקלדה ודיוק התיקון") {
                startActivity(Intent(this@MainActivity, StatsActivity::class.java))
            })
        }

        section("פרטיות ומילוי")
        card().apply {
            add(navRow(R.drawable.ic_lock, "הכספת", "פרטים אישיים, נפתחים בטביעת אצבע") {
                startActivity(Intent(this@MainActivity, VaultActivity::class.java))
            })
            add(navRow(R.drawable.ic_edit, "קיצורי טקסט", "למשל \"כת\" ← הכתובת המלאה") {
                startActivity(Intent(this@MainActivity, ShortcutsActivity::class.java))
            })
            add(switchRow("סיסמאות וכרטיסים שמורים", "מגוגל, בשורת ההצעות", "inlineAutofill", true))
            val sms = switchRow("קודי אימות מ-SMS", "בשיאומי ייתכן שצריך לאשר גם \"הרשאות נוספות\"", "smsCodes", true,
                isOn = { prefs.getBoolean("smsCodes", true) && hasSmsPermission() }) { on ->
                if (on && !hasSmsPermission()) requestPermissions(arrayOf(Manifest.permission.RECEIVE_SMS), smsRequest)
            }
            smsSwitch = sms.findViewWithTag("switch")
            add(sms)
        }

        section("מילון")
        card().apply {
            add(navRow(R.drawable.ic_trash, "מחיקת המילים שהמקלדת למדה", "המילון הבסיסי יישאר", danger = true) {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage("למחוק את כל המילים והצירופים שהמקלדת למדה ממך?")
                    .setPositiveButton("מחק") { _, _ ->
                        WordPredictor.instance?.clearLearned() ?: WordPredictor.clearSaved(this@MainActivity)
                        Toast.makeText(this@MainActivity, "נמחק", Toast.LENGTH_SHORT).show()
                    }
                    .setNegativeButton("ביטול", null)
                    .show()
            })
        }

        section("ניסיון")
        card().apply {
            add(EditText(this@MainActivity).apply {
                hint = "נסה להקליד כאן…"
                minLines = 3
                gravity = Gravity.TOP or Gravity.START
                setTextColor(textMain)
                setHintTextColor(textSub)
                background = null
                setPadding(dp(16), dp(14), dp(16), dp(14))
            })
        }

        setContentView(ScrollView(this).apply {
            setBackgroundColor(bg)
            addView(root)
        })

        // הגענו מהבאנר בלוח: מבקשים את ההרשאה מיד
        if (intent.getBooleanExtra("askScreenshots", false) && !hasImagePermission()) {
            requestPermissions(arrayOf(imagePermission()), permRequest)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshSetup()
    }

    // ---------- כותרת ומצב התקנה ----------

    private fun header() {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, dp(4), dp(18))
        }
        row.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_launcher)
            background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(accent) }
            clipToOutline = true
        }, LinearLayout.LayoutParams(dp(52), dp(52)))
        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), 0, dp(14), 0)
        }
        texts.addView(TextView(this).apply {
            text = "המקלדת שלי"
            textSize = 26f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(textMain)
        })
        texts.addView(TextView(this).apply {
            text = "הגדרות"
            textSize = 15f
            setTextColor(textSub)
        })
        row.addView(texts)
        root.addView(row)
    }

    private fun isEnabled(): Boolean =
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).enabledInputMethodList.any { it.packageName == packageName }

    private fun isDefault(): Boolean =
        Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)?.startsWith(packageName) == true

    /** כרטיס עליון: אם המקלדת פעילה מציג וי ירוק, אחרת את שני שלבי ההתקנה */
    private fun refreshSetup() {
        val c = setupCard ?: return
        c.removeAllViews()
        if (isEnabled() && isDefault()) {
            c.addView(LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(16), dp(14), dp(16), dp(14))
                addView(TextView(this@MainActivity).apply {
                    text = "✓"
                    gravity = Gravity.CENTER
                    setTextColor(Color.WHITE)
                    textSize = 16f
                    setTypeface(typeface, Typeface.BOLD)
                    background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(green) }
                }, LinearLayout.LayoutParams(dp(30), dp(30)))
                addView(TextView(this@MainActivity).apply {
                    text = "המקלדת פעילה ומוגדרת כברירת מחדל"
                    textSize = 15f
                    setTextColor(textMain)
                    setPadding(dp(12), 0, dp(12), 0)
                })
            })
            return
        }
        c.addView(navRow(null, "1. הפעלת המקלדת", if (isEnabled()) "✓ הופעלה" else "בהגדרות המערכת") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }, rowLp())
        c.addView(dividerView())
        c.addView(navRow(null, "2. בחירה כברירת מחדל", "בחירה ברשימת המקלדות") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }, rowLp())
    }

    // ---------- רכיבי עיצוב ----------

    private fun section(title: String) {
        root.addView(TextView(this).apply {
            text = title
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(accent)
            setPadding(dp(8), dp(22), dp(8), dp(8))
        })
    }

    /** כרטיס מעוגל שמכיל שורות */
    private fun card(): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { cornerRadius = dp(18).toFloat(); setColor(surface) }
            clipToOutline = true
        }
        root.addView(c, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        return c
    }

    /** מוסיף שורה לכרטיס, עם קו מפריד בין שורות */
    private fun LinearLayout.add(v: View) {
        if (childCount > 0) addView(dividerView())
        addView(v, rowLp())
    }

    private fun rowLp() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

    private fun dividerView() = View(this).apply { setBackgroundColor(divider) }.also {
        it.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1).apply { setMargins(dp(16), 0, dp(16), 0) }
    }

    private fun ripple(): RippleDrawable =
        RippleDrawable(ColorStateList.valueOf(if (dark) 0x22FFFFFF else 0x14000000), null, GradientDrawable().apply { setColor(Color.WHITE) })

    private fun titleBlock(title: String, subtitle: String?, color: Int = textMain) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(TextView(this@MainActivity).apply {
            text = title
            textSize = 16f
            setTextColor(color)
        })
        if (subtitle != null) addView(TextView(this@MainActivity).apply {
            text = subtitle
            textSize = 13f
            setTextColor(textSub)
            setPadding(0, dp(2), 0, 0)
        })
    }

    private fun switchRow(
        title: String, subtitle: String?, key: String, default: Boolean,
        isOn: () -> Boolean = { prefs.getBoolean(key, default) },
        onChange: ((Boolean) -> Unit)? = null
    ): LinearLayout {
        val sw = Switch(this).apply {
            tag = "switch"
            isChecked = isOn()
            thumbTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(Color.WHITE, if (dark) 0xFFB0B2B8.toInt() else Color.WHITE)
            )
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(accent, if (dark) 0xFF4A4B52.toInt() else 0xFFC9CCD3.toInt())
            )
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(key, checked).apply()
                onChange?.invoke(checked)
            }
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(13), dp(12), dp(13))
            background = ripple()
            isClickable = true
            setOnClickListener { sw.toggle() }
            addView(titleBlock(title, subtitle), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(sw)
        }
    }

    /** בחירה בין כמה אפשרויות, כמו כפתורים מחוברים */
    private fun segmented(title: String, key: String, options: List<Pair<String, Int>>, default: Int): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(13), dp(16), dp(14))
            addView(titleBlock(title, null))
        }
        val group = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(3), dp(3), dp(3), dp(3))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(if (dark) 0xFF2A2B30.toInt() else 0xFFEDEEF2.toInt())
            }
        }
        val views = mutableListOf<TextView>()
        fun paint(selected: Int) {
            views.forEachIndexed { i, tv ->
                val on = options[i].second == selected
                tv.setTextColor(if (on) Color.WHITE else textMain)
                tv.background = if (on) GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(accent) } else null
            }
        }
        options.forEach { (label, value) ->
            val tv = TextView(this).apply {
                text = label
                gravity = Gravity.CENTER
                textSize = 14f
                setPadding(0, dp(8), 0, dp(8))
                isClickable = true
                setOnClickListener {
                    prefs.edit().putInt(key, value).apply()
                    paint(value)
                }
            }
            views += tv
            group.addView(tv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        paint(prefs.getInt(key, default))
        box.addView(group, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(10) })
        return box
    }

    /** שורה שפותחת מסך אחר */
    private fun navRow(icon: Int?, title: String, subtitle: String?, danger: Boolean = false, onTap: () -> Unit) =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(13), dp(12), dp(13))
            background = ripple()
            isClickable = true
            setOnClickListener { onTap() }
            if (icon != null) {
                val c = if (danger) 0xFFE5484D.toInt() else accent
                addView(ImageView(this@MainActivity).apply {
                    setImageResource(icon)
                    setColorFilter(c, PorterDuff.Mode.SRC_IN)
                    scaleType = ImageView.ScaleType.CENTER
                    background = GradientDrawable().apply {
                        cornerRadius = dp(10).toFloat()
                        setColor((c and 0x00FFFFFF) or (0x22 shl 24))
                    }
                }, LinearLayout.LayoutParams(dp(38), dp(38)).apply { marginEnd = dp(12) })
            }
            addView(titleBlock(title, subtitle, if (danger) 0xFFE5484D.toInt() else textMain),
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ic_chevron_left)   // במסך מימין לשמאל החץ מצביע שמאלה
                setColorFilter(textSub, PorterDuff.Mode.SRC_IN)
            })
        }

    // ---------- הרשאות ----------

    private fun imagePermission() =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasImagePermission() =
        checkSelfPermission(imagePermission()) == PackageManager.PERMISSION_GRANTED

    private fun hasSmsPermission() =
        checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        val (sw, key, perm, msg) = when (requestCode) {
            smsRequest -> listOf(smsSwitch, "smsCodes", Manifest.permission.RECEIVE_SMS, "צריך לאשר הודעות SMS בהגדרות האפליקציה")
            permRequest -> listOf(shotSwitch, "screenshots", imagePermission(), "צריך לאשר גישה לתמונות בהגדרות האפליקציה")
            else -> return
        }
        (sw as? Switch)?.isChecked = granted
        prefs.edit().putBoolean(key as String, granted).apply()
        if (!granted && !shouldShowRequestPermissionRationale(perm as String)) {
            // ההרשאה נחסמה לצמיתות: שולחים להגדרות האפליקציה
            Toast.makeText(this, msg as String, Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
