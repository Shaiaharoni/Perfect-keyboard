package com.mykeyboard.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** מסך ההגדרות של המקלדת (נפתח מהאפליקציה או מגלגל השיניים בסרגל הכלים) */
class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var layout: LinearLayout
    private var shotSwitch: Switch? = null
    private val permRequest = 7
    private val smsRequest = 8
    private var smsSwitch: Switch? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "הגדרות המקלדת"
        prefs = getSharedPreferences("settings", MODE_PRIVATE)

        layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(20), dp(8), dp(20), dp(40))
        }

        section("התקנה")
        button("הפעלת המקלדת בהגדרות המערכת") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }
        button("בחירה כמקלדת ברירת מחדל") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }

        section("מראה")
        choice("גובה המקשים", "keyHeight", listOf("נמוך" to 46, "בינוני" to 54, "גבוה" to 62), 54)
        toggle("שורת מספרים קבועה", "numberRow", true)

        section("הקלדה")
        toggle("רטט בלחיצה", "vibrate", true)
        toggle("הצעות מילים", "suggestions", true)
        toggle("תיקון אוטומטי (מחיקה מיד אחרי מבטלת)", "autocorrect", true)
        toggle("הצעות אמוג'י לפי מילים", "emojiSuggest", true)
        choice("הגדלה סמויה של האות הצפויה", "smartLevel",
            listOf("כבוי" to 0, "עדין" to 1, "רגיל" to 2, "חזק" to 3), 2)
        toggle("רווח כפול מוסיף נקודה", "doubleSpace", true)
        toggle("אות גדולה אוטומטית באנגלית", "autoCaps", true)
        choice("לחיצה ארוכה להזזת הסמן", "longPress",
            listOf("קצרה" to 300, "בינונית" to 500, "ארוכה" to 800), 500)

        section("לוח העתקות")
        choice("כמה זמן לשמור פריטים (נעוצים נשמרים תמיד)", "clipExpiryMin",
            listOf("שעה" to 60, "יום" to 1440, "שבוע" to 10080), 60)
        screenshotToggle()

        section("קיצורי טקסט")
        layout.addView(TextView(this).apply {
            text = "מילה קצרה שהופכת לטקסט מלא כשלוחצים רווח, למשל \"כת\" לכתובת שלך."
            textSize = 13f
        })
        button("עריכת קיצורים") { startActivity(Intent(this, ShortcutsActivity::class.java)) }

        section("קודי אימות")
        smsToggle()

        section("כספת")
        layout.addView(TextView(this).apply {
            text = "מקום לדברים פרטיים (תעודת זהות, חשבון בנק וכו׳), מוצפן ונפתח בטביעת אצבע."
            textSize = 13f
        })
        button("פתיחת הכספת") { startActivity(Intent(this, VaultActivity::class.java)) }

        section("מילון")
        button("מחיקת המילים שהמקלדת למדה") {
            AlertDialog.Builder(this)
                .setMessage("למחוק את כל המילים והצירופים שהמקלדת למדה ממך? המילון הבסיסי יישאר.")
                .setPositiveButton("מחק") { _, _ ->
                    WordPredictor.instance?.clearLearned() ?: WordPredictor.clearSaved(this)
                    Toast.makeText(this, "נמחק", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("ביטול", null)
                .show()
        }

        section("ניסיון")
        layout.addView(EditText(this).apply {
            hint = "נסה להקליד כאן"
            minLines = 3
        })

        setContentView(ScrollView(this).apply { addView(layout) })

        // הגענו מהבאנר בלוח: מבקשים את ההרשאה מיד
        if (intent.getBooleanExtra("askScreenshots", false) && !hasImagePermission()) {
            requestPermissions(arrayOf(imagePermission()), permRequest)
        }
    }

    // ---------- צילומי מסך ----------

    private fun imagePermission() =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasImagePermission() =
        checkSelfPermission(imagePermission()) == PackageManager.PERMISSION_GRANTED

    private fun screenshotToggle() {
        val sw = Switch(this).apply {
            text = "צילומי מסך אחרונים בלוח"
            textSize = 16f
            setPadding(0, dp(10), 0, dp(10))
            isChecked = prefs.getBoolean("screenshots", true) && hasImagePermission()
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("screenshots", checked).apply()
                if (checked && !hasImagePermission()) requestPermissions(arrayOf(imagePermission()), permRequest)
            }
        }
        shotSwitch = sw
        layout.addView(sw)
        layout.addView(TextView(this).apply {
            text = "המקלדת קוראת רק צילומי מסך מהזמן האחרון, והתמונות לא יוצאות מהטלפון."
            textSize = 13f
            setPadding(0, 0, 0, dp(6))
        })
    }

    private fun hasSmsPermission() =
        checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED

    private fun smsToggle() {
        val sw = Switch(this).apply {
            text = "הצגת קוד אימות מ-SMS בשורת ההצעות"
            textSize = 16f
            setPadding(0, dp(10), 0, dp(10))
            isChecked = prefs.getBoolean("smsCodes", true) && hasSmsPermission()
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("smsCodes", checked).apply()
                if (checked && !hasSmsPermission()) requestPermissions(arrayOf(Manifest.permission.RECEIVE_SMS), smsRequest)
            }
        }
        smsSwitch = sw
        layout.addView(sw)
        layout.addView(TextView(this).apply {
            text = "המקלדת קוראת רק הודעות חדשות שמגיעות, מחפשת בהן קוד, ולא שומרת את ההודעה עצמה. בשיאומי ייתכן שצריך לאשר גם \"קריאת הודעות התראה\" בהרשאות הנוספות של האפליקציה."
            textSize = 13f
            setPadding(0, 0, 0, dp(6))
        })
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == smsRequest) {
            val ok = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            smsSwitch?.isChecked = ok
            prefs.edit().putBoolean("smsCodes", ok).apply()
            if (!ok && !shouldShowRequestPermissionRationale(Manifest.permission.RECEIVE_SMS)) {
                Toast.makeText(this, "צריך לאשר הודעות SMS בהגדרות האפליקציה", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }
            return
        }
        if (requestCode != permRequest) return
        val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        if (granted) {
            prefs.edit().putBoolean("screenshots", true).apply()
            shotSwitch?.isChecked = true
            Toast.makeText(this, "מעולה, צילומי מסך יופיעו בלוח", Toast.LENGTH_SHORT).show()
        } else {
            shotSwitch?.isChecked = false
            prefs.edit().putBoolean("screenshots", false).apply()
            if (!shouldShowRequestPermissionRationale(imagePermission())) {
                // ההרשאה נחסמה לצמיתות: שולחים להגדרות האפליקציה
                Toast.makeText(this, "צריך לאשר גישה לתמונות בהגדרות האפליקציה", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }
        }
    }

    // ---------- רכיבים ----------

    private fun section(title: String) {
        layout.addView(TextView(this).apply {
            text = title
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF3D7BFD.toInt())
            setPadding(0, dp(24), 0, dp(8))
        })
    }

    private fun button(label: String, onTap: () -> Unit) {
        layout.addView(Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { onTap() }
        })
    }

    private fun toggle(label: String, key: String, default: Boolean) {
        layout.addView(Switch(this).apply {
            text = label
            textSize = 16f
            isChecked = prefs.getBoolean(key, default)
            setPadding(0, dp(10), 0, dp(10))
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply() }
        })
    }

    private fun choice(label: String, key: String, options: List<Pair<String, Int>>, default: Int) {
        layout.addView(TextView(this).apply {
            text = label
            textSize = 16f
            setPadding(0, dp(10), 0, dp(4))
        })
        val current = prefs.getInt(key, default)
        val group = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        options.forEachIndexed { i, (name, value) ->
            val rb = RadioButton(this).apply {
                id = View.generateViewId()
                text = name
                setPadding(0, 0, dp(12), 0)
            }
            group.addView(rb)
            if (value == current) group.check(rb.id)
            rb.setOnCheckedChangeListener { _, checked ->
                if (checked) prefs.edit().putInt(key, options[i].second).apply()
            }
        }
        layout.addView(group)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
