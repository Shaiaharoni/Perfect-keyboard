package com.mykeyboard.app

import android.content.Context
import org.json.JSONObject

/** קיצורי טקסט: מילה קצרה שהופכת לטקסט מלא (למשל "כת" ← הכתובת המלאה) */
object Shortcuts {
    fun load(context: Context): MutableMap<String, String> {
        val raw = context.getSharedPreferences("shortcuts", Context.MODE_PRIVATE).getString("map", "{}")
        val map = linkedMapOf<String, String>()
        try {
            val o = JSONObject(raw ?: "{}")
            o.keys().forEach { k -> map[k] = o.getString(k) }
        } catch (_: Exception) {
        }
        return map
    }

    fun save(context: Context, map: Map<String, String>) {
        val o = JSONObject()
        map.forEach { (k, v) -> o.put(k, v) }
        context.getSharedPreferences("shortcuts", Context.MODE_PRIVATE).edit().putString("map", o.toString()).apply()
    }
}
