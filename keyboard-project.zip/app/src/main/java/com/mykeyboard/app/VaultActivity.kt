package com.mykeyboard.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** ניהול הכספת: הוספה, עריכה ומחיקה של פריטים פרטיים */
class VaultActivity : Activity() {

    private val authRequest = 21
    private lateinit var list: LinearLayout
    private var items = mutableListOf<Vault.Item>()
    private var waitingForAuth = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // מונע צילומי מסך והצגה ברשימת האפליקציות האחרונות
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        title = "הכספת"

        val pad = dp(20)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(pad, dp(12), pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "הפריטים כאן מוצפנים ונפתחים רק בטביעת אצבע. במקלדת, לחיצה על פריט מקלידה אותו בלי להעתיק ללוח."
            textSize = 14f
            setPadding(0, 0, 0, dp(12))
        })
        root.addView(Button(this).apply {
            text = "+ הוספת פריט"
            isAllCaps = false
            setOnClickListener { editDialog(null) }
        })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        if (Vault.isUnlocked()) {
            Vault.unlock()   // מאריך את הזמן כל עוד המסך פתוח
            items = Vault.load(this)
            render()
        } else if (!waitingForAuth) {
            list.removeAllViews()
            waitingForAuth = true
            startActivityForResult(Intent(this, VaultAuthActivity::class.java), authRequest)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == authRequest) {
            waitingForAuth = false
            if (resultCode != RESULT_OK) finish()
        }
    }

    override fun onStop() {
        super.onStop()
        if (!waitingForAuth && !isChangingConfigurations) Vault.lock()
    }

    private fun render() {
        list.removeAllViews()
        if (items.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "הכספת ריקה. אפשר לשמור כאן למשל מספר תעודת זהות, פרטי חשבון בנק או כתובת."
                textSize = 15f
                setPadding(0, dp(24), 0, 0)
            })
        }
        for (item in items) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(14), 0, dp(14))
                isClickable = true
                setOnClickListener { editDialog(item) }
            }
            row.addView(TextView(this).apply {
                text = item.label
                textSize = 16f
                setTypeface(typeface, Typeface.BOLD)
            })
            row.addView(TextView(this).apply {
                text = "•".repeat(item.value.length.coerceIn(4, 12))
                textSize = 15f
            })
            list.addView(row)
            list.addView(View(this).apply { setBackgroundColor(0x22000000) },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1))
        }
    }

    private fun editDialog(item: Vault.Item?) {
        // שדות פרטיים: המקלדת לא לומדת ולא מציעה מילים מהם
        val privateFlags = InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        val label = EditText(this).apply {
            hint = "שם (למשל: תעודת זהות)"
            inputType = InputType.TYPE_CLASS_TEXT or privateFlags
            setText(item?.label ?: "")
        }
        val value = EditText(this).apply {
            hint = "התוכן"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or privateFlags
            setText(item?.value ?: "")
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(label)
            addView(value)
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle(if (item == null) "פריט חדש" else "עריכה")
            .setView(box)
            .setPositiveButton("שמור") { _, _ ->
                val l = label.text.toString().trim()
                val v = value.text.toString()
                if (l.isEmpty() || v.isEmpty()) return@setPositiveButton
                if (item == null) items += Vault.Item(System.currentTimeMillis(), l, v)
                else { item.label = l; item.value = v }
                Vault.save(this, items)
                render()
            }
            .setNegativeButton("ביטול", null)
        if (item != null) {
            dialog.setNeutralButton("מחק") { _, _ ->
                items.remove(item)
                Vault.save(this, items)
                render()
            }
        }
        dialog.show()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
