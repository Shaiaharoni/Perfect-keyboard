package com.mykeyboard.app

import android.app.Activity
import android.app.KeyguardManager
import android.content.Intent
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.widget.Toast

/**
 * מסך שקוף שמציג את בקשת טביעת האצבע של המערכת (או קוד הנעילה, אם אין טביעת אצבע).
 * בהצלחה: הכספת נפתחת לזמן קצר והמסך נסגר.
 */
class VaultAuthActivity : Activity() {

    private val credentialRequest = 11
    private var cancel: CancellationSignal? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) showBiometricPrompt() else showDeviceCredential()
    }

    @Suppress("DEPRECATION")
    private fun showBiometricPrompt() {
        val builder = BiometricPrompt.Builder(this)
            .setTitle("פתיחת הכספת")
            .setSubtitle("אמת עם טביעת אצבע")
        when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.R ->
                builder.setAllowedAuthenticators(
                    BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL
                )
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q ->
                builder.setDeviceCredentialAllowed(true)
            else ->
                builder.setNegativeButton("ביטול", mainExecutor) { _, _ -> fail() }
        }
        cancel = CancellationSignal()
        try {
            builder.build().authenticate(cancel!!, mainExecutor, object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) = succeed()
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    if (errorCode == BiometricPrompt.BIOMETRIC_ERROR_HW_NOT_PRESENT ||
                        errorCode == BiometricPrompt.BIOMETRIC_ERROR_NO_BIOMETRICS ||
                        errorCode == BiometricPrompt.BIOMETRIC_ERROR_HW_UNAVAILABLE
                    ) showDeviceCredential() else fail()
                }
            })
        } catch (_: Exception) {
            showDeviceCredential()
        }
    }

    @Suppress("DEPRECATION")
    private fun showDeviceCredential() {
        val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
        val intent = km.createConfirmDeviceCredentialIntent("פתיחת הכספת", "אמת את זהותך")
        if (intent == null) {
            Toast.makeText(this, "כדי להשתמש בכספת צריך להגדיר נעילת מסך או טביעת אצבע", Toast.LENGTH_LONG).show()
            fail()
            return
        }
        startActivityForResult(intent, credentialRequest)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == credentialRequest) {
            if (resultCode == RESULT_OK) succeed() else fail()
        }
    }

    private fun succeed() {
        Vault.unlock()
        setResult(RESULT_OK)
        finish()
        overridePendingTransition(0, 0)
    }

    private fun fail() {
        Vault.openPanelOnReturn = false
        setResult(RESULT_CANCELED)
        finish()
        overridePendingTransition(0, 0)
    }

    override fun onDestroy() {
        cancel?.cancel()
        super.onDestroy()
    }
}
