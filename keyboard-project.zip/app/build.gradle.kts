plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mykeyboard.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.mykeyboard.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    // מפתח חתימה קבוע: כל בנייה חתומה באותו מפתח, כך שאפשר להתקין גרסה חדשה מעל הישנה
    signingConfigs {
        create("fixed") {
            storeFile = file("keyboard.keystore")
            storePassword = "keyboard-pass"
            keyAlias = "keyboard"
            keyPassword = "keyboard-pass"
        }
    }

    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("fixed") }
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fixed")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    // FileProvider ושליחת תמונות לאפליקציות (commitContent)
    implementation("androidx.core:core:1.13.1")
}
