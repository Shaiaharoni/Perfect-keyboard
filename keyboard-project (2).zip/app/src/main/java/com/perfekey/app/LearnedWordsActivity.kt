package com.perfekey.app

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

/** כל המילים שהמקלדת למדה ממך: חיפוש, מיון ומחיקה */
class LearnedWordsActivity : Activity() {

    private lateinit var ui: UiKit
    private lateinit var predictor: WordPredictor
    private lateinit var list: LinearLayout
    private lateinit var countLabel: TextView
    private var all: List<Pair<String, Int>> = emptyList()
    private var query = ""
    private var sortByCount = true
    private var shown = PAGE

    companion object { const val PAGE = 200 }

    override fun onCreate(savedInstanceState: Bundle?) {
        ui = UiKit(this)
        ui.applyTheme()
        super.onCreate(savedInstanceState)
        ui.styleWindow()
        predictor = WordPredictor.instance ?: WordPredictor(this)
        all = predictor.taughtWords()

        val page = ui.page()
        val col = page.column
        ui.header(col, ui.t("מילים שלימדת אותי", "Words you taught me"),
            ui.t("מילים שלא היו במילון, ולמדתי מההקלדה שלך", "Words that weren't in the dictionary, learned from your typing"), back = true)

        // חיפוש
        col.addView(EditText(this).apply {
            hint = ui.t("חיפוש מילה…", "Search…")
            setTextColor(ui.textMain)
            setHintTextColor(ui.textSub)
            textSize = 16f
            background = ui.rounded(ui.surface, 14)
            setPadding(ui.dp(14), ui.dp(12), ui.dp(14), ui.dp(12))
            // שדה פרטי: המקלדת לא לומדת מהחיפוש עצמו
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    query = s?.toString()?.trim()?.lowercase() ?: ""
                    shown = PAGE
                    renderList()
                }
            })
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // מיון
        col.addView(ui.segmented(ui.t("מיון", "Sort"),
            listOf(ui.t("הכי נפוצות", "Most used") to true, ui.t("לפי א-ב", "A–Z") to false), true) {
            sortByCount = it
            shown = PAGE
            renderList()
        }.apply { setPadding(ui.dp(4), ui.dp(10), ui.dp(4), ui.dp(4)) })

        countLabel = TextView(this).apply {
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(ui.accent)
            setPadding(ui.dp(8), ui.dp(16), ui.dp(8), ui.dp(8))
        }
        col.addView(countLabel)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(list)
        renderList()
    }

    private fun confirmDelete(word: String) {
        ui.confirm(ui.t("למחוק את \"$word\"? המקלדת תפסיק להציע אותה ותתקן אותה כמו מילה לא מוכרת.",
            "Delete \"$word\"? The keyboard will stop suggesting it and treat it as unknown."), ui.t("מחק", "Delete")) {
            predictor.forget(word)
            all = all.filter { it.first != word }
            renderList()
        }
    }

    private fun renderList() {
        list.removeAllViews()
        val filtered = all.filter { query.isEmpty() || it.first.contains(query) }
            .let { l -> if (sortByCount) l.sortedByDescending { it.second } else l.sortedBy { it.first } }
        countLabel.text = if (query.isEmpty()) ui.t("${filtered.size} מילים", "${filtered.size} words")
        else ui.t("${filtered.size} תוצאות", "${filtered.size} results")

        if (filtered.isEmpty()) {
            list.addView(TextView(this).apply {
                text = if (all.isEmpty()) ui.t("עוד לא לימדת אותי מילים חדשות. שמות, סלנג ומילים שאין במילון יופיעו כאן כשתקליד אותם.", "You haven't taught me new words yet. Names, slang and words missing from the dictionary will show up here as you type them.")
                else ui.t("לא נמצאו מילים", "No matching words")
                textSize = 15f
                setTextColor(ui.textSub)
                gravity = Gravity.CENTER
                setPadding(ui.dp(16), ui.dp(32), ui.dp(16), ui.dp(16))
            })
            return
        }
        val card = ui.card(list)
        val max = (filtered.maxOfOrNull { it.second } ?: 1).coerceAtLeast(1)
        for ((word, count) in filtered.take(shown)) {
            ui.add(card, LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(ui.dp(16), ui.dp(11), ui.dp(16), ui.dp(11))
                background = ui.ripple()
                isClickable = true
                setOnClickListener { confirmDelete(word) }
                addView(TextView(this@LearnedWordsActivity).apply {
                    text = word
                    textSize = 16f
                    setTextColor(ui.textMain)
                    textDirection = android.view.View.TEXT_DIRECTION_FIRST_STRONG
                }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                addView(TextView(this@LearnedWordsActivity).apply {
                    text = count.toString()
                    textSize = 13f
                    setTextColor(ui.textSub)
                    gravity = Gravity.END
                }, LinearLayout.LayoutParams(ui.dp(36), ViewGroup.LayoutParams.WRAP_CONTENT))
                // מחיקה: למשל מילה שנלמדה בטעות
                addView(android.widget.ImageView(this@LearnedWordsActivity).apply {
                    setImageResource(R.drawable.ic_trash)
                    setColorFilter(ui.red, android.graphics.PorterDuff.Mode.SRC_IN)
                    scaleType = android.widget.ImageView.ScaleType.CENTER
                    background = ui.ripple()
                    isClickable = true
                    setOnClickListener { confirmDelete(word) }
                }, LinearLayout.LayoutParams(ui.dp(40), ui.dp(40)).apply { marginStart = ui.dp(6) })
            })
        }
        if (filtered.size > shown) {
            list.addView(TextView(this).apply {
                text = ui.t("הצג עוד (${filtered.size - shown})", "Show more (${filtered.size - shown})")
                textSize = 15f
                setTextColor(ui.accent)
                gravity = Gravity.CENTER
                setPadding(0, ui.dp(14), 0, ui.dp(14))
                background = ui.rounded(ui.surface, 18)
                isClickable = true
                setOnClickListener {
                    shown += PAGE
                    renderList()
                }
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = ui.dp(12) })
        }
        list.addView(TextView(this).apply {
            text = ui.t("המספר הוא כמה פעמים הקלדת את המילה. מילה שהוקלדה פעם אחת עוד לא מוצעת ולא נחשבת מוכרת לתיקון; מפעמיים היא כן.",
                "The number is how many times you typed the word. A word typed once isn't suggested or treated as known yet; from twice on, it is.")
            textSize = 13f
            setTextColor(ui.textSub)
            setPadding(ui.dp(8), ui.dp(12), ui.dp(8), 0)
        })
    }
}
