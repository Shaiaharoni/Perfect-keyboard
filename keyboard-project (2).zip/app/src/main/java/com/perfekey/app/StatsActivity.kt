package com.perfekey.app

import android.app.Activity
import android.app.AlertDialog
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Calendar

/** t("הסטטיסטיקה שלי", "My statistics"): מה המקלדת למדה עליך ואיך אתה מקליד */
class StatsActivity : Activity() {

    private lateinit var root: LinearLayout
    private var dark = false
    private val bg get() = if (dark) 0xFF121214.toInt() else 0xFFF2F3F6.toInt()
    private val surface get() = if (dark) 0xFF1E1F23.toInt() else 0xFFFFFFFF.toInt()
    private val textMain get() = if (dark) 0xFFF2F2F2.toInt() else 0xFF1A1A1A.toInt()
    private val textSub get() = if (dark) 0xFF9A9CA3.toInt() else 0xFF6B6E76.toInt()
    private val track get() = if (dark) 0xFF2A2B30.toInt() else 0xFFEDEEF2.toInt()
    private val accent = 0xFF3D7BFD.toInt()
    private fun t(he: String, en: String) = L.t(this, he, en)

    override fun onCreate(savedInstanceState: Bundle?) {
        dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        setTheme(if (dark) android.R.style.Theme_Material_NoActionBar else android.R.style.Theme_Material_Light_NoActionBar)
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        @Suppress("DEPRECATION")
        if (!dark) window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or (if (Build.VERSION.SDK_INT >= 26) View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR else 0)
        render()
    }

    override fun onRestart() {
        super.onRestart()
        render()
    }

    private fun render() {
        val stats = Stats.get(this)
        stats.save()
        // המקלדת והמסך רצים באותו תהליך: אם המקלדת פעילה, לוקחים ממנה את הנתונים העדכניים
        val predictor = WordPredictor.instance ?: WordPredictor(this)

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = if (L.isEnglish(this@StatsActivity)) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(28), dp(16), dp(40))
        }
        root.addView(TextView(this).apply {
            text = t("הסטטיסטיקה שלי", "My statistics")
            textSize = 26f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(textMain)
            setPadding(dp(4), 0, dp(4), dp(4))
        })
        root.addView(TextView(this).apply {
            text = t("נשמר רק בטלפון. לא נאסף בשדות סיסמה ובשדות פרטיים.", "Stored only on your phone. Never collected in password or private fields.")
            textSize = 13f
            setTextColor(textSub)
            setPadding(dp(4), 0, dp(4), dp(12))
        })

        // ---- מדדים ראשיים ----
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun metricRow(a: Pair<String, String>, b: Pair<String, String>) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for ((value, label) in listOf(a, b)) {
                row.addView(LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(16), dp(14), dp(16), dp(14))
                    background = rounded(surface, 18)
                    addView(TextView(this@StatsActivity).apply {
                        text = value
                        textSize = 26f
                        setTypeface(typeface, Typeface.BOLD)
                        setTextColor(accent)
                    })
                    addView(TextView(this@StatsActivity).apply {
                        text = label
                        textSize = 13f
                        setTextColor(textSub)
                    })
                }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
            }
            grid.addView(row)
        }
        metricRow(fmt(stats.wordsOn(0)) to t("מילים היום", "Words today"), fmt(stats.totalWords) to t("מילים בסך הכל", "Total words"))
        val wpm = stats.wpm()
        metricRow((if (wpm > 0) "$wpm" else "—") to t("מילים לדקה", "Words per minute"), fmt(stats.charsSaved) to t("תווים שחסכת", "Characters saved"))
        root.addView(grid)

        // ---- 7 ימים ----
        section(t("7 הימים האחרונים", "Last 7 days"))
        card().addView(weekChart(stats))

        // ---- המילים שלך ----
        section(t("המילים שלך", "Your words"))
        val words = card()
        val top = predictor.topLearned(15)
        if (top.isEmpty()) {
            words.addView(note(t("עוד לא למדתי מילים. ככל שתקליד יותר, ההצעות והתיקונים יתאימו לך יותר.", "No words learned yet. The more you type, the better suggestions and corrections fit you.")))
        } else {
            words.addView(note(t("המילים שאתה מקליד הכי הרבה, כולל מילים מהמילון. הן עולות ראשונות בהצעות ובתיקונים. לחיצה על מילה מוחקת את מה שנלמד עליה.", "The words you type most, including dictionary words. They rank first in suggestions and corrections. Tap a word to forget what was learned about it.")))
            // כפתור לרשימה המלאה
            words.addView(TextView(this).apply {
                text = t("מילים שלימדת אותי (${fmt(predictor.taughtWords().size.toLong())}) ›", "Words you taught me (${fmt(predictor.taughtWords().size.toLong())}) ›")
                textSize = 15f
                setTextColor(accent)
                setPadding(dp(16), dp(10), dp(16), dp(10))
                isClickable = true
                setOnClickListener { startActivity(android.content.Intent(this@StatsActivity, LearnedWordsActivity::class.java)) }
            })
            val max = top.first().second.coerceAtLeast(1)
            for ((w, c) in top) words.addView(barRow(w, c, max) {
                AlertDialog.Builder(this)
                    .setMessage(t("למחוק את \"$w\" מהמילים שהמקלדת למדה?", "Forget \"$w\"?"))
                    .setPositiveButton(t("מחק", "Delete")) { _, _ -> predictor.forget(w); render() }
                    .setNegativeButton(t("ביטול", "Cancel"), null)
                    .show()
            })
        }

        // ---- תיקונים וחיסכון ----
        section(t("תיקונים וקיצורים", "Corrections & shortcuts"))
        card().apply {
            val acc = stats.correctionAccuracy()
            addView(kv(t("תיקונים אוטומטיים", "Autocorrections"), fmt(stats.corrections)))
            addView(kv(t("תיקונים שביטלת", "Corrections undone"), fmt(stats.correctionsUndone)))
            addView(kv(t("דיוק התיקון", "Autocorrect accuracy"), if (acc != null) "$acc%" else t("עוד מעט נתונים", "Not enough data yet")))
            addView(kv(t("הצעות שבחרת", "Suggestions picked"), fmt(stats.suggestionsUsed)))
            addView(kv(t("קיצורי טקסט שהופעלו", "Shortcuts used"), fmt(stats.shortcutsUsed)))
        }

        // ---- אמוג'י ----
        val emo = stats.topEmoji(8)
        if (emo.isNotEmpty()) {
            section(t("האמוג'י שלך", "Your emoji"))
            card().addView(LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(dp(10), dp(12), dp(10), dp(12))
                for ((e, c) in emo) addView(LinearLayout(this@StatsActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    addView(TextView(this@StatsActivity).apply { text = e; textSize = 26f; gravity = Gravity.CENTER })
                    addView(TextView(this@StatsActivity).apply { text = fmt(c.toLong()); textSize = 12f; setTextColor(textSub); gravity = Gravity.CENTER })
                }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            })
        }

        // ---- איפוס ----
        root.addView(TextView(this).apply {
            text = t("איפוס הסטטיסטיקה", "Reset statistics")
            gravity = Gravity.CENTER
            textSize = 15f
            setTextColor(0xFFE5484D.toInt())
            setPadding(0, dp(14), 0, dp(14))
            background = rounded(surface, 18)
            isClickable = true
            setOnClickListener {
                AlertDialog.Builder(this@StatsActivity)
                    .setMessage(t("לאפס את הסטטיסטיקה? המילים שהמקלדת למדה לא יימחקו.", "Reset statistics? Learned words are kept."))
                    .setPositiveButton(t("אפס", "Reset")) { _, _ -> Stats.get(this@StatsActivity).reset(); render() }
                    .setNegativeButton(t("ביטול", "Cancel"), null)
                    .show()
            }
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(24) })

        setContentView(ScrollView(this).apply {
            setBackgroundColor(bg)
            addView(root)
        })
    }

    // ---------- רכיבים ----------

    private fun weekChart(stats: Stats): View {
        val dayNames = if (L.isEnglish(this)) arrayOf("S", "M", "T", "W", "T", "F", "S") else arrayOf("א׳", "ב׳", "ג׳", "ד׳", "ה׳", "ו׳", "ש׳")
        val values = (6 downTo 0).map { stats.wordsOn(it) }   // מהישן לחדש
        val max = (values.maxOrNull() ?: 0).coerceAtLeast(1)
        val chartH = dp(110)
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(16), dp(12), dp(12))
            (6 downTo 0).forEachIndexed { i, daysAgo ->
                val v = values[i]
                val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -daysAgo) }
                addView(LinearLayout(this@StatsActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM
                    addView(TextView(this@StatsActivity).apply {
                        text = if (v > 0) fmt(v.toLong()) else ""
                        textSize = 11f
                        setTextColor(textSub)
                        gravity = Gravity.CENTER
                    })
                    val barH = (chartH * v / max).coerceAtLeast(dp(4))
                    addView(View(this@StatsActivity).apply {
                        background = rounded(if (daysAgo == 0) accent else (accent and 0x00FFFFFF) or (0x88 shl 24), 6)
                    }, LinearLayout.LayoutParams(dp(22), barH).apply { topMargin = dp(4) })
                    addView(TextView(this@StatsActivity).apply {
                        text = dayNames[cal.get(Calendar.DAY_OF_WEEK) - 1]
                        textSize = 12f
                        setTextColor(if (daysAgo == 0) textMain else textSub)
                        gravity = Gravity.CENTER
                        setPadding(0, dp(6), 0, 0)
                    })
                }, LinearLayout.LayoutParams(0, chartH + dp(44), 1f))
            }
        }
    }

    private fun barRow(word: String, count: Int, max: Int, onTap: () -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(16), dp(8), dp(16), dp(8))
        isClickable = true
        setOnClickListener { onTap() }
        addView(TextView(this@StatsActivity).apply {
            text = word
            textSize = 15f
            setTextColor(textMain)
            maxLines = 1
        }, LinearLayout.LayoutParams(dp(96), LinearLayout.LayoutParams.WRAP_CONTENT))
        // פס יחסי
        val barBox = LinearLayout(this@StatsActivity).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(track, 5)
        }
        val frac = count.toFloat() / max
        barBox.addView(View(this@StatsActivity).apply { background = rounded(accent, 5) },
            LinearLayout.LayoutParams(0, dp(10), frac))
        barBox.addView(View(this@StatsActivity), LinearLayout.LayoutParams(0, dp(10), 1f - frac))
        addView(barBox, LinearLayout.LayoutParams(0, dp(10), 1f))
        addView(TextView(this@StatsActivity).apply {
            text = fmt(count.toLong())
            textSize = 13f
            setTextColor(textSub)
            gravity = Gravity.END
        }, LinearLayout.LayoutParams(dp(48), LinearLayout.LayoutParams.WRAP_CONTENT))
    }

    private fun kv(k: String, v: String) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        setPadding(dp(16), dp(12), dp(16), dp(12))
        addView(TextView(this@StatsActivity).apply { text = k; textSize = 15f; setTextColor(textMain) },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        addView(TextView(this@StatsActivity).apply { text = v; textSize = 15f; setTextColor(textSub); setTypeface(typeface, Typeface.BOLD) })
    }

    private fun note(t: String) = TextView(this).apply {
        text = t
        textSize = 13f
        setTextColor(textSub)
        setPadding(dp(16), dp(12), dp(16), dp(6))
    }

    private fun section(title: String) {
        root.addView(TextView(this).apply {
            text = title
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(accent)
            setPadding(dp(8), dp(22), dp(8), dp(8))
        })
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(surface, 18)
            setPadding(0, dp(4), 0, dp(8))
        }
        root.addView(c, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        return c
    }

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        cornerRadius = dp(radiusDp).toFloat()
        setColor(color)
    }

    private fun fmt(n: Long): String = String.format("%,d", n)
    private fun fmt(n: Int): String = fmt(n.toLong())

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
